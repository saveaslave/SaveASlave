-- Softaculous SQL Dump
-- http://www.softaculous.com
--
-- Host: localhost
-- Generation Time: April 20, 2014, 7:16 pm
-- Server version: 5.5.34
-- PHP Version: 5.3.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `saveasla_joom632`
--

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_config`
--

CREATE TABLE `sas_acymailing_config` (
  `namekey` varchar(200) NOT NULL,
  `value` text,
  PRIMARY KEY (`namekey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_acymailing_config'
--

INSERT INTO `sas_acymailing_config` VALUES
('level', 'Starter'),
('version', '4.6.2'),
('from_name', 'Save A Slave'),
('from_email', 'hello@jasonloton.com'),
('mailer_method', 'mail'),
('sendmail_path', '/usr/sbin/sendmail'),
('smtp_secured', ''),
('smtp_auth', '0'),
('smtp_username', ''),
('smtp_password', ''),
('reply_name', 'Save A Slave'),
('reply_email', 'hello@jasonloton.com'),
('cron_sendto', 'hello@jasonloton.com'),
('bounce_email', ''),
('add_names', '1'),
('encoding_format', '8bit'),
('charset', 'UTF-8'),
('word_wrapping', '150'),
('hostname', ''),
('embed_images', '0'),
('embed_files', '1'),
('editor', 'acyeditor'),
('multiple_part', '1'),
('smtp_host', 'localhost'),
('smtp_port', ''),
('queue_nbmail', '40'),
('queue_nbmail_auto', '70'),
('queue_type', 'auto'),
('queue_try', '3'),
('queue_pause', '120'),
('allow_visitor', '1'),
('require_confirmation', '0'),
('priority_newsletter', '3'),
('allowedfiles', 'zip,doc,docx,pdf,xls,txt,gzip,rar,jpg,gif,xlsx,pps,csv,bmp,ico,odg,odp,ods,odt,png,ppt,swf,xcf,mp3,wma'),
('uploadfolder', 'media/com_acymailing/upload'),
('confirm_redirect', ''),
('subscription_message', '1'),
('notification_unsuball', ''),
('cron_next', '1251990901'),
('confirmation_message', '1'),
('welcome_message', '1'),
('unsub_message', '1'),
('cron_last', '0'),
('cron_fromip', ''),
('cron_report', ''),
('cron_frequency', '900'),
('cron_sendreport', '2'),
('cron_fullreport', '1'),
('cron_savereport', '2'),
('cron_savepath', 'media/com_acymailing/logs/report105527062.log'),
('notification_created', ''),
('notification_accept', ''),
('notification_refuse', ''),
('forward', '0'),
('description_starter', 'Joomla!™ Mailing Extension'),
('description_essential', 'Joomla!™ Mailing Extension'),
('description_business', 'Joomla!™ Marketing Campaign'),
('description_enterprise', 'Joomla!™ Mailing Extension'),
('priority_followup', '2'),
('unsub_redirect', ''),
('show_footer', '1'),
('use_sef', '0'),
('itemid', '0'),
('css_module', 'default'),
('css_frontend', 'default'),
('css_backend', 'default'),
('bootstrap_frontend', '0'),
('menu_position', 'above'),
('unsub_reasons', 'a:2:{i:0;s:21:"UNSUB_SURVEY_FREQUENT";i:1;s:21:"UNSUB_SURVEY_RELEVANT";}'),
('installcomplete', '1'),
('Starter', '0'),
('Essential', '1'),
('Business', '2'),
('Enterprise', '3'),
('website', 'http://saveaslave.us/');

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_fields`
--

CREATE TABLE `sas_acymailing_fields` (
  `fieldid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `fieldname` varchar(250) NOT NULL,
  `namekey` varchar(50) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `value` text NOT NULL,
  `published` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `ordering` smallint(5) unsigned DEFAULT '99',
  `options` text,
  `core` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `backend` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `frontcomp` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `default` varchar(250) DEFAULT NULL,
  `listing` tinyint(3) unsigned DEFAULT NULL,
  `frontlisting` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `frontjoomlaprofile` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `frontjoomlaregistration` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `joomlaprofile` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fieldid`),
  UNIQUE KEY `namekey` (`namekey`),
  KEY `orderingindex` (`published`,`ordering`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table 'sas_acymailing_fields'
--

INSERT INTO `sas_acymailing_fields` VALUES
(1, 'NAMECAPTION', 'name', 'text', '', 1, 1, '', 1, 1, 1, 1, '', 1, 1, 0, 0, 0),
(2, 'EMAILCAPTION', 'email', 'text', '', 1, 2, '', 1, 1, 1, 1, '', 1, 1, 0, 0, 0),
(3, 'RECEIVE', 'html', 'radio', '0::JOOMEXT_TEXT\n1::HTML', 1, 3, '', 1, 1, 1, 1, '1', 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_filter`
--

CREATE TABLE `sas_acymailing_filter` (
  `filid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` text,
  `published` tinyint(3) unsigned DEFAULT NULL,
  `lasttime` int(10) unsigned DEFAULT NULL,
  `trigger` text,
  `report` text,
  `action` text,
  `filter` text,
  PRIMARY KEY (`filid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_geolocation`
--

CREATE TABLE `sas_acymailing_geolocation` (
  `geolocation_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `geolocation_subid` int(10) unsigned NOT NULL DEFAULT '0',
  `geolocation_type` varchar(255) NOT NULL DEFAULT 'subscription',
  `geolocation_ip` varchar(255) NOT NULL DEFAULT '',
  `geolocation_created` int(10) unsigned NOT NULL DEFAULT '0',
  `geolocation_latitude` decimal(9,6) NOT NULL DEFAULT '0.000000',
  `geolocation_longitude` decimal(9,6) NOT NULL DEFAULT '0.000000',
  `geolocation_postal_code` varchar(255) NOT NULL DEFAULT '',
  `geolocation_country` varchar(255) NOT NULL DEFAULT '',
  `geolocation_country_code` varchar(255) NOT NULL DEFAULT '',
  `geolocation_state` varchar(255) NOT NULL DEFAULT '',
  `geolocation_state_code` varchar(255) NOT NULL DEFAULT '',
  `geolocation_city` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`geolocation_id`),
  KEY `geolocation_type` (`geolocation_subid`,`geolocation_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_history`
--

CREATE TABLE `sas_acymailing_history` (
  `subid` int(10) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `action` varchar(50) NOT NULL COMMENT 'different actions: created,modified,confirmed',
  `data` text,
  `source` text,
  `mailid` mediumint(8) unsigned DEFAULT NULL,
  KEY `subid` (`subid`,`date`),
  KEY `dateindex` (`date`),
  KEY `actionindex` (`action`,`mailid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_list`
--

CREATE TABLE `sas_acymailing_list` (
  `name` varchar(250) NOT NULL,
  `description` text,
  `ordering` smallint(5) unsigned DEFAULT '0',
  `listid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `published` tinyint(4) DEFAULT NULL,
  `userid` int(10) unsigned DEFAULT NULL,
  `alias` varchar(250) DEFAULT NULL,
  `color` varchar(30) DEFAULT NULL,
  `visible` tinyint(4) NOT NULL DEFAULT '1',
  `welmailid` mediumint(9) DEFAULT NULL,
  `unsubmailid` mediumint(9) DEFAULT NULL,
  `type` enum('list','campaign') NOT NULL DEFAULT 'list',
  `access_sub` varchar(250) DEFAULT 'all',
  `access_manage` varchar(250) NOT NULL DEFAULT 'none',
  `languages` varchar(250) NOT NULL DEFAULT 'all',
  `startrule` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`listid`),
  KEY `typeorderingindex` (`type`,`ordering`),
  KEY `useridindex` (`userid`),
  KEY `typeuseridindex` (`type`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table 'sas_acymailing_list'
--

INSERT INTO `sas_acymailing_list` VALUES
('Newsletters', 'Receive our latest news', 1, 1, 1, 222, 'mailing_list', '#3366ff', 1, NULL, NULL, 'list', 'all', 'none', 'all', '0');

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_listcampaign`
--

CREATE TABLE `sas_acymailing_listcampaign` (
  `campaignid` smallint(5) unsigned NOT NULL,
  `listid` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`campaignid`,`listid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_listmail`
--

CREATE TABLE `sas_acymailing_listmail` (
  `listid` smallint(5) unsigned NOT NULL,
  `mailid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`listid`,`mailid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_listsub`
--

CREATE TABLE `sas_acymailing_listsub` (
  `listid` smallint(5) unsigned NOT NULL,
  `subid` int(10) unsigned NOT NULL,
  `subdate` int(10) unsigned DEFAULT NULL,
  `unsubdate` int(10) unsigned DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`listid`,`subid`),
  KEY `subidindex` (`subid`),
  KEY `listidstatusindex` (`listid`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_acymailing_listsub'
--

INSERT INTO `sas_acymailing_listsub` VALUES
(1, 1, 1397330356, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_mail`
--

CREATE TABLE `sas_acymailing_mail` (
  `mailid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(250) NOT NULL,
  `body` longtext NOT NULL,
  `altbody` longtext NOT NULL,
  `published` tinyint(4) DEFAULT '1',
  `senddate` int(10) unsigned DEFAULT NULL,
  `created` int(10) unsigned DEFAULT NULL,
  `fromname` varchar(250) DEFAULT NULL,
  `fromemail` varchar(250) DEFAULT NULL,
  `replyname` varchar(250) DEFAULT NULL,
  `replyemail` varchar(250) DEFAULT NULL,
  `type` enum('news','autonews','followup','unsub','welcome','notification','joomlanotification') NOT NULL DEFAULT 'news',
  `visible` tinyint(4) NOT NULL DEFAULT '1',
  `userid` int(10) unsigned DEFAULT NULL,
  `alias` varchar(250) DEFAULT NULL,
  `attach` text,
  `html` tinyint(4) NOT NULL DEFAULT '1',
  `tempid` smallint(6) NOT NULL DEFAULT '0',
  `key` varchar(200) DEFAULT NULL,
  `frequency` varchar(50) DEFAULT NULL,
  `params` text,
  `sentby` int(10) unsigned DEFAULT NULL,
  `metakey` text,
  `metadesc` text,
  `filter` text,
  PRIMARY KEY (`mailid`),
  KEY `senddate` (`senddate`),
  KEY `typemailidindex` (`type`,`mailid`),
  KEY `useridindex` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table 'sas_acymailing_mail'
--

INSERT INTO `sas_acymailing_mail` VALUES
(1, 'New Subscriber on your website : {user:email}', '<p>Hello {subtag:name},</p><p>A new user has been created in AcyMailing : </p><blockquote><p>Name : {user:name}</p><p>Email : {user:email}</p><p>IP : {user:ip} </p><p>Subscription : {user:subscription}</p></blockquote>', '', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'notification', 0, NULL, 'notification_created', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'A User unsubscribed from all your lists : {user:email}', '<p>Hello {subtag:name},</p><p>The user {user:name} : {user:email} unsubscribed from all your lists</p><p>Subscription : {user:subscription}</p><p>{survey}</p>', '', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'notification', 0, NULL, 'notification_unsuball', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'A User unsubscribed : {user:email}', '<p>Hello {subtag:name},</p><p>The user {user:name} : {user:email} unsubscribed from your list</p><p>Subscription : {user:subscription}</p><p>{survey}</p>', '', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'notification', 0, NULL, 'notification_unsub', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'A User refuses to receive e-mails from your website : {user:email}', '<p>The User {user:name} : {user:email} refuses to receive any e-mail anymore from your website.</p><p>Subscription : {user:subscription}</p><p>{survey}</p>', '', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'notification', 0, NULL, 'notification_refuse', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'New contact from your website : {user:email}', '<p>Hello {subtag:name},</p><p>A user has contacted you : </p><blockquote><p>Name : {user:name}</p><p>Email : {user:email}</p><p>IP : {user:ip} </p><p>Subscription : {user:subscription}</p></blockquote>', '', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'notification', 0, NULL, 'notification_contact', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'A user confirm his subscription : {user:email}', '<p>Hello {subtag:name},</p><p>A user has confirmed his subscription in AcyMailing : </p><blockquote><p>Name : {user:name}</p><p>Email : {user:email}</p><p>IP : {user:ip} </p><p>Subscription : {user:subscription}</p></blockquote>', '', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'notification', 0, NULL, 'notification_confirm', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, '{subtag:name|ucfirst}, {trans:PLEASE_CONFIRM_SUB}', '<div style="text-align: center; width: 100%; background-color: #ffffff;">\r\n			<table style="text-align:justify; margin:auto; background-color:#ebebeb; border:1px solid #e7e7e7" border="0" cellspacing="0" cellpadding="0" width="600" align="center" bgcolor="#ebebeb">\r\n			<tbody>\r\n			<tr style="line-height: 0px;">\r\n			<td style="line-height: 0px;" height="38px"><img src="media/com_acymailing/templates/newsletter-4/top.png" border="0" alt=" - - - " /></td>\r\n			</tr>\r\n			<tr>\r\n			<td style="text-align:center" width="600">\r\n			<table style="margin:auto;" border="0" cellspacing="0" cellpadding="0" width="520">\r\n			<tbody>\r\n			<tr>\r\n			<td style="background-color: #ffffff; border: 1px solid #dbdbdb; padding: 20px; width: 500px; margin: 15px auto; text-align: left;">\r\n			<h1>Hello {subtag:name|ucfirst},</h1>\r\n			<p>{trans:CONFIRM_MSG}<br /><br />{trans:CONFIRM_MSG_ACTIVATE}</p>\r\n			<br />\r\n			<p style="text-align:center;"><strong>{confirm}{trans:CONFIRM_SUBSCRIPTION}{/confirm}</strong></p>\r\n			</td>\r\n			</tr>\r\n			</tbody>\r\n			</table>\r\n			</td>\r\n			</tr>\r\n			<tr style="line-height: 0px;">\r\n			<td style="line-height: 0px;" height="40px"><img src="media/com_acymailing/templates/newsletter-4/bottom.png" border="0" alt=" - - - " /></td>\r\n			</tr>\r\n			</tbody>\r\n			</table>\r\n			</div>', '', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'notification', 0, NULL, 'confirmation', NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'AcyMailing Cron Report {mainreport}', '<p>{report}</p><p>{detailreport}</p>', '', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'notification', 0, NULL, 'report', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'Modify your subscription', '<p>Hello {subtag:name}, </p><p>You requested some changes on your subscription,</p><p>Please {modify}click here{/modify} to be identified as the owner of this account and then modify your subscription.</p>', '', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'notification', 0, NULL, 'modif', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_queue`
--

CREATE TABLE `sas_acymailing_queue` (
  `senddate` int(10) unsigned NOT NULL,
  `subid` int(10) unsigned NOT NULL,
  `mailid` mediumint(8) unsigned NOT NULL,
  `priority` tinyint(3) unsigned DEFAULT '3',
  `try` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `paramqueue` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`subid`,`mailid`),
  KEY `listingindex` (`senddate`,`subid`),
  KEY `mailidindex` (`mailid`),
  KEY `orderingindex` (`priority`,`senddate`,`subid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_rules`
--

CREATE TABLE `sas_acymailing_rules` (
  `ruleid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `ordering` smallint(6) DEFAULT NULL,
  `regex` text NOT NULL,
  `executed_on` text NOT NULL,
  `action_message` text NOT NULL,
  `action_user` text NOT NULL,
  `published` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`ruleid`),
  KEY `ordering` (`published`,`ordering`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_stats`
--

CREATE TABLE `sas_acymailing_stats` (
  `mailid` mediumint(8) unsigned NOT NULL,
  `senthtml` int(10) unsigned NOT NULL DEFAULT '0',
  `senttext` int(10) unsigned NOT NULL DEFAULT '0',
  `senddate` int(10) unsigned NOT NULL,
  `openunique` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `opentotal` int(10) unsigned NOT NULL DEFAULT '0',
  `bounceunique` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `fail` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `clicktotal` int(10) unsigned NOT NULL DEFAULT '0',
  `clickunique` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `unsub` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `forward` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `bouncedetails` text,
  PRIMARY KEY (`mailid`),
  KEY `senddateindex` (`senddate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_subscriber`
--

CREATE TABLE `sas_acymailing_subscriber` (
  `subid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(200) NOT NULL,
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(250) NOT NULL,
  `created` int(10) unsigned DEFAULT NULL,
  `confirmed` tinyint(4) NOT NULL DEFAULT '0',
  `enabled` tinyint(4) NOT NULL DEFAULT '1',
  `accept` tinyint(4) NOT NULL DEFAULT '1',
  `ip` varchar(100) DEFAULT NULL,
  `html` tinyint(4) NOT NULL DEFAULT '1',
  `key` varchar(250) DEFAULT NULL,
  `confirmed_date` int(10) unsigned NOT NULL DEFAULT '0',
  `confirmed_ip` varchar(100) DEFAULT NULL,
  `lastopen_date` int(10) unsigned NOT NULL DEFAULT '0',
  `lastopen_ip` varchar(100) DEFAULT NULL,
  `lastclick_date` int(10) unsigned NOT NULL DEFAULT '0',
  `lastsent_date` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`subid`),
  UNIQUE KEY `email` (`email`),
  KEY `userid` (`userid`),
  KEY `queueindex` (`enabled`,`accept`,`confirmed`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table 'sas_acymailing_subscriber'
--

INSERT INTO `sas_acymailing_subscriber` VALUES
(1, 'hello@jasonloton.com', 222, 'Administrator', 1397325493, 1, 1, 1, NULL, 1, NULL, 0, NULL, 0, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_template`
--

CREATE TABLE `sas_acymailing_template` (
  `tempid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` text,
  `body` longtext,
  `altbody` longtext,
  `created` int(10) unsigned DEFAULT NULL,
  `published` tinyint(4) NOT NULL DEFAULT '1',
  `premium` tinyint(4) NOT NULL DEFAULT '0',
  `ordering` smallint(5) unsigned DEFAULT '0',
  `namekey` varchar(50) NOT NULL,
  `styles` text,
  `subject` varchar(250) DEFAULT NULL,
  `stylesheet` text,
  `fromname` varchar(250) DEFAULT NULL,
  `fromemail` varchar(250) DEFAULT NULL,
  `replyname` varchar(250) DEFAULT NULL,
  `replyemail` varchar(250) DEFAULT NULL,
  `thumb` varchar(250) DEFAULT NULL,
  `readmore` varchar(250) DEFAULT NULL,
  `access` varchar(250) DEFAULT 'all',
  PRIMARY KEY (`tempid`),
  UNIQUE KEY `namekey` (`namekey`),
  KEY `orderingindex` (`ordering`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table 'sas_acymailing_template'
--

INSERT INTO `sas_acymailing_template` VALUES
(1, 'Notification template', '', '<div style="text-align: center; width: 100%; background-color:#ffffff;">\r\n<div class="acymailing_online acyeditor_delete acyeditor_text" style="text-align:center">{readonline}This email contains graphics, so if you don''t see them, view it in your browser{/readonline}</div>\r\n\r\n<table align="center" border="0" cellpadding="0" cellspacing="0" class="w600" style="text-align: justify; margin: auto; width:600px">\r\n	<tbody>\r\n		<tr style="line-height: 0px;" class="acyeditor_delete">\r\n			<td class="w600" colspan="5" style="background-color: #69b4c0;" valign="bottom" width="600"><img alt=" - - - " src="media/com_acymailing/templates/newsletter-4/images/top.png" /></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete">\r\n			<td class="w40" style="background-color: #ebebeb;" width="40"></td>\r\n			<td class="acyeditor_text w520" colspan="3" height="80" style="text-align: left; background-color: rgb(235, 235, 235);" width="520"><img alt="-" src="media/com_acymailing/templates/newsletter-4/images/message_icon.png" style="float:left; margin-right:10px;" />\r\n				<h3>Topic of your message</h3>\r\n\r\n				<h4>Subtitle for your message</h4>\r\n			</td>\r\n			<td class="acyeditor_picture w40" style="background-color: #ebebeb;" width="40"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete" >\r\n			<td class="w40" style="background-color: #ebebeb;" width="40"></td>\r\n			<td class="w20" style="background-color: #fff;" width="20"></td>\r\n			<td class="w480" height="20" style="background-color:#fff;" width="480"></td>\r\n			<td class="w20" style="background-color: #fff;" width="20"></td>\r\n			<td class="w40" style="background-color: #ebebeb;" width="40"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete" >\r\n			<td class="w40" style="background-color: #ebebeb;" width="40"></td>\r\n			<td class="w20" style="background-color: #fff;" width="20"></td>\r\n			<td class="acyeditor_text w480 pict" style="background-color:#fff; text-align: left;" width="480">\r\n			<h1>Dear {subtag:name},</h1>\r\n			Your message here...<br />\r\n			</td>\r\n			<td class="w20" style="background-color: #fff;" width="20"></td>\r\n			<td class="w40" style="background-color: #ebebeb;" width="40"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete" >\r\n			<td class="w40" style="background-color: #ebebeb;" width="40"></td>\r\n			<td class="w20" style="background-color: #fff;" width="20"></td>\r\n			<td class="w480" height="20" style="background-color:#fff;" width="480"></td>\r\n			<td class="w20" style="background-color: #fff;" width="20"></td>\r\n			<td class="w40" style="background-color: #ebebeb;" width="40"></td>\r\n		</tr>\r\n		<tr style="line-height: 0px;" class="acyeditor_delete">\r\n			<td class="w600" colspan="5" style="background-color:#ebebeb;" width="600"><img alt=" - - - " src="media/com_acymailing/templates/newsletter-4/images/bottom.png" /></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<div class="acyeditor_delete acyeditor_text" style="text-align:center">Not interested any more? {unsubscribe}Unsubscribe{/unsubscribe}</div>\r\n</div>', '', NULL, 1, 0, 1, 'newsletter-4', 'a:10:{s:6:"tag_h1";s:76:"color:#393939 !important; font-size:14px; font-weight:bold; margin:10px 0px;";s:6:"tag_h2";s:106:"color: #309fb3 !important; font-size: 14px; font-weight: normal; text-align:left; margin:0px; padding:0px;";s:6:"tag_h3";s:144:"color: #393939 !important; font-size: 18px; font-weight: bold; text-align:left; margin:0px; padding-bottom:5px; border-bottom:1px solid #bdbdbd;";s:6:"tag_h4";s:117:"color: #309fb3 !important; font-size: 14px; font-weight: bold; text-align:left; margin:0px; padding: 5px 0px 0px 0px;";s:5:"tag_a";s:71:"color:#309FB3; text-decoration:none; font-style:italic; cursor:pointer;";s:19:"acymailing_readmore";s:90:"font-size: 12px; color: #fff; background-color:#309fb3; font-weight:bold; padding:3px 5px;";s:17:"acymailing_online";s:52:"color:#a3a3a3; text-decoration:none; font-size:11px;";s:16:"acymailing_unsub";s:52:"color:#a3a3a3; text-decoration:none; font-size:11px;";s:8:"color_bg";s:7:"#ffffff";s:18:"acymailing_content";s:19:"text-align:justify;";}', NULL, 'div,table,p{font-family: Verdana, Arial, Helvetica, sans-serif; font-size:12px; text-align:justify; color:#8c8c8c; margin:0px}\r\ndiv.info{text-align:center;padding:10px;font-size:11px;color:#a3a3a3;}\r\n\r\n@media (min-width:320px){\r\n	table[class=w600], td[class=w600] { width: 320px !important;}\r\n	table[class=w520], td[class=w520] { width: 280px !important;}\r\n	table[class=w480], td[class=w480] { width: 260px !important;}\r\n	td[class=w40] { width: 20px !important;}\r\n	td[class=w20] { width: 10px !important;}\r\n	.w600 img {max-width:320px; height:auto !important}\r\n	.w480 img {max-width:260px; height:auto !important;}\r\n}\r\n\r\n@media (min-width:480px) {\r\n	table[class=w600], td[class=w600] { width: 480px !important;}\r\n	table[class=w520], td[class=w520] { width: 440px !important;}\r\n	table[class=w480], td[class=w480] { width: 420px !important;}\r\n	td[class=w40] { width: 20px !important;}\r\n	td[class=w20] { width: 10px !important;}\r\n	.w600 img {max-width:480px; height:auto !important}\r\n	.w480 img {max-width:420px;  height:auto !important;}\r\n}\r\n@media (min-width:600px){\r\n	table[class=w600], td[class=w600] { width: 600px !important;}\r\n	table[class=w520], td[class=w520] { width: 520px !important;}\r\n	table[class=w480], td[class=w480] { width: 480px !important;}\r\n	td[class=w40] { width40px !important;}\r\n	td[class=w20] { width: 20px !important;}\r\n	.w600 img {max-width:600px; height:auto !important}\r\n	.w480 img {max-width:480px;  height:auto !important;}\r\n}\r\n', NULL, NULL, NULL, NULL, 'media/com_acymailing/templates/newsletter-4/newsletter-4.png', '', 'all'),
(2, 'Newspaper', '', '<div align="center" style="width:100%; background-color:#454545; padding-bottom:20px; color:#ffffff;">\r\n<div class="acymailing_online acyeditor_delete acyeditor_text">{readonline}This e-mail contains graphics, if you don''t see them <strong>» view it online.</strong>{/readonline}</div>\r\n\r\n<table align="center" border="0" cellpadding="0" cellspacing="0" class="w600" style="margin:auto; background-color:#ffffff; color:#454545;" width="600">\r\n		<tr>\r\n			<td class="w600">\r\n			<table border="0" cellpadding="0" cellspacing="0" class="w600" width="600">\r\n					<tr class="acyeditor_delete" >\r\n						<td class="w30" style="background-color:#ffffff" width="30"></td>\r\n						<td class="acyeditor_text w540" style="font-family:Times New Roman, Times, serif; background-color:#ffffff; text-align:left" width="540">&nbsp;\r\n						<h1><img alt="logo" src="media/com_acymailing/templates/newsletter-5/images/logo.png" style="float: right; width: 107px; height: 70px;" /></h1>\r\n\r\n						<h1>Your title here</h1>\r\n\r\n						<h3>your subtitle</h3>\r\n						</td>\r\n						<td class="w30" style="line-height:0px; background-color:#ffffff" width="30"></td>\r\n					</tr>\r\n					<tr class="acyeditor_delete">\r\n						<td class="w600" colspan="3" style="line-height:0px; background-color:#e4e4e4" valign="top" width="600"><img alt="---" src="media/com_acymailing/templates/newsletter-5/images/header.png" /></td>\r\n					</tr>\r\n					<tr class="acyeditor_delete">\r\n						<td class="acyeditor_picture w600" colspan="3" style="line-height:0px; background-color:#ffffff" valign="top" width="600"><img alt="banner" src="media/com_acymailing/templates/newsletter-5/images/banner.png" /></td>\r\n					</tr>\r\n					<tr class="acyeditor_delete">\r\n						<td class="w600" colspan="3" style="line-height:0px;" valign="top" width="600"><img alt="---" src="media/com_acymailing/templates/newsletter-5/images/separator.png" /></td>\r\n					</tr>\r\n					<tr>\r\n						<td class="w30" style="background-color:#ffffff" width="30"></td>\r\n						<td class="acyeditor_text w540" style="text-align:justify; color:#575757; font-family:Times New Roman, Times, serif; font-size:13px; background-color:#ffffff" width="540">\r\n						<h2>Interviews and reports</h2>\r\n						<span class="dark">Lorem ipsum dolor sit amet, consectLorem ipsum dolor sit amet.</span><br />\r\n						consectetur adipiscing elit. Aenean sollicitudin orci sit amet urna lla pretium ut. Sed elementum convallis mi. Vivamus elementum.ed elementum convallis mi. <a href="#">Vivamus elementum</a>.Lorem ipsum dolor sit amet.<br />\r\n						<br />\r\n						cLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean sollicitudin orci sit amet urna lla pretium ut. Sed elementum convallis mi. Vivamus elementum.<br />\r\n						<br />\r\n						<span class="acymailing_readmore">Read More</span><br />\r\n						&nbsp;\r\n						<h2>Journalism around the world</h2>\r\n						<span class="dark">Lorem ipsum dolor sit amet, consectLorem. consectetur adipiscing elit. Aenean sollicitudin orci sit amet urna lla pretium ut. Sed elementum.</span> consectetur adipiscing elit. Aenean sollicitudin orci sit amet urna lla pretium ut. Sed elementum convallis mi. Vivamus elementum.ed elementum convallis mi.<br />\r\n						Vivamus elementum.<a href="#">Lorem ipsum dolor</a> sit amet.Lorem ipsum dolor sit amet, consectetur adipiscing elit.<br />\r\n						<br />\r\n						<span class="acymailing_readmore">Read More</span></td>\r\n						<td class="w30" style="background-color:#ffffff" width="30"></td>\r\n					</tr>\r\n					<tr style="line-height: 0px;">\r\n						<td class="w600" colspan="3" style="background-color:#ffffff" width="600"><img alt="--" src="media/com_acymailing/templates/newsletter-5/images/footer1.png" width="600" /></td>\r\n					</tr>\r\n					<tr>\r\n						<td class="acyfooter acyeditor_text w600" colspan="3" height="25" style="text-align:center; background-color:#ebebeb;  color:#454545; font-family:Times New Roman, Times, serif; font-size:13px" width="600"><a href="#">www.mywebsite.com</a> | <a href="#">contact</a> | <a href="#">Facebook</a> | <a href="#">Twitter</a></td>\r\n					</tr>\r\n					<tr style="line-height: 0px;">\r\n						<td class="w600" colspan="3" style="background-color:#454545;" width="600"><img alt="--" src="media/com_acymailing/templates/newsletter-5/images/footer2.png" width="600" /></td>\r\n					</tr>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n</table>\r\n\r\n<div class="acymailing_unsub acyeditor_delete acyeditor_text">{unsubscribe}If you''re not interested any more <strong>» unsubscribe</strong>{/unsubscribe}</div>\r\n</div>\r\n', '', NULL, 1, 0, 2, 'newsletter-5', 'a:10:{s:6:"tag_h1";s:71:"color:#454545 !important; font-size:24px; font-weight:bold; margin:0px;";s:6:"tag_h2";s:145:"color:#b20000 !important; font-size:18px; font-weight:bold; margin:0px; margin-bottom:10px; padding-bottom:4px; border-bottom: 1px solid #d6d6d6;";s:6:"tag_h3";s:76:"color:#b20101 !important; font-weight:bold; font-size:18px; margin:10px 0px;";s:6:"tag_h4";s:67:"color:#e52323 !important; font-weight:bold; margin:0px; padding:0px";s:5:"tag_a";s:65:"cursor:pointer; color:#9d0000; text-decoration:none; border:none;";s:19:"acymailing_readmore";s:152:"cursor:pointer; color:#ffffff; background-color:#9d0000; border-top:1px solid #9d0000; border-bottom:1px solid #9d0000; padding:3px 5px; font-size:13px;";s:17:"acymailing_online";s:148:"color:#dddddd; text-decoration:none; font-size:13px; margin:10px; text-align:center; font-family:Times New Roman, Times, serif; padding-bottom:10px;";s:8:"color_bg";s:7:"#454545";s:18:"acymailing_content";s:0:"";s:16:"acymailing_unsub";s:131:"color:#dddddd; text-decoration:none; font-size:13px; text-align:center; font-family:Times New Roman, Times, serif; padding-top:10px";}', NULL, '.acyfooter a{\r\n	color:#454545;\r\n}\r\n.dark{\r\n	color:#454545;\r\n	font-weight:bold;\r\n}\r\ndiv,table,p{font-family:"Times New Roman", Times, serif;font-size:13px;color:#575757;}\r\n\r\n\r\n\r\n@media (min-width:320px){\r\n	table[class=w600], td[class=w600] { width:320px !important; }\r\n	table[class=w540], td[class=w540] { width:260px !important; }\r\n	td[class=w30] { width:30px !important; }\r\n	.w600 img {max-width:320px; height:auto !important; }\r\n	.w540 img {max-width:260px; height:auto !important; }\r\n}\r\n\r\n@media (min-width: 480px){\r\n	table[class=w600], td[class=w600] { width:480px !important; }\r\n	table[class=w540], td[class=w540] { width:420px !important; }\r\n	td[class=w30] { width:30px !important; }\r\n	.w600 img {max-width:480px; height:auto !important; }\r\n	.w540 img {max-width:420px; height:auto !important; }\r\n}\r\n\r\n@media (min-width:600px){\r\n	table[class=w600], td[class=w600] { width:600px !important; }\r\n	table[class=w540], td[class=w540] { width:540px !important; }\r\n	td[class=w30] { width:30px !important; }\r\n	.w600 img     {max-width:600px; height:auto !important; }\r\n	.w540 img {max-width:540px; height:auto !important; }\r\n}\r\n', NULL, NULL, NULL, NULL, 'media/com_acymailing/templates/newsletter-5/newsletter-5.png', '', 'all'),
(3, 'Build Bio', '', '<div align="center" style="width:100%; background-color:#3c3c3c; padding-bottom:20px; color:#ffffff;">\r\n<div class="acymailing_online acyeditor_delete acyeditor_text">{readonline}This e-mail contains graphics, if you don''t see them <strong>» view it online.</strong>{/readonline}</div>\r\n\r\n<table align="center" border="0" cellpadding="0" cellspacing="0" class="w600" style="margin:auto; background-color:#ffffff; color:#575757;" width="600">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<table border="0" cellpadding="0" cellspacing="0" class="w600" width="600">\r\n				<tr class="acyeditor_delete">\r\n					<td class="w600" colspan="3" style="line-height:0px; background-color:#eeeeee" valign="bottom" width="600"><img alt="mail" height="41" src="media/com_acymailing/templates/newsletter-6/images/header.png" width="600" /></td>\r\n				</tr>\r\n				<tr class="acyeditor_delete">\r\n					<td class="w30" style="color:#ffffff;" width="30"></td>\r\n					<td class="acyeditor_picture w540" style="line-height:0px; background-color:#ffffff; text-align:center" width="540"><img alt="" src="media/com_acymailing/templates/newsletter-6/images/banner.png" style="width: 540px; height: 122px;" /></td>\r\n					<td class="w30" height="122" style="background-color:#ffffff" width="30"></td>\r\n				</tr>\r\n				<tr class="acyeditor_delete">\r\n					<td class="w30" style="background-color:#b9cf00; color:#ffffff;" width="30"></td>\r\n					<td class="acyeditor_text w540" height="25" style="text-align:right; background-color:#b9cf00; color:#ffffff;" width="540"><span class="hide">Newsletter</span> {date:3}</td>\r\n					<td class="w30" style="background-color:#b9cf00; color:#ffffff;" width="30"></td>\r\n				</tr>\r\n				<tr>\r\n					<td class="w600" colspan="3" height="25" style="background-color:#ffffff" width="600"></td>\r\n				</tr>\r\n				<tr>\r\n					<td class="w30" style="background-color:#ffffff" width="30"></td>\r\n					<td class="acyeditor_text w540" style="text-align:justify; color:#575757; background-color:#ffffff" width="540"><span class="intro">Hello {subtag:name},</span><br />\r\n					<br />\r\n					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean sollicitudin orci sit amet urna lla pretium ut. Sed elementum Vivamus elementum. sollicitudin orci sit amet urna lla pretium ut. Sed elementum convallis mi.\r\n					<h2>Day One</h2>\r\n					<strong>Lorem ipsum dolor sit amet, consectLorem ipsum dolor sit amet.</strong><br />\r\n					consectetur adipiscing elit. Aenean sollicitudin orci sit amet urna lla pretium ut. Sed <a href="#">elementum convallis</a> mi. Vivamus elementum.ed elementum convallis mi. Vivamus elementum.Lorem ipsum dolor sit amet.<br />\r\n					<br />\r\n					cLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean sollicitudin orci sit amet urna lla pretium ut. Sed elementum convallis mi. Vivamus elementum.<br />\r\n					<br />\r\n					<span class="acymailing_readmore">Read More</span>\r\n\r\n					<h2>How to build a green house</h2>\r\n					<img alt="picture" height="160" src="media/com_acymailing/templates/newsletter-6/images/picture.png" style="float:left;" width="193" /> <strong>Lorem ipsum dolor sit amet, elit.</strong> Aenean sollicitudin orci sit amet . Sed <a href="#">elementum convallis</a> mi. Vivamus elementum.ed elementum convallis mi. Vivamus elementum.Lorem ipsum dolor sit amet.<br />\r\n					<br />\r\n					cLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean sollicitudin orci sit amet urna lla pretium ut. Sed elementum convallis mi. Vivamus elementum.<br />\r\n					<br />\r\n					<span class="acymailing_readmore">Read More</span></td>\r\n					<td class="w30" style="background-color:#ffffff" width="30"></td>\r\n				</tr>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr class="acyeditor_delete">\r\n			<td>\r\n			<table border="0" cellpadding="0" cellspacing="0" class="w600" width="600">\r\n				<tr style="line-height: 0px;">\r\n					<td class="w600" colspan="3" style="line-height:0px; background-color:#efefef;" valign="top" width="600"><img alt="--" height="18" src="media/com_acymailing/templates/newsletter-6/images/footer1.png" width="600" /></td>\r\n				</tr>\r\n				<tr>\r\n					<td class="w30" height="20" style="line-height:0px; background-color:#efefef;" width="30"></td>\r\n					<td class="acyfooter acyeditor_text w540" style="text-align:right; background-color:#efefef; color:#575757;" width="540"><a href="#">www.mywebsite.com</a> | <a href="#">Contact</a><a href="#"><img alt="message" class="hide" src="media/com_acymailing/templates/newsletter-6/images/mail.png" style="border: medium none; width: 35px; height: 20px;" /></a></td>\r\n					<td class="w30" height="20" style="line-height:0px; background-color:#efefef;" width="30"></td>\r\n				</tr>\r\n				<tr style="line-height: 0px;">\r\n					<td class="w600" colspan="3" style="background-color:#efefef; line-height:0px;" valign="top" width="600"><img alt="--" height="24" src="media/com_acymailing/templates/newsletter-6/images/footer2.png" width="600" /></td>\r\n				</tr>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<div class="acymailing_unsub acyeditor_delete acyeditor_text" >{unsubscribe}If you''re not interested any more <strong>» unsubscribe</strong>{/unsubscribe}</div>\r\n</div>', '', NULL, 1, 0, 3, 'newsletter-6', 'a:9:{s:6:"tag_h1";s:69:"font-weight:bold; font-size:14px;color:#3c3c3c !important;margin:0px;";s:6:"tag_h2";s:129:"color:#b9cf00 !important; font-size:14px; font-weight:bold; margin-top:20px; border-bottom:1px solid #d6d6d6; padding-bottom:4px;";s:6:"tag_h3";s:149:"color:#7e7e7e !important; font-size:14px; font-weight:bold; margin:20px 0px 0px 0px; border-bottom:1px solid #d6d6d6; padding-bottom:0px 0px 4px 0px;";s:6:"tag_h4";s:84:"color:#879700 !important; font-size:12px; font-weight:bold; margin:0px; padding:0px;";s:8:"color_bg";s:7:"#3c3c3c";s:5:"tag_a";s:65:"cursor:pointer; color:#a2b500; text-decoration:none; border:none;";s:17:"acymailing_online";s:91:"color:#dddddd; text-decoration:none; font-size:11px; text-align:center; padding-bottom:10px";s:16:"acymailing_unsub";s:88:"color:#dddddd; text-decoration:none; font-size:11px; text-align:center; padding-top:10px";s:19:"acymailing_readmore";s:73:"cursor:pointer; color:#ffffff; background-color:#b9cf00; padding:3px 5px;";}', NULL, 'table, div, p{\r\n	font-family: Verdana, Arial, Helvetica, sans-serif;\r\n	font-size:11px;\r\n	color:#575757;\r\n}\r\n.intro{\r\n	font-weight:bold;\r\n	font-size:12px;}\r\n\r\n.acyfooter a{\r\n	color:#575757;}\r\n\r\n@media (min-width: 320px){\r\n	table[class=w600], td[class=w600]  { width:320px !important; }\r\n	table[class=w540], td[class=w540]  { width:260px !important; }\r\n	td[class=w30] { width:30px !important; }\r\n	.w600 img{max-width:320px; height:auto !important}\r\n	.w540 img{max-width:260px; height:auto !important}\r\n}\r\n\r\n@media (min-width: 480px){\r\n	table[class=w600], td[class=w600]  { width:480px !important; }\r\n	table[class=w540], td[class=w540]  { width:420px !important; }\r\n	td[class=w30] { width:30px !important; }\r\n	.w600 img{max-width:480px; height:auto !important}\r\n	.w540 img{max-width:420px; height:auto !important}\r\n}\r\n\r\n@media (min-width:600px){\r\n	table[class=w600], td[class=w600]  { width:600px !important; }\r\n	table[class=w540], td[class=w540]  { width:540px !important; }\r\n	td[class=w30] { width:30px !important; }\r\n	.w600 img{max-width:600px; height:auto !important}\r\n	.w540 img{max-width:540px; height:auto !important}\r\n}\r\n', NULL, NULL, NULL, NULL, 'media/com_acymailing/templates/newsletter-6/newsletter-6.png', '', 'all'),
(4, 'Technology', '', '<div align="center" style="width:100%; background-color:#575757; padding-bottom:20px; color:#999999;">\r\n<table align="center" border="0" cellpadding="0" cellspacing="0" class="w600" style="background-color:#fff; color:#999999; margin:auto" width="600">\r\n	<tbody>\r\n		<tr class="acyeditor_delete">\r\n			<td class="w30" style="background-color:#575757" width="30"></td>\r\n			<td class="acyeditor_text w540" style="text-align:right; color:#d2d1d1; background-color:#575757" width="540"><span class="acymailing_online">{readonline}If you can''t see this e-mail properly, <span style="text-decoration:underline">view it online</span>{/readonline}</span></td>\r\n			<td class="w30" style="background-color:#575757" width="30"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete">\r\n			<td class="acyeditor_picture w600" colspan="3" style="line-height:0px; background-color:#575757" valign="bottom" width="600"><img alt="--" src="media/com_acymailing/templates/technology_resp/images/shadowtop.jpg" /></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete">\r\n			<td class="acyeditor_picture w600" colspan="3" style="line-height:0px; background-color:#f5f5f5" width="600"><img alt="--" src="media/com_acymailing/templates/technology_resp/images/top.jpg" /></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete">\r\n			<td class="w30" height="32" style="background-color:#f5f5f5; border-bottom:1px solid #ddd" width="30"></td>\r\n			<td class="acyeditor_text links w540" style="background-color:#f5f5f5; border-bottom:1px solid #ddd; text-align:right; color:#ababab" width="540"><a href="#"><img alt="mail" src="media/com_acymailing/templates/technology_resp/images/mail.jpg" style="float:right; border:none" /></a> Newsletter {mailid} | {date:%B %Y} |&nbsp; <a href="#">www.acyba.com</a> |</td>\r\n			<td class="w30" height="32" style="background-color:#f5f5f5; border-bottom:1px solid #ddd" width="30"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete">\r\n			<td class="w600" colspan="3" height="16" width="600"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete">\r\n			<td class="w30" width="30"></td>\r\n			<td class="acyeditor_text w540" width="540"><img alt="picture" src="media/com_acymailing/templates/technology_resp/images/pic1.jpg" style="float:right" />\r\n			<h1>Fresh and technologic news !</h1>\r\n\r\n			<h3>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris massa quam, eleifend at ornare.</h3>\r\n			Liget, volutpat esvft sem. Praesent auctor posuere orci, sit amet molee. Integer nec scelerisque quam. Lore uctor posum ipsum dolor sit amesent auctor.</td>\r\n			<td class="w30" width="30"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete">\r\n			<td class="w30" style="background-color:#fafafa" width="30"></td>\r\n			<td class="acyeditor_picture w540" style="background-color:#fafafa; line-height:0px" width="540"><img alt="---" src="media/com_acymailing/templates/technology_resp/images/separator1.jpg" /></td>\r\n			<td class="w30" style="background-color:#fafafa" width="30"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete">\r\n			<td class="w30" style="background-color:#fafafa" width="30"></td>\r\n			<td class="acyeditor_text w540" style="background-color:#fafafa; color:#999999" width="540">\r\n			<h2>Choose your smartphone</h2>\r\n			<img alt="picture" src="media/com_acymailing/templates/technology_resp/images/pic2.jpg" style="float:left" />\r\n			<h3>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris massa quam, eleifend at ornare.</h3>\r\n			Liget, volutpat esvft sem. Praesent auctor posuere orci, sit amet molee. Integer nec<a href="#"> scelerisque quam</a>. Lore uctor posum ipsum dolor sit amesent auctor.<br />\r\n			<br />\r\n			<img alt="buy this product" src="media/com_acymailing/templates/technology_resp/images/buyproduct.jpg" /><br />\r\n			<br />\r\n			<br />\r\n			&nbsp;\r\n			<h2>Choose your device</h2>\r\n			<img alt="picture" src="media/com_acymailing/templates/technology_resp/images/pic3.jpg" style="float:right" />\r\n			<h3>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris massa quam, eleifend at ornare.</h3>\r\n			Liget, volutpat esvft sem. Praesent auctor posuere orci, sit amet molee. Integer nec scelerisque quam. Lore uctor posum ipsum dolor sit amesent auctor.<br />\r\n			<br />\r\n			<img alt="buy this product" src="media/com_acymailing/templates/technology_resp/images/buyproduct.jpg" /></td>\r\n			<td class="w30" style="background-color:#fafafa" width="30"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete" >\r\n			<td class="w30" style="background-color:#fafafa" width="30"></td>\r\n			<td class="acyeditor_picture w540" style="background-color:#fafafa; line-height:0px" width="540"><img alt="---" src="media/com_acymailing/templates/technology_resp/images/separator2.jpg" /></td>\r\n			<td class="w30" style="background-color:#fafafa" width="30"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete" >\r\n			<td class="w600" colspan="3" height="16" width="600"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete" >\r\n			<td class="w30" width="30"></td>\r\n			<td class="acyeditor_text special w540" style="color:#999999" width="540">\r\n			<h2>Best product of the month</h2>\r\n\r\n			<h3>Lorem ipsum dolor sit amet.</h3>\r\n			Liget, volutpat esvft sem. Praesent auctor posuere orci, sit amet molee. Integer nec scelerisque quam. Lore uctor posum ipsum doLiget, volutpat esvft sem. Praesent auctor posuere orci, sit amet molee. Integer nec scelerisque quam. Lore uctor posum ipsum dolor sit amesent.<br />\r\n			<br />\r\n			<img alt="read more" src="media/com_acymailing/templates/technology_resp/images/readmore.jpg" style="border:none" /></td>\r\n			<td class="w30" width="30"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete" >\r\n			<td class="w600" colspan="3" height="16" width="600"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete" >\r\n			<td class="w30" height="30" style="background-color:#f5f5f5; border-top:1px solid #ddd" width="30"></td>\r\n			<td class="acyeditor_text w540" height="30" style="background-color:#f5f5f5; border-top:1px solid #ddd; text-align:right; color:#ababab" valign="bottom" width="540">Follow us | <img alt="facebook" src="media/com_acymailing/templates/technology_resp/images/facebook.jpg" style="border:none" /> <img alt="twitter" src="media/com_acymailing/templates/technology_resp/images/twitter.jpg" style="border:none" /> <img alt="pinterest" src="media/com_acymailing/templates/technology_resp/images/pinterest.jpg" style="border:none" /> <img alt="rss" src="media/com_acymailing/templates/technology_resp/images/rss.jpg" style="border:none" /></td>\r\n			<td class="w30" height="30" style="background-color:#f5f5f5; border-top:1px solid #ddd" width="30"></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete" >\r\n			<td class="acyeditor_picture w600" colspan="3" style="line-height:0px; background-color:#f5f5f5" width="600"><img alt="--" src="media/com_acymailing/templates/technology_resp/images/bottom.jpg" /></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete" >\r\n			<td class="acyeditor_picture w600" colspan="3" style="line-height:0px; background-color:#575757" valign="bottom" width="600"><img alt="--" src="media/com_acymailing/templates/technology_resp/images/shadowbottom.jpg" /></td>\r\n		</tr>\r\n		<tr class="acyeditor_delete" >\r\n			<td class="w30" style="background-color:#575757" width="30"></td>\r\n			<td class="acyeditor_text w540" style="text-align:right; color:#d2d1d1; background-color:#575757" width="540"><span class="acymailing_unsub">{unsubscribe}If you don''t want to receive our news anymore, <span style="text-decoration:underline">unsubscribe</span>{/unsubscribe} </span></td>\r\n			<td class="w30" style="background-color:#575757" width="30"></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n</div>', '', NULL, 1, 0, 4, 'technology_resp', 'a:9:{s:6:"tag_h1";s:104:"font-size:20px; margin:0px; margin-bottom:15px; padding:0px; font-weight:bold; color:#01bbe5 !important;";s:6:"tag_h2";s:165:"font-size:12px; font-weight:bold; color:#565656 !important; text-transform:uppercase; margin:10px 0px; padding:0px; padding-bottom:5px; border-bottom:1px solid #ddd;";s:6:"tag_h3";s:104:"color:#565656 !important; font-weight:bold; font-size:12px; margin:0px; margin-bottom:10px; padding:0px;";s:6:"tag_h4";s:0:"";s:8:"color_bg";s:7:"#575757";s:5:"tag_a";s:62:"cursor:pointer;color:#01bbe5;text-decoration:none;border:none;";s:17:"acymailing_online";s:30:"color:#d2d1d1; cursor:pointer;";s:16:"acymailing_unsub";s:30:"color:#d2d1d1; cursor:pointer;";s:19:"acymailing_readmore";s:88:"cursor:pointer; font-weight:bold; color:#fff; background-color:#01bbe5; padding:2px 5px;";}', NULL, 'table, div, p {\r\n	font-family:Arial, Helvetica, sans-serif;\r\n	font-size:12px;\r\n}\r\np{margin:0px; padding:0px}\r\n\r\n.special h2{font-size:18px;\r\n	margin:0px;\r\n	margin-bottom:15px;\r\n	padding:0px;\r\n	font-weight:bold;\r\n	color:#01bbe5 !important;\r\n	text-transform:none;\r\n	border:none}\r\n\r\n.links a{color:#ababab}\r\n\r\n@media (min-width:320px){\r\n	table[class=w600], td[class=w600] { width:320px !important;}\r\n	table[class=w540], td[class=w540] { width:260px !important;}\r\n	td[class=w30] { width:30px !important;}\r\n	.w600 img {max-width:320px; height:auto !important}\r\n	.w540 img {max-width:260px; height:auto !important}\r\n}\r\n\r\n@media (min-width: 480px){\r\n	table[class=w600], td[class=w600] { width:480px !important;}\r\n	table[class=w540], td[class=w540] { width:420px !important;}\r\n	td[class=w30] { width:30px !important;}\r\n	.w600 img {max-width:480px; height:auto !important}\r\n	.w540 img {max-width:420px; height:auto !important}\r\n}\r\n\r\n@media (min-width:600px){\r\n	table[class=w600], td[class=w600] { width:600px !important;}\r\n	table[class=w540], td[class=w540] { width:540px !important;}\r\n	td[class=w30] { width:30px !important;}\r\n	.w600 img {max-width:600px; height:auto !important}\r\n	.w540 img {max-width:540px; height:auto !important}\r\n}\r\n', NULL, NULL, NULL, NULL, 'media/com_acymailing/templates/technology_resp/thumb.jpg', '', 'all');

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_url`
--

CREATE TABLE `sas_acymailing_url` (
  `urlid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`urlid`),
  KEY `url` (`url`(250))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_urlclick`
--

CREATE TABLE `sas_acymailing_urlclick` (
  `urlid` int(10) unsigned NOT NULL,
  `mailid` mediumint(8) unsigned NOT NULL,
  `click` smallint(5) unsigned NOT NULL DEFAULT '0',
  `subid` int(10) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL,
  `ip` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`urlid`,`mailid`,`subid`),
  KEY `dateindex` (`date`),
  KEY `mailidindex` (`mailid`),
  KEY `subidindex` (`subid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_acymailing_userstats`
--

CREATE TABLE `sas_acymailing_userstats` (
  `mailid` mediumint(8) unsigned NOT NULL,
  `subid` int(10) unsigned NOT NULL,
  `html` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `sent` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `senddate` int(10) unsigned NOT NULL,
  `open` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `opendate` int(11) NOT NULL,
  `bounce` tinyint(4) NOT NULL DEFAULT '0',
  `fail` tinyint(4) NOT NULL DEFAULT '0',
  `ip` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`mailid`,`subid`),
  KEY `senddateindex` (`senddate`),
  KEY `subidindex` (`subid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_ak_profiles`
--

CREATE TABLE `sas_ak_profiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `configuration` longtext,
  `filters` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table 'sas_ak_profiles'
--

INSERT INTO `sas_ak_profiles` VALUES
(1, 'Default Backup Profile', '', '');

-- --------------------------------------------------------

--
-- Table structure for table`sas_ak_stats`
--

CREATE TABLE `sas_ak_stats` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `comment` longtext,
  `backupstart` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `backupend` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` enum('run','fail','complete') NOT NULL DEFAULT 'run',
  `origin` varchar(30) NOT NULL DEFAULT 'backend',
  `type` varchar(30) NOT NULL DEFAULT 'full',
  `profile_id` bigint(20) NOT NULL DEFAULT '1',
  `archivename` longtext,
  `absolute_path` longtext,
  `multipart` int(11) NOT NULL DEFAULT '0',
  `tag` varchar(255) DEFAULT NULL,
  `filesexist` tinyint(3) NOT NULL DEFAULT '1',
  `remote_filename` varchar(1000) DEFAULT NULL,
  `total_size` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fullstatus` (`filesexist`,`status`),
  KEY `idx_stale` (`status`,`origin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_ak_storage`
--

CREATE TABLE `sas_ak_storage` (
  `tag` varchar(255) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data` longtext,
  PRIMARY KEY (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_assets`
--

CREATE TABLE `sas_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_asset_name` (`name`),
  KEY `idx_lft_rgt` (`lft`,`rgt`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=71 ;

--
-- Dumping data for table 'sas_assets'
--

INSERT INTO `sas_assets` VALUES
(1, 0, 0, 139, 0, 'root.1', 'Root Asset', '{"core.login.site":{"6":1,"2":1},"core.login.admin":{"6":1},"core.login.offline":{"6":1},"core.admin":{"8":1},"core.manage":{"7":1},"core.create":{"6":1,"3":1},"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(2, 1, 1, 2, 1, 'com_admin', 'com_admin', '{}'),
(3, 1, 3, 6, 1, 'com_banners', 'com_banners', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(4, 1, 7, 8, 1, 'com_cache', 'com_cache', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(5, 1, 9, 10, 1, 'com_checkin', 'com_checkin', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(6, 1, 11, 12, 1, 'com_config', 'com_config', '{}'),
(7, 1, 13, 16, 1, 'com_contact', 'com_contact', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(8, 1, 17, 20, 1, 'com_content', 'com_content', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(9, 1, 21, 22, 1, 'com_cpanel', 'com_cpanel', '{}'),
(10, 1, 23, 24, 1, 'com_installer', 'com_installer', '{"core.admin":[],"core.manage":{"7":0},"core.delete":{"7":0},"core.edit.state":{"7":0}}'),
(11, 1, 25, 26, 1, 'com_languages', 'com_languages', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(12, 1, 27, 28, 1, 'com_login', 'com_login', '{}'),
(13, 1, 29, 30, 1, 'com_mailto', 'com_mailto', '{}'),
(14, 1, 31, 32, 1, 'com_massmail', 'com_massmail', '{}'),
(15, 1, 33, 34, 1, 'com_media', 'com_media', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":{"5":1}}'),
(16, 1, 35, 36, 1, 'com_menus', 'com_menus', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(17, 1, 37, 38, 1, 'com_messages', 'com_messages', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(18, 1, 39, 88, 1, 'com_modules', 'com_modules', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(19, 1, 89, 92, 1, 'com_newsfeeds', 'com_newsfeeds', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(20, 1, 93, 94, 1, 'com_plugins', 'com_plugins', '{"core.admin":{"7":1},"core.manage":[],"core.edit":[],"core.edit.state":[]}'),
(21, 1, 95, 96, 1, 'com_redirect', 'com_redirect', '{"core.admin":{"7":1},"core.manage":[]}'),
(22, 1, 97, 98, 1, 'com_search', 'com_search', '{"core.admin":{"7":1},"core.manage":{"6":1}}'),
(23, 1, 99, 100, 1, 'com_templates', 'com_templates', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(24, 1, 101, 104, 1, 'com_users', 'com_users', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(25, 1, 105, 108, 1, 'com_weblinks', 'com_weblinks', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(26, 1, 109, 110, 1, 'com_wrapper', 'com_wrapper', '{}'),
(27, 8, 18, 19, 2, 'com_content.category.2', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(28, 3, 4, 5, 2, 'com_banners.category.3', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(29, 7, 14, 15, 2, 'com_contact.category.4', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(30, 19, 90, 91, 2, 'com_newsfeeds.category.5', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(31, 25, 106, 107, 2, 'com_weblinks.category.6', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(32, 24, 102, 103, 1, 'com_users.category.7', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(33, 1, 111, 112, 1, 'com_finder', 'com_finder', '{"core.admin":{"7":1},"core.manage":{"6":1}}'),
(34, 1, 113, 114, 1, 'com_joomlaupdate', 'com_joomlaupdate', '{"core.admin":[],"core.manage":[],"core.delete":[],"core.edit.state":[]}'),
(35, 1, 115, 116, 1, 'com_tags', 'com_tags', '{"core.admin":[],"core.manage":[],"core.manage":[],"core.delete":[],"core.edit.state":[]}'),
(36, 1, 117, 118, 1, 'com_contenthistory', 'com_contenthistory', '{}'),
(37, 1, 119, 120, 1, 'com_ajax', 'com_ajax', '{}'),
(38, 1, 121, 122, 1, 'com_postinstall', 'com_postinstall', '{}'),
(39, 18, 40, 41, 2, 'com_modules.module.1', 'Main Menu', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(40, 18, 42, 43, 2, 'com_modules.module.2', 'Login', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(41, 18, 44, 45, 2, 'com_modules.module.3', 'Popular Articles', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(42, 18, 46, 47, 2, 'com_modules.module.4', 'Recently Added Articles', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(43, 18, 48, 49, 2, 'com_modules.module.8', 'Toolbar', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(44, 18, 50, 51, 2, 'com_modules.module.9', 'Quick Icons', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(45, 18, 52, 53, 2, 'com_modules.module.10', 'Logged-in Users', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(46, 18, 54, 55, 2, 'com_modules.module.12', 'Admin Menu', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(47, 18, 56, 57, 2, 'com_modules.module.13', 'Admin Submenu', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(48, 18, 58, 59, 2, 'com_modules.module.14', 'User Status', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(49, 18, 60, 61, 2, 'com_modules.module.15', 'Title', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(50, 18, 62, 63, 2, 'com_modules.module.16', 'Login Form', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(51, 18, 64, 65, 2, 'com_modules.module.17', 'Breadcrumbs', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(52, 18, 66, 67, 2, 'com_modules.module.79', 'Multilanguage status', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(53, 18, 68, 69, 2, 'com_modules.module.86', 'Joomla Version', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(54, 1, 123, 124, 1, 'com_jce', 'jce', '{}'),
(55, 1, 125, 126, 1, 'com_akeeba', 'akeeba', '{}'),
(56, 1, 127, 128, 1, 'com_k2', 'com_k2', '{}'),
(57, 18, 70, 71, 2, 'com_modules.module.87', 'K2 Comments', ''),
(58, 18, 72, 73, 2, 'com_modules.module.88', 'K2 Content', ''),
(59, 18, 74, 75, 2, 'com_modules.module.89', 'K2 Tools', ''),
(60, 18, 76, 77, 2, 'com_modules.module.90', 'K2 Users', ''),
(61, 18, 78, 79, 2, 'com_modules.module.91', 'K2 User', ''),
(62, 18, 80, 81, 2, 'com_modules.module.92', 'K2 Quick Icons (admin)', ''),
(63, 18, 82, 83, 2, 'com_modules.module.93', 'K2 Stats (admin)', ''),
(64, 1, 129, 130, 1, 'com_flexbanners', 'flexbanners', '{}'),
(65, 18, 84, 85, 2, 'com_modules.module.94', 'FlexBanners', ''),
(66, 1, 131, 132, 1, 'com_sobipro', 'sobipro', '{}'),
(67, 1, 133, 134, 1, 'com_acymailing', 'acymailing', '{}'),
(68, 18, 86, 87, 2, 'com_modules.module.96', 'ContentMap', ''),
(69, 1, 135, 136, 1, 'com_contentmap', 'com_contentmap', '{}'),
(70, 1, 137, 138, 1, 'com_feedgator', 'feedgator', '{}');

-- --------------------------------------------------------

--
-- Table structure for table`sas_associations`
--

CREATE TABLE `sas_associations` (
  `id` int(11) NOT NULL COMMENT 'A reference to the associated item.',
  `context` varchar(50) NOT NULL COMMENT 'The context of the associated item.',
  `key` char(32) NOT NULL COMMENT 'The key for the association computed from an md5 on associated ids.',
  PRIMARY KEY (`context`,`id`),
  KEY `idx_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_banners`
--

CREATE TABLE `sas_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `custombannercode` varchar(2048) NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `params` text NOT NULL,
  `own_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reset` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` char(7) NOT NULL DEFAULT '',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`),
  KEY `idx_banner_catid` (`catid`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_banner_clients`
--

CREATE TABLE `sas_banner_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `metakey` text NOT NULL,
  `own_prefix` tinyint(4) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_banner_tracks`
--

CREATE TABLE `sas_banner_tracks` (
  `track_date` datetime NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`track_date`,`track_type`,`banner_id`),
  KEY `idx_track_date` (`track_date`),
  KEY `idx_track_type` (`track_type`),
  KEY `idx_banner_id` (`banner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_categories`
--

CREATE TABLE `sas_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `extension` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`extension`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table 'sas_categories'
--

INSERT INTO `sas_categories` VALUES
(1, 0, 0, 0, 13, 0, '', 'system', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '{}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(2, 27, 1, 1, 2, 1, 'uncategorised', 'com_content', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(3, 28, 1, 3, 4, 1, 'uncategorised', 'com_banners', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(4, 29, 1, 5, 6, 1, 'uncategorised', 'com_contact', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(5, 30, 1, 7, 8, 1, 'uncategorised', 'com_newsfeeds', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(6, 31, 1, 9, 10, 1, 'uncategorised', 'com_weblinks', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(7, 32, 1, 11, 12, 1, 'uncategorised', 'com_users', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1);

-- --------------------------------------------------------

--
-- Table structure for table`sas_contact_details`
--

CREATE TABLE `sas_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  `sortname1` varchar(255) NOT NULL,
  `sortname2` varchar(255) NOT NULL,
  `sortname3` varchar(255) NOT NULL,
  `language` char(7) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_content`
--

CREATE TABLE `sas_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` varchar(5120) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `language` char(7) NOT NULL COMMENT 'The language code for the article.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_contentitem_tag_map`
--

CREATE TABLE `sas_contentitem_tag_map` (
  `type_alias` varchar(255) NOT NULL DEFAULT '',
  `core_content_id` int(10) unsigned NOT NULL COMMENT 'PK from the core content table',
  `content_item_id` int(11) NOT NULL COMMENT 'PK from the content type table',
  `tag_id` int(10) unsigned NOT NULL COMMENT 'PK from the tag table',
  `tag_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date of most recent save for this tag-item',
  `type_id` mediumint(8) NOT NULL COMMENT 'PK from the content_type table',
  UNIQUE KEY `uc_ItemnameTagid` (`type_id`,`content_item_id`,`tag_id`),
  KEY `idx_tag_type` (`tag_id`,`type_id`),
  KEY `idx_date_id` (`tag_date`,`tag_id`),
  KEY `idx_tag` (`tag_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_core_content_id` (`core_content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Maps items from content tables to tags';

-- --------------------------------------------------------

--
-- Table structure for table`sas_content_frontpage`
--

CREATE TABLE `sas_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_content_rating`
--

CREATE TABLE `sas_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(10) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_content_types`
--

CREATE TABLE `sas_content_types` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_title` varchar(255) NOT NULL DEFAULT '',
  `type_alias` varchar(255) NOT NULL DEFAULT '',
  `table` varchar(255) NOT NULL DEFAULT '',
  `rules` text NOT NULL,
  `field_mappings` text NOT NULL,
  `router` varchar(255) NOT NULL DEFAULT '',
  `content_history_options` varchar(5120) DEFAULT NULL COMMENT 'JSON string for com_contenthistory options',
  PRIMARY KEY (`type_id`),
  KEY `idx_alias` (`type_alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10000 ;

--
-- Dumping data for table 'sas_content_types'
--

INSERT INTO `sas_content_types` VALUES
(1, 'Article', 'com_content.article', '{"special":{"dbtable":"#__content","key":"id","type":"Content","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"state","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"introtext", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"attribs", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"urls", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"asset_id"}, "special":{"fulltext":"fulltext"}}', 'ContentHelperRoute::getArticleRoute', '{"formFile":"administrator\\/components\\/com_content\\/models\\/forms\\/article.xml", "hideFields":["asset_id","checked_out","checked_out_time","version"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"],"convertToInt":["publish_up", "publish_down", "featured", "ordering"],"displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(2, 'Weblink', 'com_weblinks.weblink', '{"special":{"dbtable":"#__weblinks","key":"id","type":"Weblink","prefix":"WeblinksTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"state","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"description", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"urls", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"null"}, "special":{}}', 'WeblinksHelperRoute::getWeblinkRoute', '{"formFile":"administrator\\/components\\/com_weblinks\\/models\\/forms\\/weblink.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","featured","images"], "ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"], "convertToInt":["publish_up", "publish_down", "featured", "ordering"], "displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(3, 'Contact', 'com_contact.contact', '{"special":{"dbtable":"#__contact_details","key":"id","type":"Contact","prefix":"ContactTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"address", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"image", "core_urls":"webpage", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"null"}, "special":{"con_position":"con_position","suburb":"suburb","state":"state","country":"country","postcode":"postcode","telephone":"telephone","fax":"fax","misc":"misc","email_to":"email_to","default_con":"default_con","user_id":"user_id","mobile":"mobile","sortname1":"sortname1","sortname2":"sortname2","sortname3":"sortname3"}}', 'ContactHelperRoute::getContactRoute', '{"formFile":"administrator\\/components\\/com_contact\\/models\\/forms\\/contact.xml","hideFields":["default_con","checked_out","checked_out_time","version","xreference"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"],"convertToInt":["publish_up", "publish_down", "featured", "ordering"], "displayLookup":[ {"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ] }'),
(4, 'Newsfeed', 'com_newsfeeds.newsfeed', '{"special":{"dbtable":"#__newsfeeds","key":"id","type":"Newsfeed","prefix":"NewsfeedsTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"description", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"link", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"null"}, "special":{"numarticles":"numarticles","cache_time":"cache_time","rtl":"rtl"}}', 'NewsfeedsHelperRoute::getNewsfeedRoute', '{"formFile":"administrator\\/components\\/com_newsfeeds\\/models\\/forms\\/newsfeed.xml","hideFields":["asset_id","checked_out","checked_out_time","version"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"],"convertToInt":["publish_up", "publish_down", "featured", "ordering"],"displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(5, 'User', 'com_users.user', '{"special":{"dbtable":"#__users","key":"id","type":"User","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"null","core_alias":"username","core_created_time":"registerdate","core_modified_time":"lastvisitDate","core_body":"null", "core_hits":"null","core_publish_up":"null","core_publish_down":"null","access":"null", "core_params":"params", "core_featured":"null", "core_metadata":"null", "core_language":"null", "core_images":"null", "core_urls":"null", "core_version":"null", "core_ordering":"null", "core_metakey":"null", "core_metadesc":"null", "core_catid":"null", "core_xreference":"null", "asset_id":"null"}, "special":{}}', 'UsersHelperRoute::getUserRoute', ''),
(6, 'Article Category', 'com_content.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'ContentHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(7, 'Contact Category', 'com_contact.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'ContactHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(8, 'Newsfeeds Category', 'com_newsfeeds.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'NewsfeedsHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(9, 'Weblinks Category', 'com_weblinks.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'WeblinksHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(10, 'Tag', 'com_tags.tag', '{"special":{"dbtable":"#__tags","key":"tag_id","type":"Tag","prefix":"TagsTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"urls", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"null", "core_xreference":"null", "asset_id":"null"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path"}}', 'TagsHelperRoute::getTagRoute', '{"formFile":"administrator\\/components\\/com_tags\\/models\\/forms\\/tag.xml", "hideFields":["checked_out","checked_out_time","version", "lft", "rgt", "level", "path", "urls", "publish_up", "publish_down"],"ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"}, {"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}]}'),
(11, 'Banner', 'com_banners.banner', '{"special":{"dbtable":"#__banners","key":"id","type":"Banner","prefix":"BannersTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"description", "core_hits":"null","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"link", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"null", "asset_id":"null"}, "special":{"imptotal":"imptotal", "impmade":"impmade", "clicks":"clicks", "clickurl":"clickurl", "custombannercode":"custombannercode", "cid":"cid", "purchase_type":"purchase_type", "track_impressions":"track_impressions", "track_clicks":"track_clicks"}}', '', '{"formFile":"administrator\\/components\\/com_banners\\/models\\/forms\\/banner.xml", "hideFields":["checked_out","checked_out_time","version", "reset"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "imptotal", "impmade", "reset"], "convertToInt":["publish_up", "publish_down", "ordering"], "displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}, {"sourceColumn":"cid","targetTable":"#__banner_clients","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(12, 'Banners Category', 'com_banners.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special": {"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', '', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"], "convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(13, 'Banner Client', 'com_banners.client', '{"special":{"dbtable":"#__banner_clients","key":"id","type":"Client","prefix":"BannersTable"}}', '', '', '', '{"formFile":"administrator\\/components\\/com_banners\\/models\\/forms\\/client.xml", "hideFields":["checked_out","checked_out_time"], "ignoreChanges":["checked_out", "checked_out_time"], "convertToInt":[], "displayLookup":[]}'),
(14, 'User Notes', 'com_users.note', '{"special":{"dbtable":"#__user_notes","key":"id","type":"Note","prefix":"UsersTable"}}', '', '', '', '{"formFile":"administrator\\/components\\/com_users\\/models\\/forms\\/note.xml", "hideFields":["checked_out","checked_out_time", "publish_up", "publish_down"],"ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time"], "convertToInt":["publish_up", "publish_down"],"displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}, {"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}]}'),
(15, 'User Notes Category', 'com_users.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', '', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"], "convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}');

-- --------------------------------------------------------

--
-- Table structure for table`sas_core_log_searches`
--

CREATE TABLE `sas_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_extensions`
--

CREATE TABLE `sas_extensions` (
  `extension_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `element` varchar(100) NOT NULL,
  `folder` varchar(100) NOT NULL,
  `client_id` tinyint(3) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `protected` tinyint(3) NOT NULL DEFAULT '0',
  `manifest_cache` text NOT NULL,
  `params` text NOT NULL,
  `custom_data` text NOT NULL,
  `system_data` text NOT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`extension_id`),
  KEY `element_clientid` (`element`,`client_id`),
  KEY `element_folder_clientid` (`element`,`folder`,`client_id`),
  KEY `extension` (`type`,`element`,`folder`,`client_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10053 ;

--
-- Dumping data for table 'sas_extensions'
--

INSERT INTO `sas_extensions` VALUES
(1, 'com_mailto', 'component', 'com_mailto', '', 0, 1, 1, 1, '{"name":"com_mailto","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MAILTO_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(2, 'com_wrapper', 'component', 'com_wrapper', '', 0, 1, 1, 1, '{"name":"com_wrapper","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_WRAPPER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(3, 'com_admin', 'component', 'com_admin', '', 1, 1, 1, 1, '{"name":"com_admin","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_ADMIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(4, 'com_banners', 'component', 'com_banners', '', 1, 1, 1, 0, '{"name":"com_banners","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_BANNERS_XML_DESCRIPTION","group":""}', '{"purchase_type":"3","track_impressions":"0","track_clicks":"0","metakey_prefix":"","save_history":"1","history_limit":10}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(5, 'com_cache', 'component', 'com_cache', '', 1, 1, 1, 1, '{"name":"com_cache","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CACHE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(6, 'com_categories', 'component', 'com_categories', '', 1, 1, 1, 1, '{"name":"com_categories","type":"component","creationDate":"December 2007","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CATEGORIES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(7, 'com_checkin', 'component', 'com_checkin', '', 1, 1, 1, 1, '{"name":"com_checkin","type":"component","creationDate":"Unknown","author":"Joomla! Project","copyright":"(C) 2005 - 2008 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CHECKIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(8, 'com_contact', 'component', 'com_contact', '', 1, 1, 1, 0, '{"name":"com_contact","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CONTACT_XML_DESCRIPTION","group":""}', '{"show_contact_category":"hide","save_history":"1","history_limit":10,"show_contact_list":"0","presentation_style":"sliders","show_name":"1","show_position":"1","show_email":"0","show_street_address":"1","show_suburb":"1","show_state":"1","show_postcode":"1","show_country":"1","show_telephone":"1","show_mobile":"1","show_fax":"1","show_webpage":"1","show_misc":"1","show_image":"1","image":"","allow_vcard":"0","show_articles":"0","show_profile":"0","show_links":"0","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","contact_icons":"0","icon_address":"","icon_email":"","icon_telephone":"","icon_mobile":"","icon_fax":"","icon_misc":"","show_headings":"1","show_position_headings":"1","show_email_headings":"0","show_telephone_headings":"1","show_mobile_headings":"0","show_fax_headings":"0","allow_vcard_headings":"0","show_suburb_headings":"1","show_state_headings":"1","show_country_headings":"1","show_email_form":"1","show_email_copy":"1","banned_email":"","banned_subject":"","banned_text":"","validate_session":"1","custom_reply":"0","redirect":"","show_category_crumb":"0","metakey":"","metadesc":"","robots":"","author":"","rights":"","xreference":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(9, 'com_cpanel', 'component', 'com_cpanel', '', 1, 1, 1, 1, '{"name":"com_cpanel","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CPANEL_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10, 'com_installer', 'component', 'com_installer', '', 1, 1, 1, 1, '{"name":"com_installer","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_INSTALLER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(11, 'com_languages', 'component', 'com_languages', '', 1, 1, 1, 1, '{"name":"com_languages","type":"component","creationDate":"2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_LANGUAGES_XML_DESCRIPTION","group":""}', '{"administrator":"en-GB","site":"en-GB"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(12, 'com_login', 'component', 'com_login', '', 1, 1, 1, 1, '{"name":"com_login","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(13, 'com_media', 'component', 'com_media', '', 1, 1, 0, 1, '{"name":"com_media","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MEDIA_XML_DESCRIPTION","group":""}', '{"upload_extensions":"bmp,csv,doc,gif,ico,jpg,jpeg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,GIF,ICO,JPG,JPEG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS","upload_maxsize":"10","file_path":"images","image_path":"images","restrict_uploads":"1","allowed_media_usergroup":"3","check_mime":"1","image_extensions":"bmp,gif,jpg,png","ignore_extensions":"","upload_mime":"image\\/jpeg,image\\/gif,image\\/png,image\\/bmp,application\\/x-shockwave-flash,application\\/msword,application\\/excel,application\\/pdf,application\\/powerpoint,text\\/plain,application\\/x-zip","upload_mime_illegal":"text\\/html"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(14, 'com_menus', 'component', 'com_menus', '', 1, 1, 1, 1, '{"name":"com_menus","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MENUS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(15, 'com_messages', 'component', 'com_messages', '', 1, 1, 1, 1, '{"name":"com_messages","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MESSAGES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(16, 'com_modules', 'component', 'com_modules', '', 1, 1, 1, 1, '{"name":"com_modules","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MODULES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(17, 'com_newsfeeds', 'component', 'com_newsfeeds', '', 1, 1, 1, 0, '{"name":"com_newsfeeds","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_NEWSFEEDS_XML_DESCRIPTION","group":""}', '{"newsfeed_layout":"_:default","save_history":"1","history_limit":5,"show_feed_image":"1","show_feed_description":"1","show_item_description":"1","feed_character_count":"0","feed_display_order":"des","float_first":"right","float_second":"right","show_tags":"1","category_layout":"_:default","show_category_title":"1","show_description":"1","show_description_image":"1","maxLevel":"-1","show_empty_categories":"0","show_subcat_desc":"1","show_cat_items":"1","show_cat_tags":"1","show_base_description":"1","maxLevelcat":"-1","show_empty_categories_cat":"0","show_subcat_desc_cat":"1","show_cat_items_cat":"1","filter_field":"1","show_pagination_limit":"1","show_headings":"1","show_articles":"0","show_link":"1","show_pagination":"1","show_pagination_results":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(18, 'com_plugins', 'component', 'com_plugins', '', 1, 1, 1, 1, '{"name":"com_plugins","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_PLUGINS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(19, 'com_search', 'component', 'com_search', '', 1, 1, 1, 0, '{"name":"com_search","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_SEARCH_XML_DESCRIPTION","group":""}', '{"enabled":"0","show_date":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(20, 'com_templates', 'component', 'com_templates', '', 1, 1, 1, 1, '{"name":"com_templates","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_TEMPLATES_XML_DESCRIPTION","group":""}', '{"template_positions_display":"0","upload_limit":"2","image_formats":"gif,bmp,jpg,jpeg,png","source_formats":"txt,less,ini,xml,js,php,css","font_formats":"woff,ttf,otf","compressed_formats":"zip"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(21, 'com_weblinks', 'component', 'com_weblinks', '', 1, 1, 1, 0, '{"name":"com_weblinks","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_WEBLINKS_XML_DESCRIPTION","group":""}', '{"target":"0","save_history":"1","history_limit":5,"count_clicks":"1","icons":1,"link_icons":"","float_first":"right","float_second":"right","show_tags":"1","category_layout":"_:default","show_category_title":"1","show_description":"1","show_description_image":"1","maxLevel":"-1","show_empty_categories":"0","show_subcat_desc":"1","show_cat_num_links":"1","show_cat_tags":"1","show_base_description":"1","maxLevelcat":"-1","show_empty_categories_cat":"0","show_subcat_desc_cat":"1","show_cat_num_links_cat":"1","filter_field":"1","show_pagination_limit":"1","show_headings":"0","show_link_description":"1","show_link_hits":"1","show_pagination":"2","show_pagination_results":"1","show_feed_link":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(22, 'com_content', 'component', 'com_content', '', 1, 1, 0, 1, '{"name":"com_content","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CONTENT_XML_DESCRIPTION","group":""}', '{"article_layout":"_:default","show_title":"1","link_titles":"1","show_intro":"1","show_category":"1","link_category":"1","show_parent_category":"0","link_parent_category":"0","show_author":"1","link_author":"0","show_create_date":"0","show_modify_date":"0","show_publish_date":"1","show_item_navigation":"1","show_vote":"0","show_readmore":"1","show_readmore_title":"1","readmore_limit":"100","show_icons":"1","show_print_icon":"1","show_email_icon":"1","show_hits":"1","show_noauth":"0","show_publishing_options":"1","show_article_options":"1","save_history":"1","history_limit":10,"show_urls_images_frontend":"0","show_urls_images_backend":"1","targeta":0,"targetb":0,"targetc":0,"float_intro":"left","float_fulltext":"left","category_layout":"_:blog","show_category_title":"0","show_description":"0","show_description_image":"0","maxLevel":"1","show_empty_categories":"0","show_no_articles":"1","show_subcat_desc":"1","show_cat_num_articles":"0","show_base_description":"1","maxLevelcat":"-1","show_empty_categories_cat":"0","show_subcat_desc_cat":"1","show_cat_num_articles_cat":"1","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"0","show_subcategory_content":"0","show_pagination_limit":"1","filter_field":"hide","show_headings":"1","list_show_date":"0","date_format":"","list_show_hits":"1","list_show_author":"1","orderby_pri":"order","orderby_sec":"rdate","order_date":"published","show_pagination":"2","show_pagination_results":"1","show_feed_link":"1","feed_summary":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(23, 'com_config', 'component', 'com_config', '', 1, 1, 0, 1, '{"name":"com_config","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CONFIG_XML_DESCRIPTION","group":""}', '{"filters":{"1":{"filter_type":"NH","filter_tags":"","filter_attributes":""},"9":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"6":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"7":{"filter_type":"NONE","filter_tags":"","filter_attributes":""},"2":{"filter_type":"NH","filter_tags":"","filter_attributes":""},"3":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"4":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"5":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"8":{"filter_type":"NONE","filter_tags":"","filter_attributes":""}}}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(24, 'com_redirect', 'component', 'com_redirect', '', 1, 1, 0, 1, '{"name":"com_redirect","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_REDIRECT_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(25, 'com_users', 'component', 'com_users', '', 1, 1, 0, 1, '{"name":"com_users","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_USERS_XML_DESCRIPTION","group":""}', '{"allowUserRegistration":"1","new_usertype":"2","guest_usergroup":"9","sendpassword":"1","useractivation":"1","mail_to_admin":"0","captcha":"","frontend_userparams":"1","site_language":"0","change_login_name":"0","reset_count":"10","reset_time":"1","minimum_length":"4","minimum_integers":"0","minimum_symbols":"0","minimum_uppercase":"0","save_history":"1","history_limit":5,"mailSubjectPrefix":"","mailBodySuffix":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(27, 'com_finder', 'component', 'com_finder', '', 1, 1, 0, 0, '{"name":"com_finder","type":"component","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_FINDER_XML_DESCRIPTION","group":""}', '{"show_description":"1","description_length":255,"allow_empty_query":"0","show_url":"1","show_advanced":"1","expand_advanced":"0","show_date_filters":"0","highlight_terms":"1","opensearch_name":"","opensearch_description":"","batch_size":"50","memory_table_limit":30000,"title_multiplier":"1.7","text_multiplier":"0.7","meta_multiplier":"1.2","path_multiplier":"2.0","misc_multiplier":"0.3","stemmer":"snowball"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(28, 'com_joomlaupdate', 'component', 'com_joomlaupdate', '', 1, 1, 0, 1, '{"name":"com_joomlaupdate","type":"component","creationDate":"February 2012","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_JOOMLAUPDATE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(29, 'com_tags', 'component', 'com_tags', '', 1, 1, 1, 1, '{"name":"com_tags","type":"component","creationDate":"December 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.0","description":"COM_TAGS_XML_DESCRIPTION","group":""}', '{"tag_layout":"_:default","save_history":"1","history_limit":5,"show_tag_title":"0","tag_list_show_tag_image":"0","tag_list_show_tag_description":"0","tag_list_image":"","show_tag_num_items":"0","tag_list_orderby":"title","tag_list_orderby_direction":"ASC","show_headings":"0","tag_list_show_date":"0","tag_list_show_item_image":"0","tag_list_show_item_description":"0","tag_list_item_maximum_characters":0,"return_any_or_all":"1","include_children":"0","maximum":200,"tag_list_language_filter":"all","tags_layout":"_:default","all_tags_orderby":"title","all_tags_orderby_direction":"ASC","all_tags_show_tag_image":"0","all_tags_show_tag_descripion":"0","all_tags_tag_maximum_characters":20,"all_tags_show_tag_hits":"0","filter_field":"1","show_pagination_limit":"1","show_pagination":"2","show_pagination_results":"1","tag_field_ajax_mode":"1","show_feed_link":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(30, 'com_contenthistory', 'component', 'com_contenthistory', '', 1, 1, 1, 0, '{"name":"com_contenthistory","type":"component","creationDate":"May 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"COM_CONTENTHISTORY_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(31, 'com_ajax', 'component', 'com_ajax', '', 1, 1, 1, 0, '{"name":"com_ajax","type":"component","creationDate":"August 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"COM_AJAX_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(32, 'com_postinstall', 'component', 'com_postinstall', '', 1, 1, 1, 1, '{"name":"com_postinstall","type":"component","creationDate":"September 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"COM_POSTINSTALL_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(100, 'PHPMailer', 'library', 'phpmailer', '', 0, 1, 1, 1, '{"name":"PHPMailer","type":"library","creationDate":"2001","author":"PHPMailer","copyright":"(c) 2001-2003, Brent R. Matzelle, (c) 2004-2009, Andy Prevost. All Rights Reserved., (c) 2010-2013, Jim Jagielski. All Rights Reserved.","authorEmail":"jimjag@gmail.com","authorUrl":"https:\\/\\/github.com\\/PHPMailer\\/PHPMailer","version":"5.2.6","description":"LIB_PHPMAILER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(101, 'SimplePie', 'library', 'simplepie', '', 0, 1, 1, 1, '{"name":"SimplePie","type":"library","creationDate":"2004","author":"SimplePie","copyright":"Copyright (c) 2004-2009, Ryan Parman and Geoffrey Sneddon","authorEmail":"","authorUrl":"http:\\/\\/simplepie.org\\/","version":"1.2","description":"LIB_SIMPLEPIE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(102, 'phputf8', 'library', 'phputf8', '', 0, 1, 1, 1, '{"name":"phputf8","type":"library","creationDate":"2006","author":"Harry Fuecks","copyright":"Copyright various authors","authorEmail":"hfuecks@gmail.com","authorUrl":"http:\\/\\/sourceforge.net\\/projects\\/phputf8","version":"0.5","description":"LIB_PHPUTF8_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(103, 'Joomla! Platform', 'library', 'joomla', '', 0, 1, 1, 1, '{"name":"Joomla! Platform","type":"library","creationDate":"2008","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"http:\\/\\/www.joomla.org","version":"13.1","description":"LIB_JOOMLA_XML_DESCRIPTION","group":""}', '{"mediaversion":"02082bda9a8a6b89614ffcd914db1e34"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(104, 'IDNA Convert', 'library', 'idna_convert', '', 0, 1, 1, 1, '{"name":"IDNA Convert","type":"library","creationDate":"2004","author":"phlyLabs","copyright":"2004-2011 phlyLabs Berlin, http:\\/\\/phlylabs.de","authorEmail":"phlymail@phlylabs.de","authorUrl":"http:\\/\\/phlylabs.de","version":"0.8.0","description":"LIB_IDNA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(105, 'FOF', 'library', 'fof', '', 0, 1, 1, 1, '{"name":"FOF","type":"library","creationDate":"2013-12-14","author":"Nicholas K. Dionysopoulos \\/ Akeeba Ltd","copyright":"(C)2011-2013 Nicholas K. Dionysopoulos","authorEmail":"nicholas@akeebabackup.com","authorUrl":"https:\\/\\/www.akeebabackup.com","version":"2.1.1","description":"LIB_FOF_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(106, 'PHPass', 'library', 'phpass', '', 0, 1, 1, 1, '{"name":"PHPass","type":"library","creationDate":"2004-2006","author":"Solar Designer","copyright":"","authorEmail":"solar@openwall.com","authorUrl":"http:\\/\\/www.openwall.com\\/phpass\\/","version":"0.3","description":"LIB_PHPASS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(200, 'mod_articles_archive', 'module', 'mod_articles_archive', '', 0, 1, 1, 0, '{"name":"mod_articles_archive","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters.\\n\\t\\tAll rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(201, 'mod_articles_latest', 'module', 'mod_articles_latest', '', 0, 1, 1, 0, '{"name":"mod_articles_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LATEST_NEWS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(202, 'mod_articles_popular', 'module', 'mod_articles_popular', '', 0, 1, 1, 0, '{"name":"mod_articles_popular","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(203, 'mod_banners', 'module', 'mod_banners', '', 0, 1, 1, 0, '{"name":"mod_banners","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_BANNERS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(204, 'mod_breadcrumbs', 'module', 'mod_breadcrumbs', '', 0, 1, 1, 1, '{"name":"mod_breadcrumbs","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_BREADCRUMBS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(205, 'mod_custom', 'module', 'mod_custom', '', 0, 1, 1, 1, '{"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(206, 'mod_feed', 'module', 'mod_feed', '', 0, 1, 1, 0, '{"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FEED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(207, 'mod_footer', 'module', 'mod_footer', '', 0, 1, 1, 0, '{"name":"mod_footer","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FOOTER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(208, 'mod_login', 'module', 'mod_login', '', 0, 1, 1, 1, '{"name":"mod_login","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(209, 'mod_menu', 'module', 'mod_menu', '', 0, 1, 1, 1, '{"name":"mod_menu","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_MENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(210, 'mod_articles_news', 'module', 'mod_articles_news', '', 0, 1, 1, 0, '{"name":"mod_articles_news","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_NEWS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(211, 'mod_random_image', 'module', 'mod_random_image', '', 0, 1, 1, 0, '{"name":"mod_random_image","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_RANDOM_IMAGE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(212, 'mod_related_items', 'module', 'mod_related_items', '', 0, 1, 1, 0, '{"name":"mod_related_items","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_RELATED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(213, 'mod_search', 'module', 'mod_search', '', 0, 1, 1, 0, '{"name":"mod_search","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_SEARCH_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(214, 'mod_stats', 'module', 'mod_stats', '', 0, 1, 1, 0, '{"name":"mod_stats","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_STATS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(215, 'mod_syndicate', 'module', 'mod_syndicate', '', 0, 1, 1, 1, '{"name":"mod_syndicate","type":"module","creationDate":"May 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_SYNDICATE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(216, 'mod_users_latest', 'module', 'mod_users_latest', '', 0, 1, 1, 0, '{"name":"mod_users_latest","type":"module","creationDate":"December 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_USERS_LATEST_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(217, 'mod_weblinks', 'module', 'mod_weblinks', '', 0, 1, 1, 0, '{"name":"mod_weblinks","type":"module","creationDate":"July 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_WEBLINKS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(218, 'mod_whosonline', 'module', 'mod_whosonline', '', 0, 1, 1, 0, '{"name":"mod_whosonline","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_WHOSONLINE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(219, 'mod_wrapper', 'module', 'mod_wrapper', '', 0, 1, 1, 0, '{"name":"mod_wrapper","type":"module","creationDate":"October 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_WRAPPER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(220, 'mod_articles_category', 'module', 'mod_articles_category', '', 0, 1, 1, 0, '{"name":"mod_articles_category","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_CATEGORY_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(221, 'mod_articles_categories', 'module', 'mod_articles_categories', '', 0, 1, 1, 0, '{"name":"mod_articles_categories","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(222, 'mod_languages', 'module', 'mod_languages', '', 0, 1, 1, 1, '{"name":"mod_languages","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LANGUAGES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(223, 'mod_finder', 'module', 'mod_finder', '', 0, 1, 0, 0, '{"name":"mod_finder","type":"module","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FINDER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(300, 'mod_custom', 'module', 'mod_custom', '', 1, 1, 1, 1, '{"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(301, 'mod_feed', 'module', 'mod_feed', '', 1, 1, 1, 0, '{"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FEED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(302, 'mod_latest', 'module', 'mod_latest', '', 1, 1, 1, 0, '{"name":"mod_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LATEST_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(303, 'mod_logged', 'module', 'mod_logged', '', 1, 1, 1, 0, '{"name":"mod_logged","type":"module","creationDate":"January 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LOGGED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(304, 'mod_login', 'module', 'mod_login', '', 1, 1, 1, 1, '{"name":"mod_login","type":"module","creationDate":"March 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(305, 'mod_menu', 'module', 'mod_menu', '', 1, 1, 1, 0, '{"name":"mod_menu","type":"module","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_MENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(307, 'mod_popular', 'module', 'mod_popular', '', 1, 1, 1, 0, '{"name":"mod_popular","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(308, 'mod_quickicon', 'module', 'mod_quickicon', '', 1, 1, 1, 1, '{"name":"mod_quickicon","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_QUICKICON_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(309, 'mod_status', 'module', 'mod_status', '', 1, 1, 1, 0, '{"name":"mod_status","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_STATUS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(310, 'mod_submenu', 'module', 'mod_submenu', '', 1, 1, 1, 0, '{"name":"mod_submenu","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_SUBMENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(311, 'mod_title', 'module', 'mod_title', '', 1, 1, 1, 0, '{"name":"mod_title","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_TITLE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(312, 'mod_toolbar', 'module', 'mod_toolbar', '', 1, 1, 1, 1, '{"name":"mod_toolbar","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_TOOLBAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(313, 'mod_multilangstatus', 'module', 'mod_multilangstatus', '', 1, 1, 1, 0, '{"name":"mod_multilangstatus","type":"module","creationDate":"September 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_MULTILANGSTATUS_XML_DESCRIPTION","group":""}', '{"cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(314, 'mod_version', 'module', 'mod_version', '', 1, 1, 1, 0, '{"name":"mod_version","type":"module","creationDate":"January 2012","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_VERSION_XML_DESCRIPTION","group":""}', '{"format":"short","product":"1","cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(315, 'mod_stats_admin', 'module', 'mod_stats_admin', '', 1, 1, 1, 0, '{"name":"mod_stats_admin","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_STATS_XML_DESCRIPTION","group":""}', '{"serverinfo":"0","siteinfo":"0","counter":"0","increase":"0","cache":"1","cache_time":"900","cachemode":"static"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(316, 'mod_tags_popular', 'module', 'mod_tags_popular', '', 0, 1, 1, 0, '{"name":"mod_tags_popular","type":"module","creationDate":"January 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.0","description":"MOD_TAGS_POPULAR_XML_DESCRIPTION","group":""}', '{"maximum":"5","timeframe":"alltime","owncache":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(317, 'mod_tags_similar', 'module', 'mod_tags_similar', '', 0, 1, 1, 0, '{"name":"mod_tags_similar","type":"module","creationDate":"January 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.0","description":"MOD_TAGS_SIMILAR_XML_DESCRIPTION","group":""}', '{"maximum":"5","matchtype":"any","owncache":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(400, 'plg_authentication_gmail', 'plugin', 'gmail', 'authentication', 0, 0, 1, 0, '{"name":"plg_authentication_gmail","type":"plugin","creationDate":"February 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_GMAIL_XML_DESCRIPTION","group":""}', '{"applysuffix":"0","suffix":"","verifypeer":"1","user_blacklist":""}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(401, 'plg_authentication_joomla', 'plugin', 'joomla', 'authentication', 0, 1, 1, 1, '{"name":"plg_authentication_joomla","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_AUTH_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(402, 'plg_authentication_ldap', 'plugin', 'ldap', 'authentication', 0, 0, 1, 0, '{"name":"plg_authentication_ldap","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_LDAP_XML_DESCRIPTION","group":""}', '{"host":"","port":"389","use_ldapV3":"0","negotiate_tls":"0","no_referrals":"0","auth_method":"bind","base_dn":"","search_string":"","users_dn":"","username":"admin","password":"bobby7","ldap_fullname":"fullName","ldap_email":"mail","ldap_uid":"uid"}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(403, 'plg_content_contact', 'plugin', 'contact', 'content', 0, 1, 1, 0, '{"name":"plg_content_contact","type":"plugin","creationDate":"January 2014","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.2","description":"PLG_CONTENT_CONTACT_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(404, 'plg_content_emailcloak', 'plugin', 'emailcloak', 'content', 0, 1, 1, 0, '{"name":"plg_content_emailcloak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_EMAILCLOAK_XML_DESCRIPTION","group":""}', '{"mode":"1"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(406, 'plg_content_loadmodule', 'plugin', 'loadmodule', 'content', 0, 1, 1, 0, '{"name":"plg_content_loadmodule","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_LOADMODULE_XML_DESCRIPTION","group":""}', '{"style":"xhtml"}', '', '', 0, '2011-09-18 15:22:50', 0, 0),
(407, 'plg_content_pagebreak', 'plugin', 'pagebreak', 'content', 0, 1, 1, 0, '{"name":"plg_content_pagebreak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION","group":""}', '{"title":"1","multipage_toc":"1","showall":"1"}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(408, 'plg_content_pagenavigation', 'plugin', 'pagenavigation', 'content', 0, 1, 1, 0, '{"name":"plg_content_pagenavigation","type":"plugin","creationDate":"January 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_PAGENAVIGATION_XML_DESCRIPTION","group":""}', '{"position":"1"}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(409, 'plg_content_vote', 'plugin', 'vote', 'content', 0, 1, 1, 0, '{"name":"plg_content_vote","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_VOTE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(410, 'plg_editors_codemirror', 'plugin', 'codemirror', 'editors', 0, 1, 1, 1, '{"name":"plg_editors_codemirror","type":"plugin","creationDate":"28 March 2011","author":"Marijn Haverbeke","copyright":"","authorEmail":"N\\/A","authorUrl":"","version":"3.15","description":"PLG_CODEMIRROR_XML_DESCRIPTION","group":""}', '{"lineNumbers":"1","lineWrapping":"1","matchTags":"1","matchBrackets":"1","marker-gutter":"1","autoCloseTags":"1","autoCloseBrackets":"1","autoFocus":"1","theme":"default","tabmode":"indent"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(411, 'plg_editors_none', 'plugin', 'none', 'editors', 0, 1, 1, 1, '{"name":"plg_editors_none","type":"plugin","creationDate":"August 2004","author":"Unknown","copyright":"","authorEmail":"N\\/A","authorUrl":"","version":"3.0.0","description":"PLG_NONE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(412, 'plg_editors_tinymce', 'plugin', 'tinymce', 'editors', 0, 1, 1, 0, '{"name":"plg_editors_tinymce","type":"plugin","creationDate":"2005-2013","author":"Moxiecode Systems AB","copyright":"Moxiecode Systems AB","authorEmail":"N\\/A","authorUrl":"tinymce.moxiecode.com","version":"4.0.18","description":"PLG_TINY_XML_DESCRIPTION","group":""}', '{"mode":"1","skin":"0","mobile":"0","entity_encoding":"raw","lang_mode":"1","text_direction":"ltr","content_css":"1","content_css_custom":"","relative_urls":"1","newlines":"0","invalid_elements":"script,applet,iframe","extended_elements":"","html_height":"550","html_width":"750","resizing":"1","element_path":"1","fonts":"1","paste":"1","searchreplace":"1","insertdate":"1","colors":"1","table":"1","smilies":"1","hr":"1","link":"1","media":"1","print":"1","directionality":"1","fullscreen":"1","alignment":"1","visualchars":"1","visualblocks":"1","nonbreaking":"1","template":"1","blockquote":"1","wordcount":"1","advlist":"1","autosave":"1","contextmenu":"1","inlinepopups":"1","custom_plugin":"","custom_button":""}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(413, 'plg_editors-xtd_article', 'plugin', 'article', 'editors-xtd', 0, 1, 1, 1, '{"name":"plg_editors-xtd_article","type":"plugin","creationDate":"October 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_ARTICLE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(414, 'plg_editors-xtd_image', 'plugin', 'image', 'editors-xtd', 0, 1, 1, 0, '{"name":"plg_editors-xtd_image","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_IMAGE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(415, 'plg_editors-xtd_pagebreak', 'plugin', 'pagebreak', 'editors-xtd', 0, 1, 1, 0, '{"name":"plg_editors-xtd_pagebreak","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_EDITORSXTD_PAGEBREAK_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(416, 'plg_editors-xtd_readmore', 'plugin', 'readmore', 'editors-xtd', 0, 1, 1, 0, '{"name":"plg_editors-xtd_readmore","type":"plugin","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_READMORE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(417, 'plg_search_categories', 'plugin', 'categories', 'search', 0, 1, 1, 0, '{"name":"plg_search_categories","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_CATEGORIES_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0);
INSERT INTO `sas_extensions` VALUES
(418, 'plg_search_contacts', 'plugin', 'contacts', 'search', 0, 1, 1, 0, '{"name":"plg_search_contacts","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_CONTACTS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(419, 'plg_search_content', 'plugin', 'content', 'search', 0, 1, 1, 0, '{"name":"plg_search_content","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_CONTENT_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(420, 'plg_search_newsfeeds', 'plugin', 'newsfeeds', 'search', 0, 1, 1, 0, '{"name":"plg_search_newsfeeds","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_NEWSFEEDS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(421, 'plg_search_weblinks', 'plugin', 'weblinks', 'search', 0, 1, 1, 0, '{"name":"plg_search_weblinks","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_WEBLINKS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(422, 'plg_system_languagefilter', 'plugin', 'languagefilter', 'system', 0, 0, 1, 1, '{"name":"plg_system_languagefilter","type":"plugin","creationDate":"July 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_LANGUAGEFILTER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(423, 'plg_system_p3p', 'plugin', 'p3p', 'system', 0, 1, 1, 0, '{"name":"plg_system_p3p","type":"plugin","creationDate":"September 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_P3P_XML_DESCRIPTION","group":""}', '{"headers":"NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(424, 'plg_system_cache', 'plugin', 'cache', 'system', 0, 0, 1, 1, '{"name":"plg_system_cache","type":"plugin","creationDate":"February 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CACHE_XML_DESCRIPTION","group":""}', '{"browsercache":"0","cachetime":"15"}', '', '', 0, '0000-00-00 00:00:00', 9, 0),
(425, 'plg_system_debug', 'plugin', 'debug', 'system', 0, 1, 1, 0, '{"name":"plg_system_debug","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_DEBUG_XML_DESCRIPTION","group":""}', '{"profile":"1","queries":"1","memory":"1","language_files":"1","language_strings":"1","strip-first":"1","strip-prefix":"","strip-suffix":""}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(426, 'plg_system_log', 'plugin', 'log', 'system', 0, 1, 1, 1, '{"name":"plg_system_log","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_LOG_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(427, 'plg_system_redirect', 'plugin', 'redirect', 'system', 0, 0, 1, 1, '{"name":"plg_system_redirect","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_REDIRECT_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(428, 'plg_system_remember', 'plugin', 'remember', 'system', 0, 1, 1, 1, '{"name":"plg_system_remember","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_REMEMBER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(429, 'plg_system_sef', 'plugin', 'sef', 'system', 0, 1, 1, 0, '{"name":"plg_system_sef","type":"plugin","creationDate":"December 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEF_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 8, 0),
(430, 'plg_system_logout', 'plugin', 'logout', 'system', 0, 1, 1, 1, '{"name":"plg_system_logout","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_LOGOUT_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(431, 'plg_user_contactcreator', 'plugin', 'contactcreator', 'user', 0, 0, 1, 0, '{"name":"plg_user_contactcreator","type":"plugin","creationDate":"August 2009","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTACTCREATOR_XML_DESCRIPTION","group":""}', '{"autowebpage":"","category":"34","autopublish":"0"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(432, 'plg_user_joomla', 'plugin', 'joomla', 'user', 0, 1, 1, 0, '{"name":"plg_user_joomla","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2009 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_USER_JOOMLA_XML_DESCRIPTION","group":""}', '{"strong_passwords":"1","autoregister":"1"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(433, 'plg_user_profile', 'plugin', 'profile', 'user', 0, 0, 1, 0, '{"name":"plg_user_profile","type":"plugin","creationDate":"January 2008","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_USER_PROFILE_XML_DESCRIPTION","group":""}', '{"register-require_address1":"1","register-require_address2":"1","register-require_city":"1","register-require_region":"1","register-require_country":"1","register-require_postal_code":"1","register-require_phone":"1","register-require_website":"1","register-require_favoritebook":"1","register-require_aboutme":"1","register-require_tos":"1","register-require_dob":"1","profile-require_address1":"1","profile-require_address2":"1","profile-require_city":"1","profile-require_region":"1","profile-require_country":"1","profile-require_postal_code":"1","profile-require_phone":"1","profile-require_website":"1","profile-require_favoritebook":"1","profile-require_aboutme":"1","profile-require_tos":"1","profile-require_dob":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(434, 'plg_extension_joomla', 'plugin', 'joomla', 'extension', 0, 1, 1, 1, '{"name":"plg_extension_joomla","type":"plugin","creationDate":"May 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_EXTENSION_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(435, 'plg_content_joomla', 'plugin', 'joomla', 'content', 0, 1, 1, 0, '{"name":"plg_content_joomla","type":"plugin","creationDate":"November 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(436, 'plg_system_languagecode', 'plugin', 'languagecode', 'system', 0, 0, 1, 0, '{"name":"plg_system_languagecode","type":"plugin","creationDate":"November 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_LANGUAGECODE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(437, 'plg_quickicon_joomlaupdate', 'plugin', 'joomlaupdate', 'quickicon', 0, 1, 1, 1, '{"name":"plg_quickicon_joomlaupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(438, 'plg_quickicon_extensionupdate', 'plugin', 'extensionupdate', 'quickicon', 0, 1, 1, 1, '{"name":"plg_quickicon_extensionupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_QUICKICON_EXTENSIONUPDATE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(439, 'plg_captcha_recaptcha', 'plugin', 'recaptcha', 'captcha', 0, 0, 1, 0, '{"name":"plg_captcha_recaptcha","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CAPTCHA_RECAPTCHA_XML_DESCRIPTION","group":""}', '{"public_key":"","private_key":"","theme":"clean"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(440, 'plg_system_highlight', 'plugin', 'highlight', 'system', 0, 1, 1, 0, '{"name":"plg_system_highlight","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_HIGHLIGHT_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(441, 'plg_content_finder', 'plugin', 'finder', 'content', 0, 0, 1, 0, '{"name":"plg_content_finder","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_FINDER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(442, 'plg_finder_categories', 'plugin', 'categories', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_categories","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_CATEGORIES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(443, 'plg_finder_contacts', 'plugin', 'contacts', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_contacts","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_CONTACTS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(444, 'plg_finder_content', 'plugin', 'content', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_content","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_CONTENT_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(445, 'plg_finder_newsfeeds', 'plugin', 'newsfeeds', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_newsfeeds","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_NEWSFEEDS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(446, 'plg_finder_weblinks', 'plugin', 'weblinks', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_weblinks","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_WEBLINKS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(447, 'plg_finder_tags', 'plugin', 'tags', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_tags","type":"plugin","creationDate":"February 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_TAGS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(448, 'plg_twofactorauth_totp', 'plugin', 'totp', 'twofactorauth', 0, 0, 1, 0, '{"name":"plg_twofactorauth_totp","type":"plugin","creationDate":"August 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"PLG_TWOFACTORAUTH_TOTP_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(449, 'plg_authentication_cookie', 'plugin', 'cookie', 'authentication', 0, 1, 1, 0, '{"name":"plg_authentication_cookie","type":"plugin","creationDate":"July 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_AUTH_COOKIE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(450, 'plg_twofactorauth_yubikey', 'plugin', 'yubikey', 'twofactorauth', 0, 0, 1, 0, '{"name":"plg_twofactorauth_yubikey","type":"plugin","creationDate":"September 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"PLG_TWOFACTORAUTH_YUBIKEY_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(503, 'beez3', 'template', 'beez3', '', 0, 1, 1, 0, '{"name":"beez3","type":"template","creationDate":"25 November 2009","author":"Angie Radtke","copyright":"Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.","authorEmail":"a.radtke@derauftritt.de","authorUrl":"http:\\/\\/www.der-auftritt.de","version":"3.1.0","description":"TPL_BEEZ3_XML_DESCRIPTION","group":""}', '{"wrapperSmall":"53","wrapperLarge":"72","sitetitle":"","sitedescription":"","navposition":"center","templatecolor":"nature"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(504, 'hathor', 'template', 'hathor', '', 1, 1, 1, 0, '{"name":"hathor","type":"template","creationDate":"May 2010","author":"Andrea Tarr","copyright":"Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.","authorEmail":"hathor@tarrconsulting.com","authorUrl":"http:\\/\\/www.tarrconsulting.com","version":"3.0.0","description":"TPL_HATHOR_XML_DESCRIPTION","group":""}', '{"showSiteName":"0","colourChoice":"0","boldText":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(506, 'protostar', 'template', 'protostar', '', 0, 1, 1, 0, '{"name":"protostar","type":"template","creationDate":"4\\/30\\/2012","author":"Kyle Ledbetter","copyright":"Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"","version":"1.0","description":"TPL_PROTOSTAR_XML_DESCRIPTION","group":""}', '{"templateColor":"","logoFile":"","googleFont":"1","googleFontName":"Open+Sans","fluidContainer":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(507, 'isis', 'template', 'isis', '', 1, 1, 1, 0, '{"name":"isis","type":"template","creationDate":"3\\/30\\/2012","author":"Kyle Ledbetter","copyright":"Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"","version":"1.0","description":"TPL_ISIS_XML_DESCRIPTION","group":""}', '{"templateColor":"","logoFile":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(600, 'English (United Kingdom)', 'language', 'en-GB', '', 0, 1, 1, 1, '{"name":"English (United Kingdom)","type":"language","creationDate":"2013-03-07","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.3","description":"en-GB site language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(601, 'English (United Kingdom)', 'language', 'en-GB', '', 1, 1, 1, 1, '{"name":"English (United Kingdom)","type":"language","creationDate":"2013-03-07","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.3","description":"en-GB administrator language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(700, 'files_joomla', 'file', 'joomla', '', 0, 1, 1, 1, '{"name":"files_joomla","type":"file","creationDate":"March 2014","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.3","description":"FILES_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10001, 'Security - jHackGuard', 'plugin', 'jhackguard', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"Security - jHackGuard","type":"plugin","creationDate":"Jun 2012","author":"Val Markov","copyright":"Copyright (C) 2010-2012 SiteGround.com - All rights reserved.","authorEmail":"val@siteground.com","authorUrl":"http:\\/\\/www.siteground.com\\/","version":"1.4.2","description":"jHackGuard v.1.4.2 is a Joomla 2.5\\/3 security plugin developed by SiteGround. With this plugin your Joomla is protected against the most popular hacking attacks - SQL Injections, Remote URL\\/File Inclusions, Remote Code Executions and XSS Based Attacks!","group":""}', '{"log_file":"jhackguard-log.php","logging":"1","check_post":"1","check_get":"1","check_cookies":"1","check_eval":"1","check_base64":"1","check_sql":"1","check_urlfopen":"0","check_urlinclude":"0","strip_user_agent":"1","strict_xss":"1","scan_input_keys":"0","disable_file_uploads":"0","link_back_sg":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10002, 'System - jSGCache', 'plugin', 'jSGCache', 'system', 0, 1, 1, 0, '{"name":"System - jSGCache","type":"plugin","creationDate":"13 December 2012","author":"George Penkov","copyright":"(c) 2012 All Rights Reserved","authorEmail":"georgi.p@siteground.com","authorUrl":"http:\\/\\/www.SiteGround.com","version":"1.2.2","description":"\\n<p>Please enable this plugin in the Plug-in Manager before continuing. Before you can use this plugin you need to have the SG Cache service installed and activated.<br>Through the settings of this plugin you can manage how your Joomla interacts with SG Cache.<\\/p>\\n        ","group":""}', '{"cache_enabled":"0","autoFlush":"1","autoFlush-ThirdParty":"1","autoFlush-ClientSide":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10003, 'plg_installer_webinstaller', 'plugin', 'webinstaller', 'installer', 0, 1, 1, 0, '{"name":"plg_installer_webinstaller","type":"plugin","creationDate":"18 December 2013","author":"Joomla! Project","copyright":"Copyright (C) 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"1.0.5","description":"PLG_INSTALLER_WEBINSTALLER_XML_DESCRIPTION","group":""}', '{"tab_position":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10004, 'plg_editors_jce', 'plugin', 'jce', 'editors', 0, 1, 1, 0, '{"name":"plg_editors_jce","type":"plugin","creationDate":"12 December 2013","author":"Ryan Demmer","copyright":"2006-2010 Ryan Demmer","authorEmail":"info@joomlacontenteditor.net","authorUrl":"http:\\/\\/www.joomlacontenteditor.net","version":"2.3.4.4","description":"WF_EDITOR_PLUGIN_DESC","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10005, 'plg_quickicon_jcefilebrowser', 'plugin', 'jcefilebrowser', 'quickicon', 0, 1, 1, 0, '{"name":"plg_quickicon_jcefilebrowser","type":"plugin","creationDate":"12 December 2013","author":"Ryan Demmer","copyright":"Copyright (C) 2006 - 2013 Ryan Demmer. All rights reserved","authorEmail":"@@email@@","authorUrl":"www.joomalcontenteditor.net","version":"2.3.4.4","description":"PLG_QUICKICON_JCEFILEBROWSER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10006, 'jce', 'component', 'com_jce', '', 1, 1, 0, 0, '{"name":"JCE","type":"component","creationDate":"12 December 2013","author":"Ryan Demmer","copyright":"Copyright (C) 2006 - 2013 Ryan Demmer. All rights reserved","authorEmail":"info@joomlacontenteditor.net","authorUrl":"www.joomlacontenteditor.net","version":"2.3.4.4","description":"WF_ADMIN_DESC","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10007, 'akeeba', 'component', 'com_akeeba', '', 1, 1, 0, 0, '{"name":"Akeeba","type":"component","creationDate":"2014-03-09","author":"Nicholas K. Dionysopoulos","copyright":"Copyright (c)2006-2012 Nicholas K. Dionysopoulos","authorEmail":"nicholas@dionysopoulos.me","authorUrl":"http:\\/\\/www.akeebabackup.com","version":"3.10.2","description":"Akeeba Backup Core - Full Joomla! site backup solution, Core Edition.","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10008, 'AkeebaStrapper', 'file', 'files_strapper', '', 0, 1, 0, 0, '{"name":"AkeebaStrapper","type":"file","creationDate":"2014-03-09 12:54:48","author":"Nicholas K. Dionysopoulos","copyright":"(C) 2012-2013 Akeeba Ltd.","authorEmail":"nicholas@dionysopoulos.me","authorUrl":"https:\\/\\/www.akeebabackup.com","version":"2.2.1","description":"Namespaced jQuery, jQuery UI and Bootstrap for Akeeba products.","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10009, 'AllVideos (by JoomlaWorks)', 'plugin', 'jw_allvideos', 'content', 0, 0, 1, 0, '{"name":"AllVideos (by JoomlaWorks)","type":"plugin","creationDate":"February 27th, 2013","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2013 JoomlaWorks Ltd. All rights reserved.","authorEmail":"contact@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"4.5.0","description":"JW_PLG_AV_XML_DESC","group":""}', '{"":"JW_PLG_AV_PERFORMANCE_PARAMETERS","playerTemplate":"Classic","vfolder":"images\\/videos","vwidth":"400","vheight":"300","transparency":"transparent","background":"#010101","controlBarLocation":"bottom","backgroundQT":"black","afolder":"images\\/audio","awidth":"480","aheight":"24","abackground":"#010101","afrontcolor":"#FFFFFF","alightcolor":"#00ADE3","allowAudioDownloading":"0","autoplay":"0","gzipScripts":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10010, 'com_k2', 'component', 'com_k2', '', 1, 1, 0, 0, '{"name":"COM_K2","type":"component","creationDate":"February 28th, 2014","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"Thank you for installing K2 by JoomlaWorks, the powerful content extension for Joomla!","group":""}', '{"enable_css":"1","jQueryHandling":"1.8remote","backendJQueryHandling":"remote","userName":"1","userImage":"1","userDescription":"1","userURL":"1","userEmail":"0","userFeedLink":"1","userFeedIcon":"1","userItemCount":"10","userItemTitle":"1","userItemTitleLinked":"1","userItemDateCreated":"1","userItemImage":"1","userItemIntroText":"1","userItemCategory":"1","userItemTags":"1","userItemCommentsAnchor":"1","userItemReadMore":"1","userItemK2Plugins":"1","tagItemCount":"10","tagItemTitle":"1","tagItemTitleLinked":"1","tagItemDateCreated":"1","tagItemImage":"1","tagItemIntroText":"1","tagItemCategory":"1","tagItemReadMore":"1","tagItemExtraFields":"0","tagOrdering":"","tagFeedLink":"1","tagFeedIcon":"1","genericItemCount":"10","genericItemTitle":"1","genericItemTitleLinked":"1","genericItemDateCreated":"1","genericItemImage":"1","genericItemIntroText":"1","genericItemCategory":"1","genericItemReadMore":"1","genericItemExtraFields":"0","genericFeedLink":"1","genericFeedIcon":"1","feedLimit":"10","feedItemImage":"1","feedImgSize":"S","feedItemIntroText":"1","feedTextWordLimit":"","feedItemFullText":"1","feedItemTags":"0","feedItemVideo":"0","feedItemGallery":"0","feedItemAttachments":"0","feedBogusEmail":"","introTextCleanup":"0","introTextCleanupExcludeTags":"","introTextCleanupTagAttr":"","fullTextCleanup":"0","fullTextCleanupExcludeTags":"","fullTextCleanupTagAttr":"","xssFiltering":"0","linkPopupWidth":"900","linkPopupHeight":"600","imagesQuality":"100","itemImageXS":"100","itemImageS":"200","itemImageM":"400","itemImageL":"600","itemImageXL":"900","itemImageGeneric":"300","catImageWidth":"100","catImageDefault":"1","userImageWidth":"100","userImageDefault":"1","commenterImgWidth":"48","onlineImageEditor":"splashup","imageTimestamp":"0","imageMemoryLimit":"","socialButtonCode":"","twitterUsername":"","facebookImage":"Medium","comments":"1","commentsOrdering":"DESC","commentsLimit":"10","commentsFormPosition":"below","commentsPublishing":"1","commentsReporting":"2","commentsReportRecipient":"","inlineCommentsModeration":"0","gravatar":"1","recaptcha":"0","recaptchaForRegistered":"1","commentsFormNotes":"1","commentsFormNotesText":"","frontendEditing":"1","showImageTab":"1","showImageGalleryTab":"1","showVideoTab":"1","showExtraFieldsTab":"1","showAttachmentsTab":"1","showK2Plugins":"1","sideBarDisplayFrontend":"0","mergeEditors":"1","sideBarDisplay":"1","attachmentsFolder":"","hideImportButton":"0","googleSearch":"0","googleSearchContainer":"k2GoogleSearchContainer","K2UserProfile":"1","K2UserGroup":"","redirect":"","adminSearch":"simple","cookieDomain":"","taggingSystem":"1","lockTags":"0","showTagFilter":"0","k2TagNorm":"0","k2TagNormCase":"lower","k2TagNormAdditionalReplacements":"","recaptcha_public_key":"","recaptcha_private_key":"","recaptcha_theme":"clean","recaptchaOnRegistration":"0","stopForumSpam":"0","stopForumSpamApiKey":"","showItemsCounterAdmin":"1","showChildCatItems":"1","disableCompactOrdering":"0","metaDescLimit":"150","enforceSEFReplacements":"0","SEFReplacements":"","k2Sef":"0","k2SefLabelCat":"content","k2SefLabelTag":"tag","k2SefLabelUser":"author","k2SefLabelSearch":"search","k2SefLabelDate":"date","k2SefLabelItem":"0","k2SefLabelItemCustomPrefix":"","k2SefInsertItemId":"1","k2SefItemIdTitleAliasSep":"dash","k2SefUseItemTitleAlias":"1","k2SefInsertCatId":"1","k2SefCatIdTitleAliasSep":"dash","k2SefUseCatTitleAlias":"1","sh404SefLabelCat":"","sh404SefLabelUser":"blog","sh404SefLabelItem":"2","sh404SefTitleAlias":"alias","sh404SefModK2ContentFeedAlias":"feed","sh404SefInsertItemId":"0","sh404SefInsertUniqueItemId":"0","cbIntegration":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10011, 'plg_finder_k2', 'plugin', 'k2', 'finder', 0, 0, 1, 0, '{"name":"plg_finder_k2","type":"plugin","creationDate":"February 28th, 2014","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"PLG_FINDER_K2_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10012, 'Search - K2', 'plugin', 'k2', 'search', 0, 1, 1, 0, '{"name":"Search - K2","type":"plugin","creationDate":"February 28th, 2014","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"K2_THIS_PLUGIN_EXTENDS_THE_DEFAULT_JOOMLA_SEARCH_FUNCTIONALITY_TO_K2_CONTENT","group":""}', '{"search_limit":"50","search_tags":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10013, 'System - K2', 'plugin', 'k2', 'system', 0, 1, 1, 0, '{"name":"System - K2","type":"plugin","creationDate":"February 28th, 2014","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"K2_THE_K2_SYSTEM_PLUGIN_IS_USED_TO_ASSIST_THE_PROPER_FUNCTIONALITY_OF_THE_K2_COMPONENT_SITE_WIDE_MAKE_SURE_ITS_ALWAYS_PUBLISHED_WHEN_THE_K2_COMPONENT_IS_INSTALLED","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10014, 'User - K2', 'plugin', 'k2', 'user', 0, 1, 1, 0, '{"name":"User - K2","type":"plugin","creationDate":"February 28th, 2014","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"K2_A_USER_SYNCHRONIZATION_PLUGIN_FOR_K2","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10015, 'Josetta - K2 Categories', 'plugin', 'k2category', 'josetta_ext', 0, 1, 1, 0, '{"name":"Josetta - K2 Categories","type":"plugin","creationDate":"February 28th, 2014","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10016, 'Josetta - K2 Items', 'plugin', 'k2item', 'josetta_ext', 0, 1, 1, 0, '{"name":"Josetta - K2 Items","type":"plugin","creationDate":"June 7th, 2012","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10017, 'K2 Comments', 'module', 'mod_k2_comments', '', 0, 1, 0, 0, '{"name":"K2 Comments","type":"module","creationDate":"February 28th, 2014","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"MOD_K2_COMMENTS_DESCRIPTION","group":""}', '{"moduleclass_sfx":"","module_usage":"","":"K2_TOP_COMMENTERS","catfilter":"0","category_id":"","comments_limit":"5","comments_word_limit":"10","commenterName":"1","commentAvatar":"1","commentAvatarWidthSelect":"custom","commentAvatarWidth":"50","commentDate":"1","commentDateFormat":"absolute","commentLink":"1","itemTitle":"1","itemCategory":"1","feed":"1","commenters_limit":"5","commenterNameOrUsername":"1","commenterAvatar":"1","commenterAvatarWidthSelect":"custom","commenterAvatarWidth":"50","commenterLink":"1","commenterCommentsCounter":"1","commenterLatestComment":"1","cache":"1","cache_time":"900"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10018, 'K2 Content', 'module', 'mod_k2_content', '', 0, 1, 0, 0, '{"name":"K2 Content","type":"module","creationDate":"February 28th, 2014","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"K2_MOD_K2_CONTENT_DESCRIPTION","group":""}', '{"moduleclass_sfx":"","getTemplate":"Default","source":"filter","":"K2_OTHER_OPTIONS","catfilter":"0","category_id":"","getChildren":"0","itemCount":"5","itemsOrdering":"","FeaturedItems":"1","popularityRange":"","videosOnly":"0","item":"","items":"","itemTitle":"1","itemAuthor":"1","itemAuthorAvatar":"1","itemAuthorAvatarWidthSelect":"custom","itemAuthorAvatarWidth":"50","userDescription":"1","itemIntroText":"1","itemIntroTextWordLimit":"","itemImage":"1","itemImgSize":"Small","itemVideo":"1","itemVideoCaption":"1","itemVideoCredits":"1","itemAttachments":"1","itemTags":"1","itemCategory":"1","itemDateCreated":"1","itemHits":"1","itemReadMore":"1","itemExtraFields":"0","itemCommentsCounter":"1","feed":"1","itemPreText":"","itemCustomLink":"0","itemCustomLinkTitle":"","itemCustomLinkURL":"http:\\/\\/","itemCustomLinkMenuItem":"","K2Plugins":"1","JPlugins":"1","cache":"1","cache_time":"900"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10019, 'K2 Tools', 'module', 'mod_k2_tools', '', 0, 1, 0, 0, '{"name":"K2 Tools","type":"module","creationDate":"February 28th, 2014","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"K2_TOOLS","group":""}', '{"moduleclass_sfx":"","module_usage":"0","":"K2_CUSTOM_CODE_SETTINGS","archiveItemsCounter":"1","archiveCategory":"","authors_module_category":"","authorItemsCounter":"1","authorAvatar":"1","authorAvatarWidthSelect":"custom","authorAvatarWidth":"50","authorLatestItem":"1","calendarCategory":"","home":"","seperator":"","root_id":"","end_level":"","categoriesListOrdering":"","categoriesListItemsCounter":"1","root_id2":"","catfilter":"0","category_id":"","getChildren":"0","liveSearch":"","width":"20","text":"","button":"","imagebutton":"","button_text":"","min_size":"75","max_size":"300","cloud_limit":"30","cloud_category":"0","cloud_category_recursive":"0","customCode":"","parsePhp":"0","K2Plugins":"0","JPlugins":"0","cache":"1","cache_time":"900"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10020, 'K2 Users', 'module', 'mod_k2_users', '', 0, 1, 0, 0, '{"name":"K2 Users","type":"module","creationDate":"February 28th, 2014","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"K2_MOD_K2_USERS_DESCRTIPTION","group":""}', '{"moduleclass_sfx":"","getTemplate":"Default","source":"0","":"K2_DISPLAY_OPTIONS","filter":"1","K2UserGroup":"","ordering":"1","limit":"4","userIDs":"","userName":"1","userAvatar":"1","userAvatarWidthSelect":"custom","userAvatarWidth":"50","userDescription":"1","userDescriptionWordLimit":"","userURL":"1","userEmail":"0","userFeed":"1","userItemCount":"1","cache":"1","cache_time":"900"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10021, 'K2 User', 'module', 'mod_k2_user', '', 0, 1, 0, 0, '{"name":"K2 User","type":"module","creationDate":"February 28th, 2014","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"K2_MOD_K2_USER_DESCRIPTION","group":""}', '{"moduleclass_sfx":"","pretext":"","":"K2_LOGIN_LOGOUT_REDIRECTION","name":"1","userAvatar":"1","userAvatarWidthSelect":"custom","userAvatarWidth":"50","menu":"","login":"","logout":"","usesecure":"0","cache":"0","cache_time":"900"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10022, 'K2 Quick Icons (admin)', 'module', 'mod_k2_quickicons', '', 1, 1, 2, 0, '{"name":"K2 Quick Icons (admin)","type":"module","creationDate":"February 28th, 2014","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"K2_QUICKICONS_FOR_USE_IN_THE_JOOMLA_CONTROL_PANEL_DASHBOARD_PAGE","group":""}', '{"modCSSStyling":"1","modLogo":"1","cache":"0","cache_time":"900"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10023, 'K2 Stats (admin)', 'module', 'mod_k2_stats', '', 1, 1, 2, 0, '{"name":"K2 Stats (admin)","type":"module","creationDate":"February 28th, 2014","author":"JoomlaWorks","copyright":"Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.","authorEmail":"please-use-the-contact-form@joomlaworks.net","authorUrl":"www.joomlaworks.net","version":"2.6.8","description":"K2_STATS_FOR_USE_IN_THE_K2_DASHBOARD_PAGE","group":""}', '{"latestItems":"1","popularItems":"1","mostCommentedItems":"1","latestComments":"1","statistics":"1","cache":"0","cache_time":"900"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10024, 'flexbanners', 'component', 'com_flexbanners', '', 1, 1, 0, 0, '{"name":"FlexBanners","type":"component","creationDate":"2014\\/04\\/15","author":"inch hosting","copyright":"Copyright (c)2009-2014 inch communications ltd","authorEmail":"admin@inchhosting.co.uk","authorUrl":"www.inchhosting.co.uk","version":"4.0.16","description":"\\n\\t\\t\\n\\t\\t<div align=\\"left\\"><a href=\\"\\/\\/www.inchhosting.co.uk\\/\\" alt=\\"Joomla Web Hosting from Inch\\" title=\\"Joomla Web Hosting from Inch\\"  ><img src=\\"components\\/com_flexbanners\\/flexbanner.png\\" alt=\\"FlexBanner Logo\\" \\/><\\/a><\\/div>\\n\\t\\t<div align=\\"left\\"><h2>Successfully installed FlexBanner&nbsp;Component and Module<\\/h2>\\n\\t\\t\\t\\n\\t\\tFlexBanner is a powerful banner management system that allows you to choose which articles or categories a banner appears on.\\n\\n\\t\\tIt supports the use of Flash banners and reports impressions and clicks.\\n\\t\\t<br \\/><br \\/>\\n\\t\\t<a href=\\"\\/\\/www.inchhosting.co.uk\\/\\" alt=\\"Joomla Web Hosting from Inch\\" title=\\"Joomla Web Hosting from Inch\\"  >Joomla Web Hosting from Inch<\\/a>\\n\\t\\t<br \\/><br \\/>\\n\\t\\t<\\/div>\\n\\t\\t\\n\\t","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10025, 'FlexBanners', 'module', 'mod_flexbanners', '', 0, 1, 0, 0, '{"name":"FlexBanners","type":"module","creationDate":"2014\\/04\\/15","author":"inch hosting","copyright":"Copyright (c)2009-2014 inch communications ltd","authorEmail":"adimn@inchhosting.co.uk","authorUrl":"www.inchhosting.co.uk","version":"4.0.16","description":"This module shows adverts in a flexible manner","group":""}', '{"locationid":"","numberbanner":"1","loadlast":"0","enablecsa":"0","enabletrans":"0","enablenofollow":"0","cache":"0","cache_time":"900"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10026, 'SobiPro Header', 'plugin', 'spHeader', 'system', 0, 1, 1, 0, '{"name":"SobiPro Header","type":"plugin","creationDate":"4 October 2013","author":"Sigsiu.NET GmbH","copyright":"Copyright (C) 2006-2013 Sigsiu.NET GmbH","authorEmail":"sobi[at]sigsiu.net","authorUrl":"http:\\/\\/www.Sigsiu.NET","version":"1.0.0","description":"SobiPro Header Plugin - please do not disable!<br\\/>\\nThe SobiPro Header Plugin is necessary for the correct functionality of SobiPro. If it is disabled SobiPro won''t work at all.\\n\\t","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10027, 'sobipro', 'component', 'com_sobipro', '', 1, 1, 0, 0, '{"name":"SobiPro","type":"component","creationDate":"30 March 2014","author":"Sigsiu.NET GmbH","copyright":"Copyright (C) 2006-2014 Sigsiu.NET GmbH","authorEmail":"sobi[at]sigsiu.net","authorUrl":"http:\\/\\/www.Sigsiu.NET","version":"1.1.8","description":"","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10028, 'acymailing', 'component', 'com_acymailing', '', 1, 1, 0, 0, '{"name":"AcyMailing","type":"component","creationDate":"avril 2014","author":"Acyba","copyright":"Copyright (C) 2009-2014 ACYBA SARL - All rights reserved.","authorEmail":"dev@acyba.com","authorUrl":"http:\\/\\/www.acyba.com","version":"4.6.2","description":"Manage your Mailing lists, Newsletters, e-mail marketing campaigns","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10029, 'AcyMailing : trigger Joomla Content plugins', 'plugin', 'contentplugin', 'acymailing', 0, 0, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 15, 0),
(10030, 'AcyMailing Manage text', 'plugin', 'managetext', 'acymailing', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(10031, 'AcyMailing Tag : Website links', 'plugin', 'online', 'acymailing', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(10032, 'AcyMailing : share on social networks', 'plugin', 'share', 'acymailing', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 20, 0),
(10033, 'AcyMailing : Statistics Plugin', 'plugin', 'stats', 'acymailing', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 50, 0),
(10034, 'AcyMailing table of contents generator', 'plugin', 'tablecontents', 'acymailing', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(10035, 'AcyMailing Tag : CB User information', 'plugin', 'tagcbuser', 'acymailing', 0, 0, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(10036, 'AcyMailing Tag : content insertion', 'plugin', 'tagcontent', 'acymailing', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 11, 0),
(10037, 'AcyMailing Tag : Subscriber information', 'plugin', 'tagsubscriber', 'acymailing', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(10038, 'AcyMailing Tag : Manage the Subscription', 'plugin', 'tagsubscription', 'acymailing', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(10039, 'AcyMailing Tag : Date / Time', 'plugin', 'tagtime', 'acymailing', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(10040, 'AcyMailing Tag : Joomla User Information', 'plugin', 'taguser', 'acymailing', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(10041, 'AcyMailing Template Class Replacer', 'plugin', 'template', 'acymailing', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 25, 0),
(10042, 'AcyMailing Editor', 'plugin', 'acyeditor', 'editors', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(10043, 'AcyMailing : (auto)Subscribe during Joomla registration', 'plugin', 'regacymailing', 'system', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10044, 'AcyMailing Module', 'module', 'mod_acymailing', '', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10045, 'ContentMap', 'library', 'contentmap', '', 0, 1, 1, 0, '{"name":"ContentMap","type":"library","creationDate":"13\\/02\\/2012","author":"Open Source Solutions SLU","copyright":"Open Source Solutions SLU","authorEmail":"info@opensourcesolutions.es","authorUrl":"http:\\/\\/www.opensourcesolutions.es\\/","version":"1.3.2","description":"","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10046, 'mod_contentmap', 'module', 'mod_contentmap', '', 0, 1, 0, 0, '{"name":"mod_contentmap","type":"module","creationDate":"13\\/02\\/2012","author":"Open Source Solutions SLU","copyright":"Open Source Solutions SLU","authorEmail":"info@opensourcesolutions.es","authorUrl":"http:\\/\\/www.opensourcesolutions.es\\/","version":"1.3.2","description":"MOD_CONTENTMAP_DESCRIPTION","group":""}', '{"map_width":"100","map_width_unit":"%","map_height":"400","zoom":"0","map_type":"ROADMAP","kml_url":"","hideStreetViewControl":"0","hideZoomControl":"0","markers_icon":"","markers_action":"infowindow","cluster":"1","showDirectionsMarker":"0","infowindow_event":"click","infowindow_width":"400","show_title":"1","link_titles":"1","link_target":"_self","show_image":"1","show_created_by_alias":"0","show_created":"0","show_intro":"1","introtext_size":"300","category_legend_filter":"0","featured":"0,1","category_filter_type":"0","author_filtering_type":"0","css":"default.php","data_source":"0","data_url":"http:\\/\\/forum.joomla.it\\/libraries\\/contentmap\\/json\\/smf.php"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10047, 'plg_content_contentmap', 'plugin', 'contentmap', 'content', 0, 1, 1, 0, '{"name":"plg_content_contentmap","type":"plugin","creationDate":"13\\/02\\/2012","author":"Open Source Solutions SLU","copyright":"Open Source Solutions SLU","authorEmail":"info@opensourcesolutions.es","authorUrl":"http:\\/\\/www.opensourcesolutions.es\\/","version":"1.3.2","description":"PLG_CONTENTMAP_DESCRIPTION","group":""}', '{"map_width":"100","map_width_unit":"%","map_height":"400","zoom":"17","map_type":"ROADMAP","hideStreetViewControl":"0","hideZoomControl":"0","markers_icon":"","markers_action":"infowindow","infowindow_event":"click","infowindow_width":"400","show_title":"1","link_titles":"0","link_target":"_self","show_image":"1","show_created_by_alias":"0","show_created":"0","show_intro":"1","introtext_size":"300","showDirectionsMarker":"0","css":"default.css"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10048, 'com_contentmap', 'component', 'com_contentmap', '', 1, 1, 0, 0, '{"name":"COM_CONTENTMAP","type":"component","creationDate":"13\\/02\\/2012","author":"Open Source Solutions SLU","copyright":"Open Source Solutions SLU","authorEmail":"info@opensourcesolutions.es","authorUrl":"http:\\/\\/www.opensourcesolutions.es\\/","version":"1.3.2","description":"COM_CONTENTMAP_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10049, 'feedgator', 'component', 'com_feedgator', '', 1, 1, 0, 0, '{"name":"FeedGator","type":"component","creationDate":"Aug 2010","author":"Matt Faulds","copyright":"Copyright 2005-2010 Stephen Simmons, Jozef Kapusciarz & Matt Faulds. All rights reserved!","authorEmail":"mattfaulds@gmail.com","authorUrl":"joomlacode.org\\/gf\\/project\\/feedgator | trafalgardesign.com","version":"3.0a3","description":"FG_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10050, 'System - FeedGator Automator Plugin', 'plugin', 'feedgator_system', 'system', 0, 0, 1, 0, '{"name":"System - FeedGator Automator Plugin","type":"plugin","creationDate":"October 2009","author":"Matt Faulds","copyright":"Trafalgar Design (UK) Ltd","authorEmail":"matt@trafalgardesign.com","authorUrl":"http:\\/\\/www.trafalgardesign.com","version":"3.0a1","description":"FG_PLG_DESC","group":""}', '{"fgautomator":"0","interval":"5"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10051, 'FeedGator - Joomla Native Content Plugin', 'plugin', 'plg_fg_content', 'feedgator', 0, 0, 1, 0, '{"name":"FeedGator - Joomla Native Content Plugin","type":"plugin","creationDate":"Sept 2010","author":"Matt Faulds","copyright":"Copyright 2010 Trafalgar Design","authorEmail":"matt@trafalgardesign.com","authorUrl":"http:\\/\\/www.trafalgardesign.com","version":"3.0","description":"Plugin to allow importing of content into native Joomla content. Requires FeedGator 2.4 or later.","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10052, 'FeedGator - K2 Content Plugin', 'plugin', 'plg_fg_k2', 'feedgator', 0, 0, 1, 0, '{"name":"FeedGator - K2 Content Plugin","type":"plugin","creationDate":"Sept 2010","author":"Matt Faulds","copyright":"Copyright 2010 Trafalgar Design","authorEmail":"matt@trafalgardesign.com","authorUrl":"http:\\/\\/www.trafalgardesign.com","version":"3.0.1","description":"Plugin to allow importing of content into K2 component. Requires FeedGator 2.4 or later.","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table`sas_feedgator`
--

CREATE TABLE `sas_feedgator` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT 'Untitled',
  `feed` text NOT NULL,
  `content_type` varchar(50) DEFAULT NULL,
  `sectionid` int(10) NOT NULL DEFAULT '0',
  `catid` int(10) NOT NULL DEFAULT '0',
  `default_author` varchar(100) DEFAULT NULL,
  `default_introtext` varchar(250) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_run` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_email` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `front_page` tinyint(1) NOT NULL DEFAULT '0',
  `filtering` tinyint(1) NOT NULL DEFAULT '0',
  `filter_whitelist` text NOT NULL,
  `filter_blacklist` text NOT NULL,
  `params` text NOT NULL,
  `imports` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_feedgator_imports`
--

CREATE TABLE `sas_feedgator_imports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_id` int(11) NOT NULL,
  `plugin` text NOT NULL,
  `feed_id` int(11) NOT NULL,
  `hash` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `feed_id` (`feed_id`),
  KEY `content_id` (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_feedgator_plugins`
--

CREATE TABLE `sas_feedgator_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `extension` varchar(100) NOT NULL,
  `published` int(1) DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table 'sas_feedgator_plugins'
--

INSERT INTO `sas_feedgator_plugins` VALUES
(1, 'com_content', 0, '-1{}'),
(2, 'com_k2', 0, '-1{}');

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_filters`
--

CREATE TABLE `sas_finder_filters` (
  `filter_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_count` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `params` mediumtext,
  PRIMARY KEY (`filter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links`
--

CREATE TABLE `sas_finder_links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `indexdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `md5sum` varchar(32) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `state` int(5) DEFAULT '1',
  `access` int(5) DEFAULT '0',
  `language` varchar(8) NOT NULL,
  `publish_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `list_price` double unsigned NOT NULL DEFAULT '0',
  `sale_price` double unsigned NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL,
  `object` mediumblob NOT NULL,
  PRIMARY KEY (`link_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_title` (`title`),
  KEY `idx_md5` (`md5sum`),
  KEY `idx_url` (`url`(75)),
  KEY `idx_published_list` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`list_price`),
  KEY `idx_published_sale` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`sale_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_terms0`
--

CREATE TABLE `sas_finder_links_terms0` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_terms1`
--

CREATE TABLE `sas_finder_links_terms1` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_terms2`
--

CREATE TABLE `sas_finder_links_terms2` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_terms3`
--

CREATE TABLE `sas_finder_links_terms3` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_terms4`
--

CREATE TABLE `sas_finder_links_terms4` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_terms5`
--

CREATE TABLE `sas_finder_links_terms5` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_terms6`
--

CREATE TABLE `sas_finder_links_terms6` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_terms7`
--

CREATE TABLE `sas_finder_links_terms7` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_terms8`
--

CREATE TABLE `sas_finder_links_terms8` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_terms9`
--

CREATE TABLE `sas_finder_links_terms9` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_termsa`
--

CREATE TABLE `sas_finder_links_termsa` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_termsb`
--

CREATE TABLE `sas_finder_links_termsb` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_termsc`
--

CREATE TABLE `sas_finder_links_termsc` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_termsd`
--

CREATE TABLE `sas_finder_links_termsd` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_termse`
--

CREATE TABLE `sas_finder_links_termse` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_links_termsf`
--

CREATE TABLE `sas_finder_links_termsf` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_taxonomy`
--

CREATE TABLE `sas_finder_taxonomy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `access` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `state` (`state`),
  KEY `ordering` (`ordering`),
  KEY `access` (`access`),
  KEY `idx_parent_published` (`parent_id`,`state`,`access`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table 'sas_finder_taxonomy'
--

INSERT INTO `sas_finder_taxonomy` VALUES
(1, 0, 'ROOT', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_taxonomy_map`
--

CREATE TABLE `sas_finder_taxonomy_map` (
  `link_id` int(10) unsigned NOT NULL,
  `node_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`node_id`),
  KEY `link_id` (`link_id`),
  KEY `node_id` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_terms`
--

CREATE TABLE `sas_finder_terms` (
  `term_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '0',
  `soundex` varchar(75) NOT NULL,
  `links` int(10) NOT NULL DEFAULT '0',
  `language` char(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `idx_term` (`term`),
  KEY `idx_term_phrase` (`term`,`phrase`),
  KEY `idx_stem_phrase` (`stem`,`phrase`),
  KEY `idx_soundex_phrase` (`soundex`,`phrase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_terms_common`
--

CREATE TABLE `sas_finder_terms_common` (
  `term` varchar(75) NOT NULL,
  `language` varchar(3) NOT NULL,
  KEY `idx_word_lang` (`term`,`language`),
  KEY `idx_lang` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_finder_terms_common'
--

INSERT INTO `sas_finder_terms_common` VALUES
('a', 'en'),
('about', 'en'),
('after', 'en'),
('ago', 'en'),
('all', 'en'),
('am', 'en'),
('an', 'en'),
('and', 'en'),
('ani', 'en'),
('any', 'en'),
('are', 'en'),
('aren''t', 'en'),
('as', 'en'),
('at', 'en'),
('be', 'en'),
('but', 'en'),
('by', 'en'),
('for', 'en'),
('from', 'en'),
('get', 'en'),
('go', 'en'),
('how', 'en'),
('if', 'en'),
('in', 'en'),
('into', 'en'),
('is', 'en'),
('isn''t', 'en'),
('it', 'en'),
('its', 'en'),
('me', 'en'),
('more', 'en'),
('most', 'en'),
('must', 'en'),
('my', 'en'),
('new', 'en'),
('no', 'en'),
('none', 'en'),
('not', 'en'),
('noth', 'en'),
('nothing', 'en'),
('of', 'en'),
('off', 'en'),
('often', 'en'),
('old', 'en'),
('on', 'en'),
('onc', 'en'),
('once', 'en'),
('onli', 'en'),
('only', 'en'),
('or', 'en'),
('other', 'en'),
('our', 'en'),
('ours', 'en'),
('out', 'en'),
('over', 'en'),
('page', 'en'),
('she', 'en'),
('should', 'en'),
('small', 'en'),
('so', 'en'),
('some', 'en'),
('than', 'en'),
('thank', 'en'),
('that', 'en'),
('the', 'en'),
('their', 'en'),
('theirs', 'en'),
('them', 'en'),
('then', 'en'),
('there', 'en'),
('these', 'en'),
('they', 'en'),
('this', 'en'),
('those', 'en'),
('thus', 'en'),
('time', 'en'),
('times', 'en'),
('to', 'en'),
('too', 'en'),
('true', 'en'),
('under', 'en'),
('until', 'en'),
('up', 'en'),
('upon', 'en'),
('use', 'en'),
('user', 'en'),
('users', 'en'),
('veri', 'en'),
('version', 'en'),
('very', 'en'),
('via', 'en'),
('want', 'en'),
('was', 'en'),
('way', 'en'),
('were', 'en'),
('what', 'en'),
('when', 'en'),
('where', 'en'),
('whi', 'en'),
('which', 'en'),
('who', 'en'),
('whom', 'en'),
('whose', 'en'),
('why', 'en'),
('wide', 'en'),
('will', 'en'),
('with', 'en'),
('within', 'en'),
('without', 'en'),
('would', 'en'),
('yes', 'en'),
('yet', 'en'),
('you', 'en'),
('your', 'en'),
('yours', 'en');

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_tokens`
--

CREATE TABLE `sas_finder_tokens` (
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '1',
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `language` char(3) NOT NULL DEFAULT '',
  KEY `idx_word` (`term`),
  KEY `idx_context` (`context`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_tokens_aggregate`
--

CREATE TABLE `sas_finder_tokens_aggregate` (
  `term_id` int(10) unsigned NOT NULL,
  `map_suffix` char(1) NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `term_weight` float unsigned NOT NULL,
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `context_weight` float unsigned NOT NULL,
  `total_weight` float unsigned NOT NULL,
  `language` char(3) NOT NULL DEFAULT '',
  KEY `token` (`term`),
  KEY `keyword_id` (`term_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_finder_types`
--

CREATE TABLE `sas_finder_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `mime` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_flexbanners`
--

CREATE TABLE `sas_flexbanners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) DEFAULT NULL,
  `linkid` int(11) DEFAULT NULL,
  `sizeid` int(11) DEFAULT NULL,
  `locationid` int(11) DEFAULT NULL,
  `type` tinyint(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `imageurl` varchar(255) DEFAULT NULL,
  `imagealt` varchar(255) DEFAULT NULL,
  `customcode` text,
  `restrictbyid` tinyint(1) NOT NULL DEFAULT '0',
  `frontpage` tinyint(1) DEFAULT NULL,
  `clicks` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `startdate` datetime DEFAULT NULL,
  `enddate` datetime DEFAULT NULL,
  `maximpressions` int(11) DEFAULT NULL,
  `maxclicks` int(11) DEFAULT NULL,
  `dailyimpressions` int(11) DEFAULT '0',
  `lastreset` date DEFAULT NULL,
  `published` tinyint(1) DEFAULT '0',
  `finished` tinyint(1) DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL,
  `reset` datetime DEFAULT NULL,
  `state` tinyint(3) NOT NULL,
  `catid` int(11) DEFAULT '0',
  `editor` varchar(50) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `language` char(7) DEFAULT NULL,
  `newwin` tinyint(1) DEFAULT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_flexbannersclient`
--

CREATE TABLE `sas_flexbannersclient` (
  `clientid` int(11) NOT NULL AUTO_INCREMENT,
  `clientname` varchar(255) DEFAULT NULL,
  `contactname` varchar(255) DEFAULT NULL,
  `contactemail` varchar(255) DEFAULT NULL,
  `barred` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL,
  `editor` varchar(50) DEFAULT NULL,
  `juserid` int(11) DEFAULT NULL,
  `state` tinyint(3) NOT NULL,
  PRIMARY KEY (`clientid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_flexbannersin`
--

CREATE TABLE `sas_flexbannersin` (
  `bannerid` int(11) DEFAULT NULL,
  `sectionid` int(11) DEFAULT NULL,
  `categoryid` int(11) DEFAULT NULL,
  `contentid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_flexbannerslink`
--

CREATE TABLE `sas_flexbannerslink` (
  `linkid` int(11) NOT NULL AUTO_INCREMENT,
  `linkname` varchar(30) DEFAULT NULL,
  `linkurl` text,
  `clientid` int(11) DEFAULT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL,
  `editor` varchar(50) DEFAULT NULL,
  `state` tinyint(3) NOT NULL,
  PRIMARY KEY (`linkid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_flexbannerslocations`
--

CREATE TABLE `sas_flexbannerslocations` (
  `locationid` int(11) NOT NULL AUTO_INCREMENT,
  `locationname` varchar(50) DEFAULT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL,
  `editor` varchar(50) DEFAULT NULL,
  `state` tinyint(3) NOT NULL,
  PRIMARY KEY (`locationid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_flexbannerssize`
--

CREATE TABLE `sas_flexbannerssize` (
  `sizeid` int(11) NOT NULL AUTO_INCREMENT,
  `sizename` varchar(50) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `maxfilesize` int(11) DEFAULT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL,
  `editor` varchar(50) DEFAULT NULL,
  `state` tinyint(3) NOT NULL,
  PRIMARY KEY (`sizeid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table 'sas_flexbannerssize'
--

INSERT INTO `sas_flexbannerssize` VALUES
(1, 'Full Banner (468x60)', 468, 60, 15000, 0, '0000-00-00 00:00:00', '', 1),
(2, 'Half Banner (234x60)', 234, 60, 15000, 0, '0000-00-00 00:00:00', '', 1),
(3, 'Micro Bar (88x31)', 88, 31, 15000, 0, '0000-00-00 00:00:00', '', 1),
(4, 'Button 1 (120x90)', 120, 90, 15000, 0, '0000-00-00 00:00:00', '', 1),
(5, 'Button 2 (120x60)', 120, 60, 15000, 0, '0000-00-00 00:00:00', '', 1),
(6, 'Vertical Banner (120x240)', 120, 240, 15000, 0, '0000-00-00 00:00:00', '', 1),
(7, 'Square Button (125x125)', 125, 125, 15000, 0, '0000-00-00 00:00:00', '', 1),
(8, 'Leaderboard (728x90)', 728, 90, 20000, 0, '0000-00-00 00:00:00', '', 1),
(9, 'Wide Skyscraper (160x600)', 160, 600, 20000, 0, '0000-00-00 00:00:00', '', 1),
(10, 'Skyscraper (120x600)', 120, 600, 15000, 0, '0000-00-00 00:00:00', '', 1),
(11, 'Half Page Ad (300x600)', 300, 600, 15000, 0, '0000-00-00 00:00:00', '', 1),
(12, 'Medium Rectangle (300x250)', 300, 250, 20000, 0, '0000-00-00 00:00:00', '', 1),
(13, 'Square Pop-up (250x250)', 250, 250, 15000, 0, '0000-00-00 00:00:00', '', 1),
(14, 'Vertical Rectangle (240x400)', 240, 400, 15000, 0, '0000-00-00 00:00:00', '', 1),
(15, 'Large Rectangle (336x280)', 336, 280, 15000, 0, '0000-00-00 00:00:00', '', 1),
(16, 'Rectangle (180x150)', 180, 150, 15000, 0, '0000-00-00 00:00:00', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table`sas_k2_attachments`
--

CREATE TABLE `sas_k2_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemID` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `titleAttribute` text NOT NULL,
  `hits` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itemID` (`itemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_k2_categories`
--

CREATE TABLE `sas_k2_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `parent` int(11) DEFAULT '0',
  `extraFieldsGroup` int(11) NOT NULL,
  `published` smallint(6) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `trash` smallint(6) NOT NULL DEFAULT '0',
  `plugins` text NOT NULL,
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category` (`published`,`access`,`trash`),
  KEY `parent` (`parent`),
  KEY `ordering` (`ordering`),
  KEY `published` (`published`),
  KEY `access` (`access`),
  KEY `trash` (`trash`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_k2_comments`
--

CREATE TABLE `sas_k2_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `commentDate` datetime NOT NULL,
  `commentText` text NOT NULL,
  `commentEmail` varchar(255) NOT NULL,
  `commentURL` varchar(255) NOT NULL,
  `published` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `itemID` (`itemID`),
  KEY `userID` (`userID`),
  KEY `published` (`published`),
  KEY `latestComments` (`published`,`commentDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_k2_extra_fields`
--

CREATE TABLE `sas_k2_extra_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `type` varchar(255) NOT NULL,
  `group` int(11) NOT NULL,
  `published` tinyint(4) NOT NULL,
  `ordering` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group` (`group`),
  KEY `published` (`published`),
  KEY `ordering` (`ordering`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_k2_extra_fields_groups`
--

CREATE TABLE `sas_k2_extra_fields_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_k2_items`
--

CREATE TABLE `sas_k2_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `catid` int(11) NOT NULL,
  `published` smallint(6) NOT NULL DEFAULT '0',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `video` text,
  `gallery` varchar(255) DEFAULT NULL,
  `extra_fields` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `extra_fields_search` text NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL,
  `checked_out` int(10) unsigned NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `trash` smallint(6) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `featured` smallint(6) NOT NULL DEFAULT '0',
  `featured_ordering` int(11) NOT NULL DEFAULT '0',
  `image_caption` text NOT NULL,
  `image_credits` varchar(255) NOT NULL,
  `video_caption` text NOT NULL,
  `video_credits` varchar(255) NOT NULL,
  `hits` int(10) unsigned NOT NULL,
  `params` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `metakey` text NOT NULL,
  `plugins` text NOT NULL,
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item` (`published`,`publish_up`,`publish_down`,`trash`,`access`),
  KEY `catid` (`catid`),
  KEY `created_by` (`created_by`),
  KEY `ordering` (`ordering`),
  KEY `featured` (`featured`),
  KEY `featured_ordering` (`featured_ordering`),
  KEY `hits` (`hits`),
  KEY `created` (`created`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_k2_rating`
--

CREATE TABLE `sas_k2_rating` (
  `itemID` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(11) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(11) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_k2_tags`
--

CREATE TABLE `sas_k2_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `published` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `published` (`published`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_k2_tags_xref`
--

CREATE TABLE `sas_k2_tags_xref` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tagID` int(11) NOT NULL,
  `itemID` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tagID` (`tagID`),
  KEY `itemID` (`itemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_k2_users`
--

CREATE TABLE `sas_k2_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `userName` varchar(255) DEFAULT NULL,
  `gender` enum('m','f') NOT NULL DEFAULT 'm',
  `description` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `group` int(11) NOT NULL DEFAULT '0',
  `plugins` text NOT NULL,
  `ip` varchar(15) NOT NULL,
  `hostname` varchar(255) NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userID` (`userID`),
  KEY `group` (`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_k2_user_groups`
--

CREATE TABLE `sas_k2_user_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `permissions` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_languages`
--

CREATE TABLE `sas_languages` (
  `lang_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang_code` char(7) NOT NULL,
  `title` varchar(50) NOT NULL,
  `title_native` varchar(50) NOT NULL,
  `sef` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` varchar(512) NOT NULL,
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `sitename` varchar(1024) NOT NULL DEFAULT '',
  `published` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang_id`),
  UNIQUE KEY `idx_sef` (`sef`),
  UNIQUE KEY `idx_image` (`image`),
  UNIQUE KEY `idx_langcode` (`lang_code`),
  KEY `idx_access` (`access`),
  KEY `idx_ordering` (`ordering`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table 'sas_languages'
--

INSERT INTO `sas_languages` VALUES
(1, 'en-GB', 'English (UK)', 'English (UK)', 'en', 'en', '', '', '', '', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table`sas_menu`
--

CREATE TABLE `sas_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(1024) NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The published state of the menu link.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The relative level in the tree.',
  `component_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__extensions.id',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__users.id',
  `checked_out_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The click behaviour of the link.',
  `access` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The access level required to view the menu item.',
  `img` varchar(255) NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `home` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`,`language`),
  KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`),
  KEY `idx_menutype` (`menutype`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_path` (`path`(255)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=153 ;

--
-- Dumping data for table 'sas_menu'
--

INSERT INTO `sas_menu` VALUES
(1, '', 'Menu_Item_Root', 'root', '', '', '', '', 1, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, 0, '', 0, '', 0, 137, 0, '*', 0),
(2, 'menu', 'com_banners', 'Banners', '', 'Banners', 'index.php?option=com_banners', 'component', 0, 1, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 1, 10, 0, '*', 1),
(3, 'menu', 'com_banners', 'Banners', '', 'Banners/Banners', 'index.php?option=com_banners', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 2, 3, 0, '*', 1),
(4, 'menu', 'com_banners_categories', 'Categories', '', 'Banners/Categories', 'index.php?option=com_categories&extension=com_banners', 'component', 0, 2, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-cat', 0, '', 4, 5, 0, '*', 1),
(5, 'menu', 'com_banners_clients', 'Clients', '', 'Banners/Clients', 'index.php?option=com_banners&view=clients', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-clients', 0, '', 6, 7, 0, '*', 1),
(6, 'menu', 'com_banners_tracks', 'Tracks', '', 'Banners/Tracks', 'index.php?option=com_banners&view=tracks', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-tracks', 0, '', 8, 9, 0, '*', 1),
(7, 'menu', 'com_contact', 'Contacts', '', 'Contacts', 'index.php?option=com_contact', 'component', 0, 1, 1, 8, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 11, 16, 0, '*', 1),
(8, 'menu', 'com_contact', 'Contacts', '', 'Contacts/Contacts', 'index.php?option=com_contact', 'component', 0, 7, 2, 8, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 12, 13, 0, '*', 1),
(9, 'menu', 'com_contact_categories', 'Categories', '', 'Contacts/Categories', 'index.php?option=com_categories&extension=com_contact', 'component', 0, 7, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact-cat', 0, '', 14, 15, 0, '*', 1),
(10, 'menu', 'com_messages', 'Messaging', '', 'Messaging', 'index.php?option=com_messages', 'component', 0, 1, 1, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages', 0, '', 17, 22, 0, '*', 1),
(11, 'menu', 'com_messages_add', 'New Private Message', '', 'Messaging/New Private Message', 'index.php?option=com_messages&task=message.add', 'component', 0, 10, 2, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-add', 0, '', 18, 19, 0, '*', 1),
(12, 'menu', 'com_messages_read', 'Read Private Message', '', 'Messaging/Read Private Message', 'index.php?option=com_messages', 'component', 0, 10, 2, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-read', 0, '', 20, 21, 0, '*', 1),
(13, 'menu', 'com_newsfeeds', 'News Feeds', '', 'News Feeds', 'index.php?option=com_newsfeeds', 'component', 0, 1, 1, 17, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 23, 28, 0, '*', 1),
(14, 'menu', 'com_newsfeeds_feeds', 'Feeds', '', 'News Feeds/Feeds', 'index.php?option=com_newsfeeds', 'component', 0, 13, 2, 17, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 24, 25, 0, '*', 1),
(15, 'menu', 'com_newsfeeds_categories', 'Categories', '', 'News Feeds/Categories', 'index.php?option=com_categories&extension=com_newsfeeds', 'component', 0, 13, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds-cat', 0, '', 26, 27, 0, '*', 1),
(16, 'menu', 'com_redirect', 'Redirect', '', 'Redirect', 'index.php?option=com_redirect', 'component', 0, 1, 1, 24, 0, '0000-00-00 00:00:00', 0, 0, 'class:redirect', 0, '', 29, 30, 0, '*', 1),
(17, 'menu', 'com_search', 'Basic Search', '', 'Basic Search', 'index.php?option=com_search', 'component', 0, 1, 1, 19, 0, '0000-00-00 00:00:00', 0, 0, 'class:search', 0, '', 31, 32, 0, '*', 1),
(18, 'menu', 'com_weblinks', 'Weblinks', '', 'Weblinks', 'index.php?option=com_weblinks', 'component', 0, 1, 1, 21, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks', 0, '', 33, 38, 0, '*', 1),
(19, 'menu', 'com_weblinks_links', 'Links', '', 'Weblinks/Links', 'index.php?option=com_weblinks', 'component', 0, 18, 2, 21, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks', 0, '', 34, 35, 0, '*', 1),
(20, 'menu', 'com_weblinks_categories', 'Categories', '', 'Weblinks/Categories', 'index.php?option=com_categories&extension=com_weblinks', 'component', 0, 18, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks-cat', 0, '', 36, 37, 0, '*', 1),
(21, 'menu', 'com_finder', 'Smart Search', '', 'Smart Search', 'index.php?option=com_finder', 'component', 0, 1, 1, 27, 0, '0000-00-00 00:00:00', 0, 0, 'class:finder', 0, '', 39, 40, 0, '*', 1),
(22, 'menu', 'com_joomlaupdate', 'Joomla! Update', '', 'Joomla! Update', 'index.php?option=com_joomlaupdate', 'component', 1, 1, 1, 28, 0, '0000-00-00 00:00:00', 0, 0, 'class:joomlaupdate', 0, '', 41, 42, 0, '*', 1),
(23, 'main', 'com_tags', 'Tags', '', 'Tags', 'index.php?option=com_tags', 'component', 0, 1, 1, 29, 0, '0000-00-00 00:00:00', 0, 1, 'class:tags', 0, '', 43, 44, 0, '', 1),
(24, 'main', 'com_postinstall', 'Post-installation messages', '', 'Post-installation messages', 'index.php?option=com_postinstall', 'component', 0, 1, 1, 32, 0, '0000-00-00 00:00:00', 0, 1, 'class:postinstall', 0, '', 45, 46, 0, '*', 1),
(101, 'mainmenu', 'Home', 'home', '', 'home', 'index.php?option=com_content&view=featured', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"featured_categories":[""],"layout_type":"blog","num_leading_articles":"1","num_intro_articles":"3","num_columns":"3","num_links":"0","multi_column_order":"1","orderby_pri":"","orderby_sec":"front","order_date":"","show_pagination":"2","show_pagination_results":"1","show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_readmore":"","show_readmore_title":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":1,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 47, 48, 1, '*', 0),
(102, 'main', 'JCE', 'jce', '', 'jce', 'index.php?option=com_jce', 'component', 0, 1, 1, 10006, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_jce/media/img/menu/logo.png', 0, '', 49, 58, 0, '', 1),
(103, 'main', 'WF_MENU_CPANEL', 'wf-menu-cpanel', '', 'jce/wf-menu-cpanel', 'index.php?option=com_jce', 'component', 0, 102, 2, 10006, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_jce/media/img/menu/jce-cpanel.png', 0, '', 50, 51, 0, '', 1),
(104, 'main', 'WF_MENU_CONFIG', 'wf-menu-config', '', 'jce/wf-menu-config', 'index.php?option=com_jce&view=config', 'component', 0, 102, 2, 10006, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_jce/media/img/menu/jce-config.png', 0, '', 52, 53, 0, '', 1),
(105, 'main', 'WF_MENU_PROFILES', 'wf-menu-profiles', '', 'jce/wf-menu-profiles', 'index.php?option=com_jce&view=profiles', 'component', 0, 102, 2, 10006, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_jce/media/img/menu/jce-profiles.png', 0, '', 54, 55, 0, '', 1),
(106, 'main', 'WF_MENU_INSTALL', 'wf-menu-install', '', 'jce/wf-menu-install', 'index.php?option=com_jce&view=installer', 'component', 0, 102, 2, 10006, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_jce/media/img/menu/jce-install.png', 0, '', 56, 57, 0, '', 1),
(107, 'main', 'COM_AKEEBA', 'com-akeeba', '', 'com-akeeba', 'index.php?option=com_akeeba', 'component', 0, 1, 1, 10007, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_akeeba/icons/akeeba-16.png', 0, '', 59, 60, 0, '', 1),
(108, 'main', 'COM_K2', 'com-k2', '', 'com-k2', 'index.php?option=com_k2', 'component', 0, 1, 1, 10010, 0, '0000-00-00 00:00:00', 0, 1, '../media/k2/assets/images/system/k2_16x16.png', 0, '', 61, 82, 0, '', 1),
(109, 'main', 'K2_ITEMS', 'k2-items', '', 'com-k2/k2-items', 'index.php?option=com_k2&view=items', 'component', 0, 108, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 62, 63, 0, '', 1),
(110, 'main', 'K2_CATEGORIES', 'k2-categories', '', 'com-k2/k2-categories', 'index.php?option=com_k2&view=categories', 'component', 0, 108, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 64, 65, 0, '', 1),
(111, 'main', 'K2_TAGS', 'k2-tags', '', 'com-k2/k2-tags', 'index.php?option=com_k2&view=tags', 'component', 0, 108, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 66, 67, 0, '', 1),
(112, 'main', 'K2_COMMENTS', 'k2-comments', '', 'com-k2/k2-comments', 'index.php?option=com_k2&view=comments', 'component', 0, 108, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 68, 69, 0, '', 1),
(113, 'main', 'K2_USERS', 'k2-users', '', 'com-k2/k2-users', 'index.php?option=com_k2&view=users', 'component', 0, 108, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 70, 71, 0, '', 1),
(114, 'main', 'K2_USER_GROUPS', 'k2-user-groups', '', 'com-k2/k2-user-groups', 'index.php?option=com_k2&view=usergroups', 'component', 0, 108, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 72, 73, 0, '', 1),
(115, 'main', 'K2_EXTRA_FIELDS', 'k2-extra-fields', '', 'com-k2/k2-extra-fields', 'index.php?option=com_k2&view=extrafields', 'component', 0, 108, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 74, 75, 0, '', 1),
(116, 'main', 'K2_EXTRA_FIELD_GROUPS', 'k2-extra-field-groups', '', 'com-k2/k2-extra-field-groups', 'index.php?option=com_k2&view=extrafieldsgroups', 'component', 0, 108, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 76, 77, 0, '', 1),
(117, 'main', 'K2_MEDIA_MANAGER', 'k2-media-manager', '', 'com-k2/k2-media-manager', 'index.php?option=com_k2&view=media', 'component', 0, 108, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 78, 79, 0, '', 1),
(118, 'main', 'K2_INFORMATION', 'k2-information', '', 'com-k2/k2-information', 'index.php?option=com_k2&view=info', 'component', 0, 108, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 80, 81, 0, '', 1),
(126, 'main', 'COM_SOBIPRO', 'com-sobipro', '', 'com-sobipro', 'index.php?option=com_sobipro', 'component', 0, 1, 1, 10027, 0, '0000-00-00 00:00:00', 0, 1, '../media/sobipro/sp_16.png', 0, '', 83, 84, 0, '', 1),
(127, 'main', 'AcyMailing', 'acymailing', '', 'acymailing', 'index.php?option=com_acymailing', 'component', 0, 1, 1, 10028, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_acymailing/images/icons/icon-16-acymailing.png', 0, '', 85, 102, 0, '', 1),
(128, 'main', 'Users', 'users', '', 'acymailing/users', 'index.php?option=com_acymailing&ctrl=subscriber', 'component', 0, 127, 2, 10028, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_acymailing/images/icons/icon-16-users.png', 0, '', 86, 87, 0, '', 1),
(129, 'main', 'Lists', 'lists', '', 'acymailing/lists', 'index.php?option=com_acymailing&ctrl=list', 'component', 0, 127, 2, 10028, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_acymailing/images/icons/icon-16-acylist.png', 0, '', 88, 89, 0, '', 1),
(130, 'main', 'Newsletters', 'newsletters', '', 'acymailing/newsletters', 'index.php?option=com_acymailing&ctrl=newsletter', 'component', 0, 127, 2, 10028, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_acymailing/images/icons/icon-16-newsletter.png', 0, '', 90, 91, 0, '', 1),
(131, 'main', 'Templates', 'templates', '', 'acymailing/templates', 'index.php?option=com_acymailing&ctrl=template', 'component', 0, 127, 2, 10028, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_acymailing/images/icons/icon-16-acytemplate.png', 0, '', 92, 93, 0, '', 1),
(132, 'main', 'Queue', 'queue', '', 'acymailing/queue', 'index.php?option=com_acymailing&ctrl=queue', 'component', 0, 127, 2, 10028, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_acymailing/images/icons/icon-16-process.png', 0, '', 94, 95, 0, '', 1),
(133, 'main', 'Statistics', 'statistics', '', 'acymailing/statistics', 'index.php?option=com_acymailing&ctrl=stats', 'component', 0, 127, 2, 10028, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_acymailing/images/icons/icon-16-stats.png', 0, '', 96, 97, 0, '', 1),
(134, 'main', 'Configuration', 'configuration', '', 'acymailing/configuration', 'index.php?option=com_acymailing&ctrl=cpanel', 'component', 0, 127, 2, 10028, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_acymailing/images/icons/icon-16-acyconfig.png', 0, '', 98, 99, 0, '', 1),
(135, 'main', 'Update_About', 'update-about', '', 'acymailing/update-about', 'index.php?option=com_acymailing&ctrl=update', 'component', 0, 127, 2, 10028, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_acymailing/images/icons/icon-16-update.png', 0, '', 100, 101, 0, '', 1),
(136, 'main', 'COM_CONTENTMAP_MENU', 'com-contentmap-menu', '', 'com-contentmap-menu', 'index.php?option=com_contentmap', 'component', 0, 1, 1, 10048, 0, '0000-00-00 00:00:00', 0, 1, '../media/contentmap/images/map-16.png', 0, '', 103, 104, 0, '', 1),
(137, 'main', 'COM_FLEXBANNERS_MENU_FLEXBANNER', 'com-flexbanners-menu-flexbanner', '', 'com-flexbanners-menu-flexbanner', 'index.php?option=com_flexbanners', 'component', 0, 1, 1, 10024, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_flexbanners/flexbanner-16.png', 0, '', 105, 118, 0, '', 1),
(138, 'main', 'COM_FLEXBANNERS_MENU_FLEXBANNER', 'com-flexbanners-menu-flexbanner', '', 'com-flexbanners-menu-flexbanner/com-flexbanners-menu-flexbanner', 'index.php?option=com_flexbanners', 'component', 0, 137, 2, 10024, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_flexbanners/flexbanner-16.png', 0, '', 106, 107, 0, '', 1),
(139, 'main', 'COM_FLEXBANNERS_MENU_CATEGORY', 'com-flexbanners-menu-category', '', 'com-flexbanners-menu-flexbanner/com-flexbanners-menu-category', 'index.php?option=com_categories&extension=com_flexbanners', 'component', 0, 137, 2, 10024, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_flexbanners/flexbanner-16.png', 0, '', 108, 109, 0, '', 1),
(140, 'main', 'COM_FLEXBANNERS_MENU_CLIENTS', 'com-flexbanners-menu-clients', '', 'com-flexbanners-menu-flexbanner/com-flexbanners-menu-clients', 'index.php?option=com_flexbanners&view=clients', 'component', 0, 137, 2, 10024, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_flexbanners/flexbanner-16.png', 0, '', 110, 111, 0, '', 1),
(141, 'main', 'COM_FLEXBANNERS_MENU_LINKS', 'com-flexbanners-menu-links', '', 'com-flexbanners-menu-flexbanner/com-flexbanners-menu-links', 'index.php?option=com_flexbanners&view=links', 'component', 0, 137, 2, 10024, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_flexbanners/flexbanner-16.png', 0, '', 112, 113, 0, '', 1),
(142, 'main', 'COM_FLEXBANNERS_MENU_LOCATIONS', 'com-flexbanners-menu-locations', '', 'com-flexbanners-menu-flexbanner/com-flexbanners-menu-locations', 'index.php?option=com_flexbanners&view=locations', 'component', 0, 137, 2, 10024, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_flexbanners/flexbanner-16.png', 0, '', 114, 115, 0, '', 1),
(143, 'main', 'COM_FLEXBANNERS_MENU_SIZES', 'com-flexbanners-menu-sizes', '', 'com-flexbanners-menu-flexbanner/com-flexbanners-menu-sizes', 'index.php?option=com_flexbanners&view=sizes', 'component', 0, 137, 2, 10024, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_flexbanners/flexbanner-16.png', 0, '', 116, 117, 0, '', 1),
(144, 'main', 'FG_FEED_GATOR', 'fg-feed-gator', '', 'fg-feed-gator', 'index.php?option=com_feedgator', 'component', 0, 1, 1, 10049, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_feedgator/images/feedgator_16.png', 0, '', 119, 136, 0, '', 1),
(145, 'main', 'FG_CPANEL', 'fg-cpanel', '', 'fg-feed-gator/fg-cpanel', 'index.php?option=com_feedgator&task=cpanel', 'component', 0, 144, 2, 10049, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 120, 121, 0, '', 1),
(146, 'main', 'FG_MAN_FEEDS', 'fg-man-feeds', '', 'fg-feed-gator/fg-man-feeds', 'index.php?option=com_feedgator&task=feeds', 'component', 0, 144, 2, 10049, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 122, 123, 0, '', 1),
(147, 'main', 'FG_SETTINGS', 'fg-settings', '', 'fg-feed-gator/fg-settings', 'index.php?option=com_feedgator&task=settings', 'component', 0, 144, 2, 10049, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 124, 125, 0, '', 1),
(148, 'main', 'FG_PLUGINS', 'fg-plugins', '', 'fg-feed-gator/fg-plugins', 'index.php?option=com_feedgator&task=plugins', 'component', 0, 144, 2, 10049, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 126, 127, 0, '', 1),
(149, 'main', 'FG_TOOLS', 'fg-tools', '', 'fg-feed-gator/fg-tools', 'index.php?option=com_feedgator&task=tools', 'component', 0, 144, 2, 10049, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 128, 129, 0, '', 1),
(150, 'main', 'FG_IMPORTS', 'fg-imports', '', 'fg-feed-gator/fg-imports', 'index.php?option=com_feedgator&task=imports', 'component', 0, 144, 2, 10049, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 130, 131, 0, '', 1),
(151, 'main', 'FG_SUPPORT', 'fg-support', '', 'fg-feed-gator/fg-support', 'index.php?option=com_feedgator&task=support', 'component', 0, 144, 2, 10049, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 132, 133, 0, '', 1),
(152, 'main', 'FG_ABOUT', 'fg-about', '', 'fg-feed-gator/fg-about', 'index.php?option=com_feedgator&task=about', 'component', 0, 144, 2, 10049, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 134, 135, 0, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table`sas_menu_types`
--

CREATE TABLE `sas_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL,
  `title` varchar(48) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_menutype` (`menutype`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table 'sas_menu_types'
--

INSERT INTO `sas_menu_types` VALUES
(1, 'mainmenu', 'Main Menu', 'The main menu for the site');

-- --------------------------------------------------------

--
-- Table structure for table`sas_messages`
--

CREATE TABLE `sas_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_messages_cfg`
--

CREATE TABLE `sas_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_modules`
--

CREATE TABLE `sas_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(100) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) NOT NULL DEFAULT '',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=97 ;

--
-- Dumping data for table 'sas_modules'
--

INSERT INTO `sas_modules` VALUES
(1, 55, 'Main Menu', '', '', 1, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"mainmenu","startLevel":"0","endLevel":"0","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"","moduleclass_sfx":"_menu","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(2, 56, 'Login', '', '', 1, 'login', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '', 1, '*'),
(3, 57, 'Popular Articles', '', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_popular', 3, 1, '{"count":"5","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(4, 58, 'Recently Added Articles', '', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_latest', 3, 1, '{"count":"5","ordering":"c_dsc","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(8, 59, 'Toolbar', '', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_toolbar', 3, 1, '', 1, '*'),
(9, 60, 'Quick Icons', '', '', 1, 'icon', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_quickicon', 3, 1, '', 1, '*'),
(10, 61, 'Logged-in Users', '', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_logged', 3, 1, '{"count":"5","name":"1","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(12, 62, 'Admin Menu', '', '', 1, 'menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 3, 1, '{"layout":"","moduleclass_sfx":"","shownew":"1","showhelp":"1","cache":"0"}', 1, '*'),
(13, 63, 'Admin Submenu', '', '', 1, 'submenu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_submenu', 3, 1, '', 1, '*'),
(14, 64, 'User Status', '', '', 2, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_status', 3, 1, '', 1, '*'),
(15, 65, 'Title', '', '', 1, 'title', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_title', 3, 1, '', 1, '*'),
(16, 66, 'Login Form', '', '', 7, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '{"greeting":"1","name":"0"}', 0, '*'),
(17, 67, 'Breadcrumbs', '', '', 1, 'position-2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 1, 1, '{"moduleclass_sfx":"","showHome":"1","homeText":"","showComponent":"1","separator":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(79, 68, 'Multilanguage status', '', '', 1, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_multilangstatus', 3, 1, '{"layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(86, 69, 'Joomla Version', '', '', 1, 'footer', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_version', 3, 1, '{"format":"short","product":"1","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(87, 57, 'K2 Comments', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_k2_comments', 1, 1, '', 0, '*'),
(88, 58, 'K2 Content', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_k2_content', 1, 1, '', 0, '*'),
(89, 59, 'K2 Tools', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_k2_tools', 1, 1, '', 0, '*'),
(90, 60, 'K2 Users', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_k2_users', 1, 1, '', 0, '*'),
(91, 61, 'K2 User', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_k2_user', 1, 1, '', 0, '*'),
(92, 62, 'K2 Quick Icons (admin)', '', '', 0, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_k2_quickicons', 1, 1, '', 1, '*'),
(93, 63, 'K2 Stats (admin)', '', '', 0, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_k2_stats', 1, 1, '', 1, '*'),
(94, 65, 'FlexBanners', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_flexbanners', 1, 1, '', 0, '*'),
(95, 0, 'AcyMailing Module', '', '', 0, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_acymailing', 1, 1, '', 0, '*');

-- --------------------------------------------------------

--
-- Table structure for table`sas_modules_menu`
--

CREATE TABLE `sas_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_modules_menu'
--

INSERT INTO `sas_modules_menu` VALUES
(1, 0),
(2, 0),
(3, 0),
(4, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(12, 0),
(13, 0),
(14, 0),
(15, 0),
(16, 0),
(17, 0),
(79, 0),
(86, 0),
(92, 0),
(93, 0),
(95, 0);

-- --------------------------------------------------------

--
-- Table structure for table`sas_newsfeeds`
--

CREATE TABLE `sas_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `link` varchar(200) NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(10) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(10) unsigned NOT NULL DEFAULT '3600',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `description` text NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `images` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_overrider`
--

CREATE TABLE `sas_overrider` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `constant` varchar(255) NOT NULL,
  `string` text NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_postinstall_messages`
--

CREATE TABLE `sas_postinstall_messages` (
  `postinstall_message_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `extension_id` bigint(20) NOT NULL DEFAULT '700' COMMENT 'FK to #__extensions',
  `title_key` varchar(255) NOT NULL DEFAULT '' COMMENT 'Lang key for the title',
  `description_key` varchar(255) NOT NULL DEFAULT '' COMMENT 'Lang key for description',
  `action_key` varchar(255) NOT NULL DEFAULT '',
  `language_extension` varchar(255) NOT NULL DEFAULT 'com_postinstall' COMMENT 'Extension holding lang keys',
  `language_client_id` tinyint(3) NOT NULL DEFAULT '1',
  `type` varchar(10) NOT NULL DEFAULT 'link' COMMENT 'Message type - message, link, action',
  `action_file` varchar(255) DEFAULT '' COMMENT 'RAD URI to the PHP file containing action method',
  `action` varchar(255) DEFAULT '' COMMENT 'Action method name or URL',
  `condition_file` varchar(255) DEFAULT NULL COMMENT 'RAD URI to file holding display condition method',
  `condition_method` varchar(255) DEFAULT NULL COMMENT 'Display condition method, must return boolean',
  `version_introduced` varchar(50) NOT NULL DEFAULT '3.2.0' COMMENT 'Version when this message was introduced',
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`postinstall_message_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table 'sas_postinstall_messages'
--

INSERT INTO `sas_postinstall_messages` VALUES
(1, 700, 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_TITLE', 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_BODY', 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_ACTION', 'plg_twofactorauth_totp', 1, 'action', 'site://plugins/twofactorauth/totp/postinstall/actions.php', 'twofactorauth_postinstall_action', 'site://plugins/twofactorauth/totp/postinstall/actions.php', 'twofactorauth_postinstall_condition', '3.2.0', 1),
(2, 700, 'COM_CPANEL_MSG_EACCELERATOR_TITLE', 'COM_CPANEL_MSG_EACCELERATOR_BODY', 'COM_CPANEL_MSG_EACCELERATOR_BUTTON', 'com_cpanel', 1, 'action', 'admin://components/com_admin/postinstall/eaccelerator.php', 'admin_postinstall_eaccelerator_action', 'admin://components/com_admin/postinstall/eaccelerator.php', 'admin_postinstall_eaccelerator_condition', '3.2.0', 1),
(3, 700, 'COM_CPANEL_WELCOME_BEGINNERS_TITLE', 'COM_CPANEL_WELCOME_BEGINNERS_MESSAGE', '', 'com_cpanel', 1, 'message', '', '', '', '', '3.2.0', 1),
(4, 700, 'COM_CPANEL_MSG_PHPVERSION_TITLE', 'COM_CPANEL_MSG_PHPVERSION_BODY', '', 'com_cpanel', 1, 'message', '', '', 'admin://components/com_admin/postinstall/phpversion.php', 'admin_postinstall_phpversion_condition', '3.2.2', 1);

-- --------------------------------------------------------

--
-- Table structure for table`sas_redirect_links`
--

CREATE TABLE `sas_redirect_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_url` varchar(255) NOT NULL,
  `new_url` varchar(255) NOT NULL,
  `referer` varchar(150) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_link_old` (`old_url`),
  KEY `idx_link_modifed` (`modified_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_schemas`
--

CREATE TABLE `sas_schemas` (
  `extension_id` int(11) NOT NULL,
  `version_id` varchar(20) NOT NULL,
  PRIMARY KEY (`extension_id`,`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_schemas'
--

INSERT INTO `sas_schemas` VALUES
(700, '3.2.3-2014-02-20'),
(10007, '3.6.0-2012-07-31'),
(10024, '4.0.16');

-- --------------------------------------------------------

--
-- Table structure for table`sas_session`
--

CREATE TABLE `sas_session` (
  `session_id` varchar(200) NOT NULL DEFAULT '',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guest` tinyint(4) unsigned DEFAULT '1',
  `time` varchar(14) DEFAULT '',
  `data` mediumtext,
  `userid` int(11) DEFAULT '0',
  `username` varchar(150) DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_session'
--

INSERT INTO `sas_session` VALUES
('7un9h6psj5b2h6l9lamq2npks3', 1, 1, '1398039284', '__default|a:8:{s:15:"session.counter";i:14;s:19:"session.timer.start";i:1398038711;s:18:"session.timer.last";i:1398039283;s:17:"session.timer.now";i:1398039283;s:22:"session.client.browser";s:72:"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:28.0) Gecko/20100101 Firefox/28.0";s:8:"registry";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":1:{s:11:"application";O:8:"stdClass":1:{s:4:"lang";s:5:"en-GB";}}}s:4:"user";O:5:"JUser":24:{s:9:"\\0\\0\\0isRoot";b:0;s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:5:"block";N;s:9:"sendEmail";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:6:"groups";a:1:{i:0;s:1:"9";}s:5:"guest";i:1;s:13:"lastResetTime";N;s:10:"resetCount";N;s:10:"\\0\\0\\0_params";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}}s:14:"\\0\\0\\0_authGroups";a:2:{i:0;i:1;i:1;i:9;}s:14:"\\0\\0\\0_authLevels";a:3:{i:0;i:1;i:1;i:1;i:2;i:5;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;}s:13:"session.token";s:32:"57799e860a06a5885a5316ba7b02ed4d";}', 0, ''),
('8gf41hq75ga6rq24jrv7n3l296', 1, 1, '1398019859', '__default|a:8:{s:15:"session.counter";i:1;s:19:"session.timer.start";i:1398019858;s:18:"session.timer.last";i:1398019858;s:17:"session.timer.now";i:1398019858;s:22:"session.client.browser";s:70:"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; HbTools 4.7.1)";s:8:"registry";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}}s:4:"user";O:5:"JUser":24:{s:9:"\\0\\0\\0isRoot";b:0;s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:5:"block";N;s:9:"sendEmail";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:6:"groups";a:1:{i:0;s:1:"9";}s:5:"guest";i:1;s:13:"lastResetTime";N;s:10:"resetCount";N;s:10:"\\0\\0\\0_params";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}}s:14:"\\0\\0\\0_authGroups";a:2:{i:0;i:1;i:1;i:9;}s:14:"\\0\\0\\0_authLevels";a:3:{i:0;i:1;i:1;i:1;i:2;i:5;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;}s:13:"session.token";s:32:"f1c556e8cad234e4b24f8638d43b623e";}', 0, ''),
('jlp1ms1ja8613p8t05dc9qo466', 1, 1, '1398039198', '__default|a:8:{s:15:"session.counter";i:5;s:19:"session.timer.start";i:1398039092;s:18:"session.timer.last";i:1398039197;s:17:"session.timer.now";i:1398039198;s:22:"session.client.browser";s:72:"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:24.0) Gecko/20100101 Firefox/24.0";s:8:"registry";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":1:{s:11:"application";O:8:"stdClass":1:{s:4:"lang";s:5:"en-GB";}}}s:4:"user";O:5:"JUser":24:{s:9:"\\0\\0\\0isRoot";b:0;s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:5:"block";N;s:9:"sendEmail";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:6:"groups";a:1:{i:0;s:1:"9";}s:5:"guest";i:1;s:13:"lastResetTime";N;s:10:"resetCount";N;s:10:"\\0\\0\\0_params";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}}s:14:"\\0\\0\\0_authGroups";a:2:{i:0;i:1;i:1;i:9;}s:14:"\\0\\0\\0_authLevels";a:3:{i:0;i:1;i:1;i:1;i:2;i:5;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;}s:13:"session.token";s:32:"a260bc91cb876de45cfd562e25f38cf3";}', 0, ''),
('niib04npomdahudvigqgt3akv1', 0, 1, '1398039174', '__default|a:8:{s:15:"session.counter";i:1;s:19:"session.timer.start";i:1398039174;s:18:"session.timer.last";i:1398039174;s:17:"session.timer.now";i:1398039174;s:22:"session.client.browser";s:104:"Mozilla/5.0 (compatible; NetSeer crawler/2.0; +http://www.netseer.com/crawler.html; crawler@netseer.com)";s:8:"registry";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}}s:4:"user";O:5:"JUser":24:{s:9:"\\0\\0\\0isRoot";b:0;s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:5:"block";N;s:9:"sendEmail";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:6:"groups";a:1:{i:0;s:1:"9";}s:5:"guest";i:1;s:13:"lastResetTime";N;s:10:"resetCount";N;s:10:"\\0\\0\\0_params";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}}s:14:"\\0\\0\\0_authGroups";a:2:{i:0;i:1;i:1;i:9;}s:14:"\\0\\0\\0_authLevels";a:3:{i:0;i:1;i:1;i:1;i:2;i:5;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;}s:13:"session.token";s:32:"ebc1536e023ac8969248e11053b38c94";}', 0, ''),
('np48gdt970ps7g8bo39sioq1q3', 0, 1, '1398029745', '__default|a:8:{s:15:"session.counter";i:1;s:19:"session.timer.start";i:1398029745;s:18:"session.timer.last";i:1398029745;s:17:"session.timer.now";i:1398029745;s:22:"session.client.browser";s:55:"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)";s:8:"registry";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}}s:4:"user";O:5:"JUser":24:{s:9:"\\0\\0\\0isRoot";b:0;s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:5:"block";N;s:9:"sendEmail";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:6:"groups";a:1:{i:0;s:1:"9";}s:5:"guest";i:1;s:13:"lastResetTime";N;s:10:"resetCount";N;s:10:"\\0\\0\\0_params";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}}s:14:"\\0\\0\\0_authGroups";a:2:{i:0;i:1;i:1;i:9;}s:14:"\\0\\0\\0_authLevels";a:3:{i:0;i:1;i:1;i:1;i:2;i:5;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;}s:13:"session.token";s:32:"7d3413e13927fd2c251744d4aaf04b1a";}', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_category`
--

CREATE TABLE `sas_sobipro_category` (
  `id` int(11) NOT NULL,
  `position` int(11) DEFAULT NULL,
  `description` text,
  `parseDesc` enum('0','1','2') NOT NULL DEFAULT '2',
  `introtext` varchar(255) NOT NULL,
  `showIntrotext` enum('0','1','2') NOT NULL DEFAULT '2',
  `icon` varchar(150) DEFAULT NULL,
  `showIcon` enum('0','1','2') NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_sobipro_category'
--

INSERT INTO `sas_sobipro_category` VALUES
(2, 1, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque  laoreet rhoncus tempor. Suspendisse dapibus vulputate dolor ut  tincidunt. Suspendisse tristique laoreet dui, ut tempor orci dictum ut.  Quisque aliquam urna ac justo tristique interdum. Aliquam in dui eget  lectus elementum lacinia eget eu sem. Nam eu felis tellus, ac cursus  velit. Etiam magna libero, condimentum at facilisis a, fermentum eget  leo.</p>', '2', '', '2', 'tmpl/default/laptop.png', '2'),
(3, 2, '', '2', '', '2', 'tmpl/default/Cardgame.png', '2'),
(4, 3, '', '2', '', '2', 'tmpl/default/virussafe.png', '2'),
(5, 4, '', '2', '', '2', 'tmpl/default/folder_home.png', '2'),
(6, 5, '', '2', '', '2', 'tmpl/default/knewsticker.png', '2'),
(7, 6, '', '2', '', '2', 'tmpl/default/view-barcode-add.png', '2'),
(8, 1, '', '2', '', '2', 'tmpl/default/kblogger.png', '2'),
(9, 0, '', '2', '', '2', 'tmpl/default/video-x-mng.png', '2'),
(10, 0, '', '2', '', '2', 'tmpl/default/media-flash.png', '2'),
(11, 0, '', '2', '', '2', 'tmpl/default/pda.png', '2'),
(12, 0, '', '2', '', '2', 'tmpl/default/multimedia.png', '2'),
(13, 0, '', '2', '', '2', 'tmpl/default/meeting-attending.png', '2'),
(14, 0, '', '2', '', '2', 'tmpl/default/applications-games.png', '2'),
(15, 2, '', '2', '', '2', 'tmpl/default/mouse.png', '2'),
(16, 3, '', '2', '', '2', 'tmpl/default/ksirtet.png', '2'),
(17, 4, '', '2', '', '2', 'tmpl/default/joystick.png', '2'),
(18, 1, '', '2', '', '2', 'tmpl/default/kcoloredit.png', '2'),
(19, 2, '', '2', '', '2', 'tmpl/default/agt_login.png', '2'),
(20, 3, '', '2', '', '2', 'tmpl/default/applications-education-science.png', '2'),
(21, 4, '', '2', '', '2', 'tmpl/default/cookie.png', '2'),
(22, 5, '', '2', '', '2', 'tmpl/default/applications-development.png', '2'),
(23, 6, '', '2', '', '2', 'tmpl/default/pack.png', '2'),
(24, 7, '', '2', '', '2', 'tmpl/default/spread.png', '2'),
(25, 8, '', '2', '', '2', 'tmpl/default/bird.png', '2'),
(26, 9, '', '2', '', '2', 'tmpl/default/chat.png', '2'),
(27, 10, '', '2', '', '2', 'tmpl/default/date.png', '2'),
(28, 0, '', '2', '', '2', 'tmpl/default/text-rdf.png', '2'),
(29, 12, '', '2', '', '2', 'tmpl/default/tv.png', '2'),
(30, 13, '', '2', '', '2', 'tmpl/default/weather.png', '2'),
(31, 0, '', '2', '', '2', 'tmpl/default/accessories-dictionary.png', '2'),
(32, 0, '', '2', '', '2', 'tmpl/default/multimedia.png', '2'),
(33, 0, '', '2', '', '2', 'tmpl/default/fork.png', '2'),
(34, 0, '', '2', '', '2', 'tmpl/default/applications-engineering.png', '2'),
(35, 7, '', '2', '', '2', 'tmpl/default/synaptic.png', '2'),
(36, 1, '', '2', '', '2', 'tmpl/default/ktron.png', '2');

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_config`
--

CREATE TABLE `sas_sobipro_config` (
  `sKey` varchar(150) NOT NULL DEFAULT '',
  `sValue` text,
  `section` int(11) NOT NULL DEFAULT '0',
  `critical` tinyint(1) DEFAULT NULL,
  `cSection` varchar(30) NOT NULL,
  PRIMARY KEY (`sKey`,`section`,`cSection`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_sobipro_config'
--

INSERT INTO `sas_sobipro_config` VALUES
('allowed_attributes_array', 'YTo4OntpOjA7czo1OiJjbGFzcyI7aToxO3M6MjoiaWQiO2k6MjtzOjU6InN0eWxlIjtpOjM7czo0OiJocmVmIjtpOjQ7czozOiJzcmMiO2k6NTtzOjQ6Im5hbWUiO2k6NjtzOjM6ImFsdCI7aTo3O3M6NToidGl0bGUiO30=', 0, 0, 'html'),
('allowed_attributes_array', 'YTo4OntpOjA7czo1OiJjbGFzcyI7aToxO3M6MjoiaWQiO2k6MjtzOjU6InN0eWxlIjtpOjM7czo0OiJocmVmIjtpOjQ7czozOiJzcmMiO2k6NTtzOjQ6Im5hbWUiO2k6NjtzOjM6ImFsdCI7aTo3O3M6NToidGl0bGUiO30=', 1, 0, 'html'),
('allowed_tags_array', 'YToxNzp7aTowO3M6MToiYSI7aToxO3M6MToicCI7aToyO3M6MjoiYnIiO2k6MztzOjI6ImhyIjtpOjQ7czozOiJkaXYiO2k6NTtzOjI6ImxpIjtpOjY7czoyOiJ1bCI7aTo3O3M6NDoic3BhbiI7aTo4O3M6NToidGFibGUiO2k6OTtzOjI6InRyIjtpOjEwO3M6MjoidGQiO2k6MTE7czozOiJpbWciO2k6MTI7czoyOiJoMSI7aToxMztzOjI6ImgyIjtpOjE0O3M6MjoiaDMiO2k6MTU7czoyOiJoNCI7aToxNjtzOjI6Img1Ijt9', 0, 0, 'html'),
('allowed_tags_array', 'YToxNzp7aTowO3M6MToiYSI7aToxO3M6MToicCI7aToyO3M6MjoiYnIiO2k6MztzOjI6ImhyIjtpOjQ7czozOiJkaXYiO2k6NTtzOjI6ImxpIjtpOjY7czoyOiJ1bCI7aTo3O3M6NDoic3BhbiI7aTo4O3M6NToidGFibGUiO2k6OTtzOjI6InRyIjtpOjEwO3M6MjoidGQiO2k6MTE7czozOiJpbWciO2k6MTI7czoyOiJoMSI7aToxMztzOjI6ImgyIjtpOjE0O3M6MjoiaDMiO2k6MTU7czoyOiJoNCI7aToxNjtzOjI6Img1Ijt9', 1, 0, 'html'),
('alphamenu_extra_fields_array', '', 0, 0, 'alphamenu_extra_fields_array'),
('alphamenu_extra_fields_array', '', 1, 0, 'alphamenu_extra_fields_array'),
('always_add_entryinput', '0', 1, 0, 'meta'),
('always_add_search', '0', 1, 0, 'meta'),
('always_add_section', '0', 1, 0, 'meta'),
('categories_in_line', '2', 1, 0, 'list'),
('categories_ordering', 'name.asc', 1, 0, 'list'),
('category_access_enabled', '0', 1, 0, 'redirects'),
('category_access_msg', 'UNAUTHORIZED_ACCESS', 1, 0, 'redirects'),
('category_access_msgtype', 'info', 1, 0, 'redirects'),
('category_access_url', 'index.php', 1, 0, 'redirects'),
('cat_desc', '0', 1, 0, 'list'),
('cat_meta', '0', 1, 0, 'list'),
('compress_js', '0', 0, 0, 'cache'),
('currency', '€', 0, 0, 'payments'),
('dec_point', ',', 0, 0, 'payments'),
('discount_to_netto', '0', 0, 0, 'payments'),
('display_errors', '0', 0, 0, 'debug'),
('engb_preload', '1', 0, 0, 'lang'),
('entries_in_line', '2', 1, 0, 'list'),
('entries_limit', '10', 1, 0, 'list'),
('entries_ordering', 'position.asc', 1, 0, 'list'),
('entries_ordering', 'disabled', 1, 0, 'search'),
('entry_access_enabled', '0', 1, 0, 'redirects'),
('entry_access_msg', 'UNAUTHORIZED_ACCESS', 1, 0, 'redirects'),
('entry_access_msgtype', 'info', 1, 0, 'redirects'),
('entry_access_url', 'index.php', 1, 0, 'redirects'),
('entry_add_enabled', '0', 1, 0, 'redirects'),
('entry_add_msg', 'UNAUTHORIZED_ACCESS', 1, 0, 'redirects'),
('entry_add_msgtype', 'info', 1, 0, 'redirects'),
('entry_add_url', 'index.php', 1, 0, 'redirects'),
('entry_cats', '1', 1, 0, 'list'),
('entry_meta', '0', 1, 0, 'list'),
('entry_save_enabled', '0', 1, 0, 'redirects'),
('entry_save_msg', 'EN.ENTRY_SAVED_NA', 1, 0, 'redirects'),
('entry_save_msgtype', 'info', 1, 0, 'redirects'),
('entry_save_url', 'index.php', 1, 0, 'redirects'),
('extra_fields_array', 'YTozOntpOjA7czoxOiIyIjtpOjE7czoxOiIzIjtpOjI7czoxOiI0Ijt9', 1, 0, 'alphamenu'),
('format', '%value %currency', 0, 0, 'payments'),
('include_css_files', '1', 0, 0, 'cache'),
('include_js_files', '1', 0, 0, 'cache'),
('l3_enabled', '1', 0, 0, 'cache'),
('letters', 'A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,0-9', 1, 0, 'alphamenu'),
('level', '2', 0, 0, 'debug'),
('maxCats', '5', 1, 0, 'entry'),
('multimode', '0', 0, 0, 'lang'),
('name_field', '1', 1, 0, 'entry'),
('num_subcats', '6', 1, 0, 'list'),
('parse_desc', '0', 1, 0, 'category'),
('parse_template_content', '0', 1, 0, 'general'),
('percent_format', '%number%sign', 0, 0, 'payments'),
('primary_field', '1', 1, 0, 'alphamenu'),
('publish_limit', '', 1, 0, 'entry'),
('section_access_enabled', '0', 1, 0, 'redirects'),
('section_access_msg', 'UNAUTHORIZED_ACCESS', 1, 0, 'redirects'),
('section_access_msgtype', 'info', 1, 0, 'redirects'),
('section_access_url', 'index.php', 1, 0, 'redirects'),
('section_search_enabled', '0', 1, 0, 'redirects'),
('section_search_msg', 'UNAUTHORIZED_ACCESS', 1, 0, 'redirects'),
('section_search_msgtype', 'info', 1, 0, 'redirects'),
('section_search_url', 'index.php', 1, 0, 'redirects'),
('show', '1', 1, 0, 'alphamenu'),
('show_desc', '1', 1, 0, 'category'),
('show_icon', '1', 1, 0, 'category'),
('show_intro', '1', 1, 0, 'category'),
('show_pb', '1', 0, 0, 'general'),
('subcats', '1', 1, 0, 'list'),
('template', 'default2', 1, 0, 'section'),
('top_menu', '1', 1, 0, 'general'),
('vat', '7', 0, 0, 'payments'),
('vat_brutto', '1', 0, 0, 'payments'),
('verify', '1', 1, 0, 'alphamenu'),
('xml_ip', '', 0, 0, 'debug'),
('xml_raw', '0', 0, 0, 'debug');

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_counter`
--

CREATE TABLE `sas_sobipro_counter` (
  `sid` int(11) NOT NULL,
  `counter` int(11) NOT NULL,
  `lastUpdate` datetime NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_crawler`
--

CREATE TABLE `sas_sobipro_crawler` (
  `url` varchar(255) NOT NULL,
  `crid` int(11) NOT NULL AUTO_INCREMENT,
  `state` tinyint(1) NOT NULL,
  PRIMARY KEY (`crid`),
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_errors`
--

CREATE TABLE `sas_sobipro_errors` (
  `eid` int(25) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `errNum` int(5) NOT NULL,
  `errCode` int(5) NOT NULL,
  `errMsg` text NOT NULL,
  `errFile` varchar(255) NOT NULL,
  `errLine` int(10) NOT NULL,
  `errSect` varchar(50) NOT NULL,
  `errUid` int(11) NOT NULL,
  `errIp` varchar(15) NOT NULL,
  `errRef` varchar(255) NOT NULL,
  `errUa` varchar(255) NOT NULL,
  `errReq` varchar(255) NOT NULL,
  `errCont` text NOT NULL,
  `errBacktrace` text NOT NULL,
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_field`
--

CREATE TABLE `sas_sobipro_field` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `nid` varchar(150) NOT NULL,
  `adminField` tinyint(1) DEFAULT NULL,
  `admList` int(10) NOT NULL,
  `dataType` int(11) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `fee` double DEFAULT NULL,
  `fieldType` varchar(50) DEFAULT NULL,
  `filter` varchar(150) DEFAULT NULL,
  `isFree` tinyint(1) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `priority` int(11) NOT NULL,
  `required` tinyint(1) DEFAULT NULL,
  `section` int(11) DEFAULT NULL,
  `multiLang` tinyint(4) DEFAULT NULL,
  `uniqueData` tinyint(1) DEFAULT NULL,
  `validate` tinyint(1) DEFAULT NULL,
  `addToMetaDesc` tinyint(1) DEFAULT NULL,
  `addToMetaKeys` tinyint(1) DEFAULT '0',
  `editLimit` int(11) NOT NULL DEFAULT '0',
  `editable` tinyint(4) NOT NULL,
  `showIn` enum('both','details','vcard','hidden') NOT NULL DEFAULT 'both',
  `allowedAttributes` text NOT NULL,
  `allowedTags` text NOT NULL,
  `editor` varchar(255) NOT NULL,
  `inSearch` tinyint(4) NOT NULL DEFAULT '1',
  `withLabel` tinyint(4) NOT NULL,
  `cssClass` varchar(50) NOT NULL,
  `parse` tinyint(4) NOT NULL,
  `template` varchar(255) NOT NULL,
  `notice` varchar(150) NOT NULL,
  `params` text NOT NULL,
  `defaultValue` text NOT NULL,
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `enabled` (`enabled`),
  KEY `position` (`position`),
  KEY `section` (`section`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table 'sas_sobipro_field'
--

INSERT INTO `sas_sobipro_field` VALUES
(1, 'field_name', 0, 0, 0, 1, 0, 'inbox', '', 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, -1, 1, 'both', '', '', '', 1, 0, '', 0, '', '', 'YTozOntzOjk6Im1heExlbmd0aCI7czozOiIxNTAiO3M6NToid2lkdGgiO3M6MzoiMzUwIjtzOjEyOiJzZWFyY2hNZXRob2QiO3M6NzoiZ2VuZXJhbCI7fQ==', '', 1),
(2, 'field_zip', 0, 0, 0, 1, 0, 'inbox', 'alphanum', 1, 7, 10, 1, 1, 0, 0, 0, 0, 0, -1, 1, 'details', '', '', '', 1, 1, '', 0, '', '', 'YTo0OntzOjk6Im1heExlbmd0aCI7czozOiIxNTAiO3M6NToid2lkdGgiO3M6MzoiMzUwIjtzOjEyOiJzZWFyY2hNZXRob2QiO3M6NzoiZ2VuZXJhbCI7czoxNzoic2VhcmNoUmFuZ2VWYWx1ZXMiO3M6MDoiIjt9', '', 1),
(3, 'field_city', 0, 0, 0, 1, 0, 'inbox', '', 1, 8, 4, 1, 1, 0, 0, 0, 0, 0, -1, 1, 'details', '', '', '', 1, 1, '', 0, '', '', 'YTo0OntzOjk6Im1heExlbmd0aCI7czozOiIxNTAiO3M6NToid2lkdGgiO3M6MzoiMzUwIjtzOjEyOiJzZWFyY2hNZXRob2QiO3M6Njoic2VsZWN0IjtzOjE3OiJzZWFyY2hSYW5nZVZhbHVlcyI7czowOiIiO30=', '', 1),
(4, 'field_contact', 0, 0, 0, 1, 0, 'inbox', '', 1, 4, 8, 0, 1, 0, 0, 0, 0, 0, -1, 1, 'details', '', '', '', 1, 1, '', 0, '', '', 'YTo0OntzOjk6Im1heExlbmd0aCI7czozOiIxNTAiO3M6NToid2lkdGgiO3M6MzoiMzUwIjtzOjEyOiJzZWFyY2hNZXRob2QiO3M6NzoiZ2VuZXJhbCI7czoxNzoic2VhcmNoUmFuZ2VWYWx1ZXMiO3M6MDoiIjt9', '', 1),
(5, 'field_phone', 0, 0, 0, 1, 0, 'inbox', 'phone', 1, 10, 10, 0, 1, 0, 0, 0, 0, 0, -1, 1, 'details', '', '', '', 0, 1, '', 0, '', '', 'YTo0OntzOjk6Im1heExlbmd0aCI7czozOiIxNTAiO3M6NToid2lkdGgiO3M6MzoiMzUwIjtzOjEyOiJzZWFyY2hNZXRob2QiO3M6NzoiZ2VuZXJhbCI7czoxNzoic2VhcmNoUmFuZ2VWYWx1ZXMiO3M6MDoiIjt9', '', 1),
(6, 'field_fax', 0, 0, 0, 1, 0, 'inbox', 'phone', 1, 11, 10, 0, 1, 0, 0, 0, 0, 0, -1, 1, 'details', '', '', '', 0, 1, '', 0, '', '', 'YTo0OntzOjk6Im1heExlbmd0aCI7czozOiIxNTAiO3M6NToid2lkdGgiO3M6MzoiMzUwIjtzOjEyOiJzZWFyY2hNZXRob2QiO3M6NzoiZ2VuZXJhbCI7czoxNzoic2VhcmNoUmFuZ2VWYWx1ZXMiO3M6MDoiIjt9', '', 1),
(7, 'field_email', 0, 0, 0, 1, 0, 'inbox', 'email', 1, 5, 9, 1, 1, 0, 0, 0, 0, 0, -1, 1, 'hidden', '', '', '', 0, 0, '', 0, '', '', 'YTo0OntzOjk6Im1heExlbmd0aCI7czozOiIxNTAiO3M6NToid2lkdGgiO3M6MzoiMzUwIjtzOjEyOiJzZWFyY2hNZXRob2QiO3M6NzoiZ2VuZXJhbCI7czoxNzoic2VhcmNoUmFuZ2VWYWx1ZXMiO3M6MDoiIjt9', '', 1),
(8, 'field_short_description', 0, 0, 0, 1, 0, 'textarea', '', 1, 14, 6, 1, 1, 0, 0, 0, 1, 0, -1, 1, 'vcard', '', 'YTo0OntpOjA7czo0OiJzcGFuIjtpOjE7czoyOiJiciI7aToyO3M6MzoiZGl2IjtpOjM7czoxOiJwIjt9', '0', 1, 0, '', 0, '', '', 'YTo1OntzOjk6Im1heExlbmd0aCI7czozOiIzMDAiO3M6NToid2lkdGgiO3M6MzoiNTUwIjtzOjY6ImhlaWdodCI7czozOiIxMDAiO3M6NjoiZWRpdG9yIjtzOjE6IjAiO3M6OToiYWxsb3dIdG1sIjtzOjE6IjEiO30=', '', 1),
(9, 'field_full_description', 0, 0, 0, 1, 20, 'textarea', '', 0, 15, 7, 0, 1, 0, 0, 0, 0, 0, -1, 1, 'details', '', '', '1', 1, 0, '', 0, '', '', 'YTo1OntzOjk6Im1heExlbmd0aCI7czoxOiIwIjtzOjU6IndpZHRoIjtzOjM6IjU1MCI7czo2OiJoZWlnaHQiO3M6MzoiMTAwIjtzOjY6ImVkaXRvciI7czoxOiIxIjtzOjk6ImFsbG93SHRtbCI7czoxOiIxIjt9', '', 1),
(10, 'field_company_logo', 0, 0, 0, 1, 5, 'image', '', 0, 3, 10, 0, 1, 0, 0, 0, 0, 0, -1, 1, 'both', '', '', '', 0, 0, '', 0, '', '', 'YToxNjp7czo1OiJ3aWR0aCI7czozOiIzNTAiO3M6ODoic2F2ZVBhdGgiO3M6Mjg6ImltYWdlcy9zb2JpcHJvL2VudHJpZXMve2lkfS8iO3M6OToiaW5EZXRhaWxzIjtzOjU6ImltYWdlIjtzOjc6ImluVmNhcmQiO3M6NToidGh1bWIiO3M6MTE6InRodW1iSGVpZ2h0IjtzOjM6IjEwMCI7czoxMDoidGh1bWJXaWR0aCI7czozOiIxMDAiO3M6OToidGh1bWJOYW1lIjtzOjE1OiJ0aHVtYl97b3JnbmFtZX0iO3M6Nzoia2VlcE9yZyI7czoxOiIxIjtzOjY6InJlc2l6ZSI7czoxOiIxIjtzOjc6Im1heFNpemUiO3M6NzoiMTA0ODU3NiI7czoxMToicmVzaXplV2lkdGgiO3M6MzoiMjAwIjtzOjEyOiJyZXNpemVIZWlnaHQiO3M6MzoiMjAwIjtzOjk6ImltYWdlTmFtZSI7czoxMzoiaW1nX3tvcmduYW1lfSI7czoxMzoiZ2VuZXJhdGVUaHVtYiI7czoxOiIxIjtzOjEwOiJ0aHVtYkZsb2F0IjtzOjU6InJpZ2h0IjtzOjEwOiJpbWFnZUZsb2F0IjtzOjU6InJpZ2h0Ijt9', '', 1),
(11, 'field_website', 0, 0, 0, 1, 10, 'url', 'title', 0, 12, 9, 0, 1, 0, 0, 0, 0, 0, -1, 1, 'details', '', '', '', 0, 1, '', 0, '', '', 'YTo5OntzOjg6Im93bkxhYmVsIjtzOjE6IjEiO3M6MTA6ImxhYmVsV2lkdGgiO3M6MzoiMzUwIjtzOjE0OiJsYWJlbE1heExlbmd0aCI7czozOiIxNTAiO3M6MTE6ImxhYmVsc0xhYmVsIjtzOjEzOiJXZWJzaXRlIFRpdGxlIjtzOjExOiJ2YWxpZGF0ZVVybCI7czoxOiIwIjtzOjE2OiJhbGxvd2VkUHJvdG9jb2xzIjthOjI6e2k6MDtzOjQ6Imh0dHAiO2k6MTtzOjU6Imh0dHBzIjt9czo5OiJuZXdXaW5kb3ciO3M6MToiMSI7czo5OiJtYXhMZW5ndGgiO3M6MzoiMTUwIjtzOjU6IndpZHRoIjtzOjM6IjM1MCI7fQ==', '', 1),
(12, 'field_business_days', 0, 0, 0, 1, 0, 'chbxgroup', '', 1, 13, 9, 1, 1, 0, 0, 0, 0, 0, -1, 1, 'details', '', '', '', 1, 1, '', 0, '', '', 'YTo0OntzOjk6Im9wdEluTGluZSI7czoxOiIyIjtzOjk6ImxhYmVsU2l0ZSI7czo1OiJyaWdodCI7czo4OiJvcHRXaWR0aCI7czozOiIxNTAiO3M6MTI6InNlYXJjaE1ldGhvZCI7czo0OiJjaGJ4Ijt9', '', 1),
(13, 'field_country', 0, 0, 0, 1, 0, 'select', '', 1, 9, 3, 1, 1, 0, 0, 0, 0, 0, -1, 1, 'details', '', '', '', 1, 1, '', 0, '', '', 'YTo2OntzOjU6IndpZHRoIjtzOjM6IjM1MCI7czo0OiJzaXplIjtzOjI6IjEwIjtzOjExOiJzZWxlY3RMYWJlbCI7czo5OiJTZWxlY3QgJXMiO3M6MTI6InNlYXJjaE1ldGhvZCI7czo3OiJtc2VsZWN0IjtzOjY6InN3aWR0aCI7czozOiIzNTAiO3M6NToic3NpemUiO3M6MjoiMTAiO30=', '', 1),
(14, 'field_street', 0, 0, 0, 1, 0, 'inbox', '', 1, 6, 5, 0, 1, 0, 0, 0, 0, 0, -1, 1, 'details', '', '', '', 0, 1, '', 0, '', '', 'YTo0OntzOjk6Im1heExlbmd0aCI7czozOiIxNTAiO3M6NToid2lkdGgiO3M6MzoiMzUwIjtzOjEyOiJzZWFyY2hNZXRob2QiO3M6NzoiZ2VuZXJhbCI7czoxNzoic2VhcmNoUmFuZ2VWYWx1ZXMiO3M6MDoiIjt9', '', 1),
(15, 'field_select_category', 0, 0, 0, 1, 0, 'category', '', 1, 2, 10, 1, 1, 0, 0, 0, 0, 0, -1, 1, 'hidden', '', '', '', 1, 0, '', 0, '', '', 'YToxOTp7czo2OiJtZXRob2QiO3M6NzoibXNlbGVjdCI7czo1OiJtb2RhbCI7czoxOiIwIjtzOjEyOiJjYXRzTWF4TGltaXQiO3M6MjoiMTAiO3M6MTQ6ImNhdHNXaXRoQ2hpbGRzIjtzOjE6IjEiO3M6NToid2lkdGgiO3M6MzoiMjIwIjtzOjY6ImhlaWdodCI7czozOiIyNTAiO3M6ODoiZml4ZWRDaWQiO047czoxMzoiX3NlbGVjdGVkQ2F0cyI7TjtzOjU6Il9jYXRzIjtOO3M6OToiaXNQcmltYXJ5IjtOO3M6MTI6InNlYXJjaE1ldGhvZCI7czo2OiJzZWxlY3QiO3M6MTE6InNlYXJjaFdpZHRoIjtzOjM6IjIyMCI7czoxMjoic2VhcmNoSGVpZ2h0IjtzOjE6IjAiO3M6NToiX2F0dHIiO047czo5OiJfc2VsZWN0ZWQiO047czo1OiJkVHlwZSI7TjtzOjY6Il9yZGF0YSI7TjtzOjg6ImNzc0NsYXNzIjtzOjA6IiI7czo5OiJzaG93TGFiZWwiO047fQ==', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_field_data`
--

CREATE TABLE `sas_sobipro_field_data` (
  `publishUp` datetime DEFAULT NULL,
  `publishDown` datetime DEFAULT NULL,
  `fid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `section` int(11) NOT NULL DEFAULT '0',
  `lang` varchar(50) NOT NULL DEFAULT '',
  `enabled` tinyint(1) NOT NULL,
  `params` text,
  `options` text,
  `baseData` text,
  `approved` tinyint(1) DEFAULT NULL,
  `confirmed` tinyint(1) DEFAULT NULL,
  `createdTime` datetime DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `createdIP` varchar(15) DEFAULT NULL,
  `updatedTime` datetime DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedIP` varchar(15) DEFAULT NULL,
  `copy` tinyint(1) NOT NULL DEFAULT '0',
  `editLimit` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`,`section`,`lang`,`sid`,`copy`),
  KEY `enabled` (`enabled`),
  KEY `copy` (`copy`),
  FULLTEXT KEY `baseData` (`baseData`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_sobipro_field_data'
--

INSERT INTO `sas_sobipro_field_data` VALUES
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 37, 1, 'en-GB', 1, '', '', 'Neo Electronics', 1, 0, '2013-01-02 00:00:00', 0, '88.68.227.138', '2013-01-02 16:25:51', 791, '192.168.1.32', 0, 2),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, 37, 1, 'en-GB', 1, '', '', 'John Doe', 1, 0, '2013-01-02 00:00:00', 0, '88.68.227.138', '2013-01-02 16:25:51', 791, '192.168.1.32', 0, 2),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 7, 37, 1, 'en-GB', 1, '', '', 'example@example.com', 1, 0, '2013-01-02 00:00:00', 0, '88.68.227.138', '2013-01-02 16:25:51', 791, '192.168.1.32', 0, 2),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, 37, 1, 'en-GB', 1, '', '', '1234', 1, 0, '2013-01-02 00:00:00', 0, '88.68.227.138', '2013-01-02 16:25:51', 791, '192.168.1.32', 0, 2),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 3, 37, 1, 'en-GB', 1, '', '', 'Duckburg', 1, 0, '2013-01-02 00:00:00', 0, '88.68.227.138', '2013-01-02 16:25:51', 791, '192.168.1.32', 0, 2),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 37, 1, 'en-GB', 1, '', '', '+1 (0) 1234.567.890', 1, 0, '2013-01-02 00:00:00', 0, '88.68.227.138', '2013-01-02 16:25:51', 791, '192.168.1.32', 0, 2),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 6, 37, 1, 'en-GB', 1, '', '', '+1 (0) 1234.567.891', 1, 0, '2013-01-02 00:00:00', 0, '88.68.227.138', '2013-01-02 16:25:51', 791, '192.168.1.32', 0, 2),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 8, 37, 1, 'en-GB', 1, '', '', 'Morbi ornare porta eleifend. Praesent auctor urna eget nulla bibendum vestibulum. Phasellus eros est, adipiscing eu cursus fermentum, lacinia interdum felis. Vestibulum sit amet velit dui, a placerat dolor. Phasellus gravida, urna eu scelerisque venenatis, velit quam facilisis eros.', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 16:25:51', 791, '192.168.1.32', 0, 2),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 9, 37, 1, 'en-GB', 1, '', '', '<p>Morbi ornare porta eleifend. Praesent auctor urna eget nulla bibendum vestibulum. Phasellus eros est, adipiscing eu cursus fermentum, lacinia interdum felis. Vestibulum sit amet velit dui, a placerat dolor. Phasellus gravida, urna eu scelerisque venenatis, velit quam facilisis eros, sit amet pretium metus leo quis orci. Sed eget ultrices neque. Proin at elit nibh, in aliquam elit. Morbi euismod libero in sapien rutrum in blandit enim pharetra. Integer tincidunt sagittis pellentesque. Cras sed mauris vitae est convallis rhoncus sed sed ligula. Fusce cursus, tortor non pellentesque consequat, purus odio ultrices massa, a gravida libero nisl eget tellus. Donec mollis tincidunt ligula, at rhoncus libero suscipit ut. Integer sodales semper congue. Ut sagittis bibendum augue, et feugiat mauris gravida ac. Maecenas pellentesque orci vitae quam sagittis non gravida lorem egestas. Aenean at enim id orci facilisis fermentum. Pellentesque convallis tortor eget lorem blandit ornare. In purus nisi, tincidunt at ultricies ac, luctus auctor augue. Sed orci neque, commodo in lobortis sit amet, condimentum ac odio.</p>', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 16:25:51', 791, '192.168.1.32', 0, 2),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 10, 37, 1, 'en-GB', 1, NULL, NULL, 'YTo0OntzOjU6ImltYWdlIjtzOjQ0OiJpbWFnZXMvc29iaXByby9lbnRyaWVzLzM3L2ltZ19hdWRpby1jYXJkLnBuZyI7czo1OiJ0aHVtYiI7czo0NjoiaW1hZ2VzL3NvYmlwcm8vZW50cmllcy8zNy90aHVtYl9hdWRpby1jYXJkLnBuZyI7czozOiJpY28iO3M6NDQ6ImltYWdlcy9zb2JpcHJvL2VudHJpZXMvMzcvaWNvX2F1ZGlvLWNhcmQucG5nIjtzOjg6Im9yaWdpbmFsIjtzOjk0OiJpbWFnZXMvc29iaXByby9lbnRyaWVzLzM3Ly92YXIvd3d3L3NvYmktcHJvL2h0bWwvcm9vdC9pbWFnZXMvc29iaXByby9lbnRyaWVzLzM3L2F1ZGlvLWNhcmQucG5nIjt9', 0, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 0, '0', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 11, 37, 1, 'en-GB', 1, NULL, NULL, 'YTozOntzOjU6ImxhYmVsIjtzOjIwOiJOZW8gRWxlY3Ryb25pY3MgU2hvcCI7czo4OiJwcm90b2NvbCI7czo0OiJodHRwIjtzOjM6InVybCI7czoxMjoiZXhhbXBsZS5jb20vIjt9', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 16:25:51', 791, '192.168.1.32', 0, 2),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 12, 37, 1, 'en-GB', 1, NULL, NULL, '', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 16:25:51', 791, '192.168.1.32', 0, 2),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 38, 1, 'en-GB', 1, NULL, NULL, 'N-Communications', 1, 0, '2013-01-02 00:00:00', 0, '88.68.227.138', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 10, 38, 1, 'en-GB', 1, NULL, NULL, 'YTo0OntzOjU6ImltYWdlIjtzOjQ3OiJpbWFnZXMvc29iaXByby9lbnRyaWVzLzM4L2ltZ19Gb2xkZXJOZXR3b3JrLnBuZyI7czo1OiJ0aHVtYiI7czo0OToiaW1hZ2VzL3NvYmlwcm8vZW50cmllcy8zOC90aHVtYl9Gb2xkZXJOZXR3b3JrLnBuZyI7czozOiJpY28iO3M6NDc6ImltYWdlcy9zb2JpcHJvL2VudHJpZXMvMzgvaWNvX2ZvbGRlcm5ldHdvcmsucG5nIjtzOjg6Im9yaWdpbmFsIjtzOjk3OiJpbWFnZXMvc29iaXByby9lbnRyaWVzLzM4Ly92YXIvd3d3L3NvYmktcHJvL2h0bWwvcm9vdC9pbWFnZXMvc29iaXByby9lbnRyaWVzLzM4L0ZvbGRlck5ldHdvcmsucG5nIjt9', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.68.227.138', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, 38, 1, 'en-GB', 1, NULL, NULL, 'Scrooge McDuck', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 7, 38, 1, 'en-GB', 1, NULL, NULL, 'Scrooge@mcduck.com', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, 38, 1, 'en-GB', 1, NULL, NULL, '7788', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 3, 38, 1, 'en-GB', 1, NULL, NULL, 'Duckburg', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 38, 1, 'en-GB', 1, NULL, NULL, '+1 (0) 9934.567.899', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 6, 38, 1, 'en-GB', 1, NULL, NULL, '+1 (0) 9934.567.001', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 11, 38, 1, 'en-GB', 1, NULL, NULL, 'YTozOntzOjU6ImxhYmVsIjtzOjMxOiJXaWtpcGVkaWEgdGhlIGZyZWUgZW5jeWNsb3BlZGlhIjtzOjg6InByb3RvY29sIjtzOjQ6Imh0dHAiO3M6MzoidXJsIjtzOjE3OiJlbi53aWtpcGVkaWEub3JnLyI7fQ==', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 12, 38, 1, 'en-GB', 1, NULL, NULL, '', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 8, 38, 1, 'en-GB', 1, NULL, NULL, 'Fusce vel felis et dolor sagittis volutpat. Nunc sit amet lacus sapien, ac imperdiet mi. Duis sed massa metus, venenatis dignissim odio. Proin dui urna, facilisis vitae venenatis non, vehicula id neque. Sed rutrum est eu diam suscipit elementum eget nec mi.', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 9, 38, 1, 'en-GB', 1, NULL, NULL, '<p>Morbi ornare porta eleifend. Praesent auctor urna eget nulla bibendum  vestibulum. Phasellus eros est, adipiscing eu cursus fermentum, lacinia  interdum felis. Vestibulum sit amet velit dui, a placerat dolor.  Phasellus gravida, urna eu scelerisque venenatis, velit quam facilisis  eros, sit amet pretium metus leo quis orci. Sed eget ultrices neque.  Proin at elit nibh, in aliquam elit. Morbi euismod libero in sapien  rutrum in blandit enim pharetra. Integer tincidunt sagittis  pellentesque. Cras sed mauris vitae est convallis rhoncus sed sed  ligula. Fusce cursus, tortor non pellentesque consequat, purus odio  ultrices massa, a gravida libero nisl eget tellus. Donec mollis  tincidunt ligula, at rhoncus libero suscipit ut. Integer sodales semper  congue. Ut sagittis bibendum augue, et feugiat mauris gravida ac.  Maecenas pellentesque orci vitae quam sagittis non gravida lorem  egestas. Aenean at enim id orci facilisis fermentum. Pellentesque  convallis tortor eget lorem blandit ornare. In purus nisi, tincidunt at  ultricies ac, luctus auctor augue. Sed orci neque, commodo in lobortis  sit amet, condimentum ac odio.</p>\r\n<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere  cubilia Curae; Etiam elit massa, malesuada dictum pellentesque id,  vestibulum non risus. Maecenas adipiscing, nunc at ullamcorper  porttitor, libero turpis laoreet nisl, eu dapibus ipsum justo sed leo.  Mauris vel purus augue, ac ultricies nisi. In hac habitasse platea  dictumst. Nulla magna risus, venenatis sed ultricies vel, condimentum  nec turpis. Curabitur cursus luctus enim eu pharetra. Mauris elit nisi,  eleifend vitae condimentum vitae, ultricies ut justo. Aliquam mollis  lectus eu nulla tempor eget ultricies elit tincidunt. Aliquam erat  volutpat. Quisque eros lacus, iaculis a placerat et, fermentum et massa.  Ut tempor faucibus cursus. Nunc imperdiet vestibulum faucibus. Mauris  commodo, augue a cursus aliquet, mauris diam aliquam nisl, nec pharetra  massa nulla eget nibh. Integer egestas volutpat diam, quis malesuada dui  sollicitudin at. Mauris vehicula, metus quis posuere egestas, metus  lectus pulvinar sapien, non accumsan nulla sapien eget nulla. Quisque  imperdiet ultricies ipsum non fringilla. Curabitur pulvinar mi nec lacus  consectetur vel ullamcorper enim pretium. Pellentesque vitae  scelerisque sem. Morbi nunc ipsum, dignissim eu pellentesque quis,  sollicitudin vitae turpis.</p>', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 39, 1, 'en-GB', 1, NULL, NULL, 'Sun Bookstore', 1, 0, '2013-01-02 00:00:00', 0, '88.68.227.138', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 10, 39, 1, 'en-GB', 1, NULL, NULL, 'YTo0OntzOjU6ImltYWdlIjtzOjQxOiJpbWFnZXMvc29iaXByby9lbnRyaWVzLzM5L2ltZ19OZXR3b3JrLnBuZyI7czo1OiJ0aHVtYiI7czo0MzoiaW1hZ2VzL3NvYmlwcm8vZW50cmllcy8zOS90aHVtYl9OZXR3b3JrLnBuZyI7czozOiJpY28iO3M6NDE6ImltYWdlcy9zb2JpcHJvL2VudHJpZXMvMzkvaWNvX25ldHdvcmsucG5nIjtzOjg6Im9yaWdpbmFsIjtzOjkxOiJpbWFnZXMvc29iaXByby9lbnRyaWVzLzM5Ly92YXIvd3d3L3NvYmktcHJvL2h0bWwvcm9vdC9pbWFnZXMvc29iaXByby9lbnRyaWVzLzM5L05ldHdvcmsucG5nIjt9', 0, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 0, '0', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, 39, 1, 'en-GB', 1, NULL, NULL, 'Carl  Sun', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 7, 39, 1, 'en-GB', 1, NULL, NULL, 'example@example.com', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, 39, 1, 'en-GB', 1, NULL, NULL, '7118', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 3, 39, 1, 'en-GB', 1, NULL, NULL, 'Duckburg', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 39, 1, 'en-GB', 1, NULL, NULL, '+1 (0) 567.899.11', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 6, 39, 1, 'en-GB', 1, NULL, NULL, '+1 (0) 567.899.99', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 11, 39, 1, 'en-GB', 1, NULL, NULL, 'YTozOntzOjU6ImxhYmVsIjtzOjEzOiJTdW4gQm9va3N0b3JlIjtzOjg6InByb3RvY29sIjtzOjQ6Imh0dHAiO3M6MzoidXJsIjtzOjExOiJleGFtcGxlLm9yZyI7fQ==', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 12, 39, 1, 'en-GB', 1, NULL, NULL, '', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 8, 39, 1, 'en-GB', 1, NULL, NULL, 'Vivamus est leo, tempor at dictum in, pellentesque molestie velit. Sed lacinia, quam non malesuada porttitor, ante arcu ornare magna, vel lacinia nibh velit quis massa. Donec nec massa sit amet metus elementum porta. Duis a velit vitae leo accumsan sodales. Vestibulum convallis consectetur elit', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 9, 39, 1, 'en-GB', 1, NULL, NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque  laoreet rhoncus tempor. Suspendisse dapibus vulputate dolor ut  tincidunt. Suspendisse tristique laoreet dui, ut tempor orci dictum ut.  Quisque aliquam urna ac justo tristique interdum. Aliquam in dui eget  lectus elementum lacinia eget eu sem. Nam eu felis tellus, ac cursus  velit. Etiam magna libero, condimentum at facilisis a, fermentum eget  leo. Nulla gravida imperdiet neque, accumsan auctor magna viverra a.  Aliquam eget augue a ante malesuada convallis a nec mi. Phasellus  mollis, urna et interdum congue, lacus ante lacinia ipsum, vitae  fringilla quam mi id ipsum.</p>', 1, 0, '2013-01-02 00:00:00', 0, '0', '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 13, 37, 1, 'en-GB', 1, NULL, NULL, '', 1, 0, NULL, NULL, NULL, '2013-01-02 16:25:51', 791, '192.168.1.32', 0, 2),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 13, 38, 1, 'en-GB', 1, NULL, NULL, '', 1, 0, NULL, NULL, NULL, '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 13, 39, 1, 'en-GB', 1, NULL, NULL, '', 1, 0, NULL, NULL, NULL, '2013-01-02 00:00:00', 63, '88.69.191.86', 0, NULL),
('0000-00-00 00:00:00', '0000-00-00 00:00:00', 14, 37, 1, 'en-GB', 1, '', '', '', 1, 0, NULL, NULL, NULL, '2013-01-02 16:25:51', 791, '192.168.1.32', 0, -1);

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_field_option`
--

CREATE TABLE `sas_sobipro_field_option` (
  `fid` int(11) NOT NULL,
  `optValue` varchar(100) NOT NULL,
  `optPos` int(11) NOT NULL,
  `img` varchar(150) NOT NULL,
  `optClass` varchar(50) NOT NULL,
  `actions` text NOT NULL,
  `class` text NOT NULL,
  `optParent` varchar(100) NOT NULL,
  PRIMARY KEY (`fid`,`optValue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_sobipro_field_option'
--

INSERT INTO `sas_sobipro_field_option` VALUES
(12, 'Friday', 5, '', '', '', '', ''),
(12, 'Monday', 1, '', '', '', '', ''),
(12, 'Saturday', 6, '', '', '', '', ''),
(12, 'Sunday', 7, '', '', '', '', ''),
(12, 'Thursday', 4, '', '', '', '', ''),
(12, 'Tuesday', 2, '', '', '', '', ''),
(12, 'Wednesday', 3, '', '', '', '', ''),
(13, 'abkhazia', 58, '', '', '', '', 'asia'),
(13, 'afghanistan', 59, '', '', '', '', 'asia'),
(13, 'africa', 1, '', '', '', '', ''),
(13, 'akrotiri-and-dhekelia', 60, '', '', '', '', 'asia'),
(13, 'aland-islands', 118, '', '', '', '', 'europe'),
(13, 'albania', 119, '', '', '', '', 'europe'),
(13, 'algeria', 2, '', '', '', '', 'africa'),
(13, 'american-samoa', 229, '', '', '', '', 'oceania'),
(13, 'andorra', 120, '', '', '', '', 'europe'),
(13, 'angola', 3, '', '', '', '', 'africa'),
(13, 'anguilla', 172, '', '', '', '', 'north-america'),
(13, 'antarctica', 264, '', '', '', '', ''),
(13, 'antigua-and-barbuda', 173, '', '', '', '', 'north-america'),
(13, 'argentina', 214, '', '', '', '', 'south-america'),
(13, 'armenia', 61, '', '', '', '', 'asia'),
(13, 'aruba', 174, '', '', '', '', 'north-america'),
(13, 'ashmore-and-cartier', 230, '', '', '', '', 'oceania'),
(13, 'asia', 57, '', '', '', '', ''),
(13, 'australia', 231, '', '', '', '', 'oceania'),
(13, 'austria', 121, '', '', '', '', 'europe'),
(13, 'azerbaijan', 62, '', '', '', '', 'asia'),
(13, 'bahamas', 175, '', '', '', '', 'north-america'),
(13, 'bahrain', 63, '', '', '', '', 'asia'),
(13, 'baker-island', 232, '', '', '', '', 'oceania'),
(13, 'bangladesh', 64, '', '', '', '', 'asia'),
(13, 'barbados', 176, '', '', '', '', 'north-america'),
(13, 'belarus', 122, '', '', '', '', 'europe'),
(13, 'belgium', 123, '', '', '', '', 'europe'),
(13, 'belize', 177, '', '', '', '', 'north-america'),
(13, 'benin', 4, '', '', '', '', 'africa'),
(13, 'bermuda', 178, '', '', '', '', 'north-america'),
(13, 'bhutan', 65, '', '', '', '', 'asia'),
(13, 'bolivia', 215, '', '', '', '', 'south-america'),
(13, 'bosnia-herzegovina', 124, '', '', '', '', 'europe'),
(13, 'botswana', 5, '', '', '', '', 'africa'),
(13, 'bouvet-island', 265, '', '', '', '', 'antarctica'),
(13, 'brazil', 216, '', '', '', '', 'south-america'),
(13, 'british-indian', 66, '', '', '', '', 'asia'),
(13, 'british-virgin-islands', 179, '', '', '', '', 'north-america'),
(13, 'brunei', 67, '', '', '', '', 'asia'),
(13, 'bulgaria', 125, '', '', '', '', 'europe'),
(13, 'burkina-faso', 6, '', '', '', '', 'africa'),
(13, 'burundi', 7, '', '', '', '', 'africa'),
(13, 'cambodia', 68, '', '', '', '', 'asia'),
(13, 'cameroon', 8, '', '', '', '', 'africa'),
(13, 'canada', 180, '', '', '', '', 'north-america'),
(13, 'cape-verde', 9, '', '', '', '', 'africa'),
(13, 'cayman-islands', 181, '', '', '', '', 'north-america'),
(13, 'central-african-republic', 10, '', '', '', '', 'africa'),
(13, 'chad', 11, '', '', '', '', 'africa'),
(13, 'chile', 217, '', '', '', '', 'south-america'),
(13, 'china', 69, '', '', '', '', 'asia'),
(13, 'christmas-island', 71, '', '', '', '', 'asia'),
(13, 'clipperton-island', 182, '', '', '', '', 'north-america'),
(13, 'cocos-islands', 72, '', '', '', '', 'asia'),
(13, 'colombia', 218, '', '', '', '', 'south-america'),
(13, 'comoros', 12, '', '', '', '', 'africa'),
(13, 'congo-democratic', 13, '', '', '', '', 'africa'),
(13, 'congo-republic-of', 14, '', '', '', '', 'africa'),
(13, 'cook-islands', 233, '', '', '', '', 'oceania'),
(13, 'coral-sea-islands', 234, '', '', '', '', 'oceania'),
(13, 'costa-rica', 183, '', '', '', '', 'north-america'),
(13, 'cote-d-ivoire', 15, '', '', '', '', 'africa'),
(13, 'croatia', 126, '', '', '', '', 'europe'),
(13, 'cuba', 184, '', '', '', '', 'north-america'),
(13, 'cyprus', 73, '', '', '', '', 'asia'),
(13, 'czech-republic', 127, '', '', '', '', 'europe'),
(13, 'denmark', 128, '', '', '', '', 'europe'),
(13, 'djibouti', 16, '', '', '', '', 'africa'),
(13, 'dominica', 185, '', '', '', '', 'north-america'),
(13, 'dominican-republic', 186, '', '', '', '', 'north-america'),
(13, 'ecuador', 219, '', '', '', '', 'south-america'),
(13, 'egypt', 17, '', '', '', '', 'africa'),
(13, 'el-salvador', 187, '', '', '', '', 'north-america'),
(13, 'equatorial-guinea', 18, '', '', '', '', 'africa'),
(13, 'eritrea', 19, '', '', '', '', 'africa'),
(13, 'estonia', 129, '', '', '', '', 'europe'),
(13, 'ethiopia', 20, '', '', '', '', 'africa'),
(13, 'europe', 117, '', '', '', '', ''),
(13, 'falkland-islands', 220, '', '', '', '', 'south-america'),
(13, 'faroe-islands', 130, '', '', '', '', 'europe'),
(13, 'fiji', 235, '', '', '', '', 'oceania'),
(13, 'finland', 131, '', '', '', '', 'europe'),
(13, 'france', 132, '', '', '', '', 'europe'),
(13, 'french-guiana', 221, '', '', '', '', 'south-america'),
(13, 'french-polynesia', 236, '', '', '', '', 'oceania'),
(13, 'french-southern-territories', 266, '', '', '', '', 'antarctica'),
(13, 'gabon', 21, '', '', '', '', 'africa'),
(13, 'gambia', 22, '', '', '', '', 'africa'),
(13, 'georgia', 74, '', '', '', '', 'asia'),
(13, 'germany', 133, '', '', '', '', 'europe'),
(13, 'ghana', 23, '', '', '', '', 'africa'),
(13, 'gibraltar', 134, '', '', '', '', 'europe'),
(13, 'greece', 135, '', '', '', '', 'europe'),
(13, 'greenland', 188, '', '', '', '', 'north-america'),
(13, 'grenada', 189, '', '', '', '', 'north-america'),
(13, 'guadeloupe', 190, '', '', '', '', 'north-america'),
(13, 'guam', 237, '', '', '', '', 'oceania'),
(13, 'guatemala', 191, '', '', '', '', 'north-america'),
(13, 'guernsey', 136, '', '', '', '', 'europe'),
(13, 'guinea', 24, '', '', '', '', 'africa'),
(13, 'guinea-bissau', 25, '', '', '', '', 'africa'),
(13, 'guyana', 222, '', '', '', '', 'south-america'),
(13, 'haiti', 192, '', '', '', '', 'north-america'),
(13, 'heard-island-mcdonald-islands', 267, '', '', '', '', 'antarctica'),
(13, 'honduras', 193, '', '', '', '', 'north-america'),
(13, 'hong-kong', 75, '', '', '', '', 'asia'),
(13, 'howland-island', 238, '', '', '', '', 'oceania'),
(13, 'hungary', 137, '', '', '', '', 'europe'),
(13, 'iceland', 138, '', '', '', '', 'europe'),
(13, 'india', 76, '', '', '', '', 'asia'),
(13, 'indonesia', 77, '', '', '', '', 'asia'),
(13, 'iran', 78, '', '', '', '', 'asia'),
(13, 'iraq', 79, '', '', '', '', 'asia'),
(13, 'ireland', 139, '', '', '', '', 'europe'),
(13, 'isle-of-man', 140, '', '', '', '', 'europe'),
(13, 'israel', 80, '', '', '', '', 'asia'),
(13, 'italy', 141, '', '', '', '', 'europe'),
(13, 'jamaica', 194, '', '', '', '', 'north-america'),
(13, 'japan', 81, '', '', '', '', 'asia'),
(13, 'jarvis-island', 239, '', '', '', '', 'oceania'),
(13, 'jersey', 142, '', '', '', '', 'europe'),
(13, 'johnston-atoll', 240, '', '', '', '', 'oceania'),
(13, 'jordan', 82, '', '', '', '', 'asia'),
(13, 'kazakhstan', 83, '', '', '', '', 'asia'),
(13, 'kenya', 26, '', '', '', '', 'africa'),
(13, 'kingman-reef', 241, '', '', '', '', 'oceania'),
(13, 'kiribati', 242, '', '', '', '', 'oceania'),
(13, 'korea-republic', 85, '', '', '', '', 'asia'),
(13, 'kosovo', 143, '', '', '', '', 'europe'),
(13, 'kuwait', 86, '', '', '', '', 'asia'),
(13, 'kyrgyzstan', 87, '', '', '', '', 'asia'),
(13, 'laos', 88, '', '', '', '', 'asia'),
(13, 'latvia', 144, '', '', '', '', 'europe'),
(13, 'lebanon', 89, '', '', '', '', 'asia'),
(13, 'lesotho', 27, '', '', '', '', 'africa'),
(13, 'liberia', 28, '', '', '', '', 'africa'),
(13, 'libya', 29, '', '', '', '', 'africa'),
(13, 'liechtenstein', 145, '', '', '', '', 'europe'),
(13, 'lithuania', 146, '', '', '', '', 'europe'),
(13, 'luxembourg', 147, '', '', '', '', 'europe'),
(13, 'macau', 90, '', '', '', '', 'asia'),
(13, 'macedonia', 148, '', '', '', '', 'europe'),
(13, 'madagascar', 30, '', '', '', '', 'africa'),
(13, 'malawi', 31, '', '', '', '', 'africa'),
(13, 'malaysia', 91, '', '', '', '', 'asia'),
(13, 'maldives', 92, '', '', '', '', 'asia'),
(13, 'mali', 32, '', '', '', '', 'africa'),
(13, 'malta', 149, '', '', '', '', 'europe'),
(13, 'marshall-islands', 243, '', '', '', '', 'oceania'),
(13, 'martinique', 195, '', '', '', '', 'north-america'),
(13, 'mauritania', 33, '', '', '', '', 'africa'),
(13, 'mauritius', 34, '', '', '', '', 'africa'),
(13, 'mayotte', 35, '', '', '', '', 'africa'),
(13, 'mexico', 196, '', '', '', '', 'north-america'),
(13, 'micronesia', 244, '', '', '', '', 'oceania'),
(13, 'midway-atoll', 245, '', '', '', '', 'oceania'),
(13, 'moldova', 150, '', '', '', '', 'europe'),
(13, 'monaco', 151, '', '', '', '', 'europe'),
(13, 'mongolia', 93, '', '', '', '', 'asia'),
(13, 'montenegro', 152, '', '', '', '', 'europe'),
(13, 'montserrat', 197, '', '', '', '', 'north-america'),
(13, 'morocco', 36, '', '', '', '', 'africa'),
(13, 'mozambique', 37, '', '', '', '', 'africa'),
(13, 'myanmar', 94, '', '', '', '', 'asia'),
(13, 'nagorno-karabakh', 95, '', '', '', '', 'asia'),
(13, 'namibia', 38, '', '', '', '', 'africa'),
(13, 'nauru', 246, '', '', '', '', 'oceania'),
(13, 'navassa-island', 198, '', '', '', '', 'north-america'),
(13, 'nepal', 97, '', '', '', '', 'asia'),
(13, 'netherlands', 153, '', '', '', '', 'europe'),
(13, 'netherlands-antilles', 199, '', '', '', '', 'north-america'),
(13, 'new-caledonia', 247, '', '', '', '', 'oceania'),
(13, 'new-zealand', 248, '', '', '', '', 'oceania'),
(13, 'nicaragua', 200, '', '', '', '', 'north-america'),
(13, 'niger', 39, '', '', '', '', 'africa'),
(13, 'nigeria', 40, '', '', '', '', 'africa'),
(13, 'niue', 249, '', '', '', '', 'oceania'),
(13, 'norfolk-island', 250, '', '', '', '', 'oceania'),
(13, 'north-america', 171, '', '', '', '', ''),
(13, 'north-korea', 84, '', '', '', '', 'asia'),
(13, 'northern-cyprus', 96, '', '', '', '', 'asia'),
(13, 'northern-mariana-islands', 251, '', '', '', '', 'oceania'),
(13, 'norway', 154, '', '', '', '', 'europe'),
(13, 'oceania', 228, '', '', '', '', ''),
(13, 'oman', 98, '', '', '', '', 'asia'),
(13, 'pakistan', 99, '', '', '', '', 'asia'),
(13, 'palau', 252, '', '', '', '', 'oceania'),
(13, 'palestinian-territories', 100, '', '', '', '', 'asia'),
(13, 'palmyra-atoll', 253, '', '', '', '', 'oceania'),
(13, 'panama', 201, '', '', '', '', 'north-america'),
(13, 'papua-new-guinea', 254, '', '', '', '', 'oceania'),
(13, 'paraguay', 223, '', '', '', '', 'south-america'),
(13, 'peru', 224, '', '', '', '', 'south-america'),
(13, 'philippines', 101, '', '', '', '', 'asia'),
(13, 'pitcairn-islands', 255, '', '', '', '', 'oceania'),
(13, 'poland', 155, '', '', '', '', 'europe'),
(13, 'portugal', 156, '', '', '', '', 'europe'),
(13, 'puerto-rico', 202, '', '', '', '', 'north-america'),
(13, 'qatar', 102, '', '', '', '', 'asia'),
(13, 'reunion', 41, '', '', '', '', 'africa'),
(13, 'romania', 157, '', '', '', '', 'europe'),
(13, 'russia', 158, '', '', '', '', 'europe'),
(13, 'rwanda', 42, '', '', '', '', 'africa'),
(13, 'saint-barthelemy', 203, '', '', '', '', 'north-america'),
(13, 'saint-kitts-and-nevis', 204, '', '', '', '', 'north-america'),
(13, 'saint-lucia', 205, '', '', '', '', 'north-america'),
(13, 'saint-martin', 206, '', '', '', '', 'north-america'),
(13, 'saint-pierre-and-miquelon', 207, '', '', '', '', 'north-america'),
(13, 'saint-vincent-grenadines', 208, '', '', '', '', 'north-america'),
(13, 'samoa', 256, '', '', '', '', 'oceania'),
(13, 'san-marino', 159, '', '', '', '', 'europe'),
(13, 'sao-tome-and-principe', 43, '', '', '', '', 'africa'),
(13, 'saudi-arabia', 103, '', '', '', '', 'asia'),
(13, 'senegal', 44, '', '', '', '', 'africa'),
(13, 'serbia', 160, '', '', '', '', 'europe'),
(13, 'seychelles', 45, '', '', '', '', 'africa'),
(13, 'sierra-leone', 46, '', '', '', '', 'africa'),
(13, 'singapore', 104, '', '', '', '', 'asia'),
(13, 'slovakia', 161, '', '', '', '', 'europe'),
(13, 'slovenia', 162, '', '', '', '', 'europe'),
(13, 'solomon-islands', 257, '', '', '', '', 'oceania'),
(13, 'somalia', 47, '', '', '', '', 'africa'),
(13, 'somaliland', 48, '', '', '', '', 'africa'),
(13, 'south-africa', 49, '', '', '', '', 'africa'),
(13, 'south-america', 213, '', '', '', '', ''),
(13, 'south-georgia-south-sandwich-islands', 268, '', '', '', '', 'antarctica'),
(13, 'south-ossetia', 105, '', '', '', '', 'asia'),
(13, 'spain', 163, '', '', '', '', 'europe'),
(13, 'sri-lanka', 106, '', '', '', '', 'asia'),
(13, 'sudan', 50, '', '', '', '', 'africa'),
(13, 'suriname', 225, '', '', '', '', 'south-america'),
(13, 'svalbard', 164, '', '', '', '', 'europe'),
(13, 'swaziland', 51, '', '', '', '', 'africa'),
(13, 'sweden', 165, '', '', '', '', 'europe'),
(13, 'switzerland', 166, '', '', '', '', 'europe'),
(13, 'syria', 107, '', '', '', '', 'asia'),
(13, 'taiwan', 70, '', '', '', '', 'asia'),
(13, 'tajikistan', 108, '', '', '', '', 'asia'),
(13, 'thailand', 109, '', '', '', '', 'asia'),
(13, 'timor-leste', 110, '', '', '', '', 'asia'),
(13, 'tokelau', 258, '', '', '', '', 'oceania'),
(13, 'tonga', 259, '', '', '', '', 'oceania'),
(13, 'transnistria', 167, '', '', '', '', 'europe'),
(13, 'trinidad-and-tobago', 209, '', '', '', '', 'north-america'),
(13, 'tunisia', 52, '', '', '', '', 'africa'),
(13, 'turkey', 111, '', '', '', '', 'asia'),
(13, 'turkmenistan', 112, '', '', '', '', 'asia'),
(13, 'turks-and-caicos-islands', 210, '', '', '', '', 'north-america'),
(13, 'tuvalu', 260, '', '', '', '', 'oceania'),
(13, 'uganda', 53, '', '', '', '', 'africa'),
(13, 'ukraine', 168, '', '', '', '', 'europe'),
(13, 'united-arab-emirates', 113, '', '', '', '', 'asia'),
(13, 'united-kingdom', 169, '', '', '', '', 'europe'),
(13, 'uruguay', 226, '', '', '', '', 'south-america'),
(13, 'usa', 211, '', '', '', '', 'north-america'),
(13, 'uzbekistan', 114, '', '', '', '', 'asia'),
(13, 'vanuatu', 261, '', '', '', '', 'oceania'),
(13, 'vatican', 170, '', '', '', '', 'europe'),
(13, 'venezuela', 227, '', '', '', '', 'south-america'),
(13, 'vietnam', 115, '', '', '', '', 'asia'),
(13, 'virgin-islands', 212, '', '', '', '', 'north-america'),
(13, 'wake-island', 262, '', '', '', '', 'oceania'),
(13, 'wallis-and-futuna', 263, '', '', '', '', 'oceania'),
(13, 'western-sahara', 54, '', '', '', '', 'africa'),
(13, 'yemen', 116, '', '', '', '', 'asia'),
(13, 'zambia', 55, '', '', '', '', 'africa'),
(13, 'zimbabwe', 56, '', '', '', '', 'africa');

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_field_option_selected`
--

CREATE TABLE `sas_sobipro_field_option_selected` (
  `fid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `optValue` varchar(100) NOT NULL,
  `params` text NOT NULL,
  `copy` tinyint(1) NOT NULL,
  PRIMARY KEY (`fid`,`sid`,`optValue`,`copy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_sobipro_field_option_selected'
--

INSERT INTO `sas_sobipro_field_option_selected` VALUES
(12, 37, 'Friday', '', 0),
(12, 37, 'Monday', '', 0),
(12, 37, 'Thursday', '', 0),
(12, 37, 'Tuesday', '', 0),
(12, 37, 'Wednesday', '', 0),
(12, 38, 'Friday', '', 0),
(12, 38, 'Monday', '', 0),
(12, 38, 'Saturday', '', 0),
(12, 38, 'Thursday', '', 0),
(12, 38, 'Tuesday', '', 0),
(12, 38, 'Wednesday', '', 0),
(12, 39, 'Friday', '', 0),
(12, 39, 'Saturday', '', 0),
(12, 39, 'Thursday', '', 0),
(12, 39, 'Tuesday', '', 0),
(12, 39, 'Wednesday', '', 0),
(13, 37, 'france', '', 0),
(13, 38, 'germany', '', 0),
(13, 39, 'usa', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_field_types`
--

CREATE TABLE `sas_sobipro_field_types` (
  `tid` char(50) NOT NULL,
  `fType` varchar(50) NOT NULL,
  `tGroup` varchar(100) NOT NULL,
  `fPos` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tid`,`tGroup`),
  UNIQUE KEY `pos` (`fPos`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table 'sas_sobipro_field_types'
--

INSERT INTO `sas_sobipro_field_types` VALUES
('category', 'Category', 'special', 11),
('chbxgroup', 'Check Box Group', 'predefined_multi_data_multi_choice', 4),
('email', 'Email', 'special', 12),
('image', 'Image', 'special', 9),
('inbox', 'Input Box', 'free_single_simple_data', 1),
('multiselect', 'Multiple Select List', 'predefined_multi_data_multi_choice', 3),
('radio', 'Radio Buttons', 'predefined_multi_data_single_choice', 8),
('select', 'Single Select List', 'predefined_multi_data_single_choice', 7),
('textarea', 'Text Area', 'free_single_simple_data', 2),
('url', 'URL', 'special', 10);

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_field_url_clicks`
--

CREATE TABLE `sas_sobipro_field_url_clicks` (
  `date` datetime NOT NULL,
  `uid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `fid` varchar(50) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `section` int(11) NOT NULL,
  `browserData` text NOT NULL,
  `osData` text NOT NULL,
  `humanity` int(3) NOT NULL,
  PRIMARY KEY (`date`,`sid`,`fid`,`ip`,`section`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_history`
--

CREATE TABLE `sas_sobipro_history` (
  `revision` varchar(150) NOT NULL,
  `changedAt` datetime NOT NULL,
  `uid` int(11) NOT NULL,
  `userName` varchar(150) NOT NULL,
  `userEmail` varchar(150) NOT NULL,
  `change` varchar(150) NOT NULL,
  `site` enum('site','adm') NOT NULL,
  `sid` int(11) NOT NULL,
  `changes` text NOT NULL,
  `params` text NOT NULL,
  `reason` text NOT NULL,
  `language` varchar(50) NOT NULL,
  PRIMARY KEY (`revision`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_language`
--

CREATE TABLE `sas_sobipro_language` (
  `sKey` varchar(150) NOT NULL DEFAULT '',
  `sValue` text,
  `section` int(11) DEFAULT NULL,
  `language` varchar(50) NOT NULL DEFAULT '',
  `oType` varchar(150) NOT NULL,
  `fid` int(11) NOT NULL,
  `id` int(11) NOT NULL DEFAULT '0',
  `params` text,
  `options` text,
  `explanation` text,
  PRIMARY KEY (`sKey`,`language`,`id`,`fid`),
  KEY `sKey` (`sKey`),
  KEY `section` (`section`),
  KEY `language` (`language`),
  FULLTEXT KEY `sValue` (`sValue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_sobipro_language'
--

INSERT INTO `sas_sobipro_language` VALUES
('description', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque laoreet rhoncus tempor. Suspendisse dapibus vulputate dolor ut tincidunt. Suspendisse tristique laoreet dui, ut tempor orci dictum ut. Quisque aliquam urna ac justo tristique interdum. Aliquam in dui eget lectus elementum lacinia eget eu sem. Nam eu felis tellus, ac cursus velit. Etiam magna libero, condimentum at facilisis a, fermentum eget leo. Nulla gravida imperdiet neque, accumsan auctor magna viverra a. Aliquam eget augue a ante malesuada convallis a nec mi. Phasellus mollis, urna et interdum congue, lacus ante lacinia ipsum, vitae fringilla quam mi id ipsum.</p>', NULL, 'en-GB', 'section', 0, 1, NULL, NULL, NULL),
('name', 'Business Directory', NULL, 'en-GB', 'section', 0, 1, NULL, NULL, NULL),
('name', 'Company Name', NULL, 'en-GB', 'field', 1, 0, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'field', 1, 0, NULL, NULL, NULL),
('description', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque  laoreet rhoncus tempor. Suspendisse dapibus vulputate dolor ut  tincidunt. Suspendisse tristique laoreet dui, ut tempor orci dictum ut.  Quisque aliquam urna ac justo tristique interdum. Aliquam in dui eget  lectus elementum lacinia eget eu sem. Nam eu felis tellus, ac cursus  velit. Etiam magna libero, condimentum at facilisis a, fermentum eget  leo. Nulla gravida imperdiet neque, accumsan auctor magna viverra a.  Aliquam eget augue a ante malesuada convallis a nec mi. Phasellus  mollis, urna et interdum congue, lacus ante lacinia ipsum, vitae  fringilla quam mi id ipsum.</p>', NULL, 'en-GB', 'category', 0, 2, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 2, NULL, NULL, NULL),
('name', 'Computers and Internet', NULL, 'en-GB', 'category', 0, 2, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 3, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 3, NULL, NULL, NULL),
('name', 'Games', NULL, 'en-GB', 'category', 0, 3, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 4, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 4, NULL, NULL, NULL),
('name', 'Health', NULL, 'en-GB', 'category', 0, 4, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 5, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 5, NULL, NULL, NULL),
('name', 'Home & Garden', NULL, 'en-GB', 'category', 0, 5, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 6, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 6, NULL, NULL, NULL),
('name', 'News', NULL, 'en-GB', 'category', 0, 6, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 7, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 7, NULL, NULL, NULL),
('name', 'Shopping', NULL, 'en-GB', 'category', 0, 7, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 8, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 8, NULL, NULL, NULL),
('name', 'Communications', NULL, 'en-GB', 'category', 0, 8, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 9, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 9, NULL, NULL, NULL),
('name', 'Graphics', NULL, 'en-GB', 'category', 0, 9, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 10, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 10, NULL, NULL, NULL),
('name', 'Hardware', NULL, 'en-GB', 'category', 0, 10, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 11, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 11, NULL, NULL, NULL),
('name', 'Mobile Computing', NULL, 'en-GB', 'category', 0, 11, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 12, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 12, NULL, NULL, NULL),
('name', 'Multimedia', NULL, 'en-GB', 'category', 0, 12, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 13, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 13, NULL, NULL, NULL),
('name', 'Open Source', NULL, 'en-GB', 'category', 0, 13, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 14, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 14, NULL, NULL, NULL),
('name', 'Card Games', NULL, 'en-GB', 'category', 0, 14, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 15, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 15, NULL, NULL, NULL),
('name', 'Computer Games', NULL, 'en-GB', 'category', 0, 15, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 16, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 16, NULL, NULL, NULL),
('name', 'Puzzles', NULL, 'en-GB', 'category', 0, 16, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 17, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 17, NULL, NULL, NULL),
('name', 'Video Games', NULL, 'en-GB', 'category', 0, 17, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 18, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 18, NULL, NULL, NULL),
('name', 'Beauty', NULL, 'en-GB', 'category', 0, 18, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 19, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 19, NULL, NULL, NULL),
('name', 'Fitness', NULL, 'en-GB', 'category', 0, 19, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 20, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 20, NULL, NULL, NULL),
('name', 'Pharmacy', NULL, 'en-GB', 'category', 0, 20, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 21, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 21, NULL, NULL, NULL),
('name', 'Weight Loss', NULL, 'en-GB', 'category', 0, 21, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 22, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 22, NULL, NULL, NULL),
('name', 'Do-It-Yourself', NULL, 'en-GB', 'category', 0, 22, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 23, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 23, NULL, NULL, NULL),
('name', 'Moving and Relocating', NULL, 'en-GB', 'category', 0, 23, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 24, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 24, NULL, NULL, NULL),
('name', 'Personal Finance', NULL, 'en-GB', 'category', 0, 24, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 25, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 25, NULL, NULL, NULL),
('name', 'Pets', NULL, 'en-GB', 'category', 0, 25, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 26, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 26, NULL, NULL, NULL),
('name', 'Chats and Forums', NULL, 'en-GB', 'category', 0, 26, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 27, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 27, NULL, NULL, NULL),
('name', 'Current Events', NULL, 'en-GB', 'category', 0, 27, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 28, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 28, NULL, NULL, NULL),
('name', 'Journalism', NULL, 'en-GB', 'category', 0, 28, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 29, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 29, NULL, NULL, NULL),
('name', 'Television', NULL, 'en-GB', 'category', 0, 29, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 30, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 30, NULL, NULL, NULL),
('name', 'Weather', NULL, 'en-GB', 'category', 0, 30, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 31, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 31, NULL, NULL, NULL),
('name', 'Books', NULL, 'en-GB', 'category', 0, 31, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 32, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 32, NULL, NULL, NULL),
('name', 'Movies & Music', NULL, 'en-GB', 'category', 0, 32, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 33, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 33, NULL, NULL, NULL),
('name', 'Toys', NULL, 'en-GB', 'category', 0, 33, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 34, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 34, NULL, NULL, NULL),
('name', 'Home Improvement', NULL, 'en-GB', 'category', 0, 34, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 35, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 35, NULL, NULL, NULL),
('name', 'Software', NULL, 'en-GB', 'category', 0, 35, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'category', 0, 36, NULL, NULL, NULL),
('introtext', '', NULL, 'en-GB', 'category', 0, 36, NULL, NULL, NULL),
('name', 'Autos', NULL, 'en-GB', 'category', 0, 36, NULL, NULL, NULL),
('name', 'Postcode', NULL, 'en-GB', 'field', 2, 0, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'field', 2, 0, NULL, NULL, NULL),
('name', 'City', NULL, 'en-GB', 'field', 3, 0, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'field', 3, 0, NULL, NULL, NULL),
('name', 'Contact Person', NULL, 'en-GB', 'field', 4, 0, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'field', 4, 0, NULL, NULL, NULL),
('name', 'Phone', NULL, 'en-GB', 'field', 5, 0, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'field', 5, 0, NULL, NULL, NULL),
('name', 'Fax', NULL, 'en-GB', 'field', 6, 0, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'field', 6, 0, NULL, NULL, NULL),
('name', 'Email', NULL, 'en-GB', 'field', 7, 0, NULL, NULL, NULL),
('description', 'The entered email address will not be visible for visitors', NULL, 'en-GB', 'field', 7, 0, NULL, NULL, NULL),
('name', 'Short Description', NULL, 'en-GB', 'field', 8, 0, NULL, NULL, NULL),
('description', 'Short company description. This text will be displayed at the category listing page. Maximal length 300 characters. ', NULL, 'en-GB', 'field', 8, 0, NULL, NULL, NULL),
('name', 'Full Description', NULL, 'en-GB', 'field', 9, 0, NULL, NULL, NULL),
('description', 'Full company description will be displayed at the details view page.', NULL, 'en-GB', 'field', 9, 0, NULL, NULL, NULL),
('name', 'Company Logo', NULL, 'en-GB', 'field', 10, 0, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'field', 10, 0, NULL, NULL, NULL),
('name', 'Website', NULL, 'en-GB', 'field', 11, 0, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'field', 11, 0, NULL, NULL, NULL),
('name', 'Business Days', NULL, 'en-GB', 'field', 12, 0, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'field', 12, 0, NULL, NULL, NULL),
('Sunday', 'Sunday', NULL, 'en-GB', 'field_option', 12, 0, NULL, NULL, NULL),
('Saturday', 'Saturday', NULL, 'en-GB', 'field_option', 12, 0, NULL, NULL, NULL),
('Friday', 'Friday', NULL, 'en-GB', 'field_option', 12, 0, NULL, NULL, NULL),
('Thursday', 'Thursday', NULL, 'en-GB', 'field_option', 12, 0, NULL, NULL, NULL),
('Wednesday', 'Wednesday', NULL, 'en-GB', 'field_option', 12, 0, NULL, NULL, NULL),
('Tuesday', 'Tuesday', NULL, 'en-GB', 'field_option', 12, 0, NULL, NULL, NULL),
('Monday', 'Monday', NULL, 'en-GB', 'field_option', 12, 0, NULL, NULL, NULL),
('name', 'No name', NULL, 'en-GB', 'entry', 0, 37, NULL, NULL, NULL),
('name', '', NULL, 'en-GB', 'entry', 0, 38, NULL, NULL, NULL),
('name', '', NULL, 'en-GB', 'entry', 0, 39, NULL, NULL, NULL),
('name', 'Country', NULL, 'en-GB', 'field', 13, 0, NULL, NULL, NULL),
('description', '', NULL, 'en-GB', 'field', 13, 0, NULL, NULL, NULL),
('johnston-atoll', 'Johnston Atoll', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('palau', 'Palau', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('jarvis-island', 'Jarvis Island', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('niue', 'Niue', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('howland-island', 'Howland Island', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('micronesia', 'Micronesia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('french-polynesia', 'French Polynesia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('nauru', 'Nauru', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('kiribati', 'Kiribati', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('coral-sea-islands', 'Coral Sea Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('guam', 'Guam', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('cook-islands', 'Cook Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('baker-island', 'Baker Island', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('fiji', 'Fiji', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('ashmore-and-cartier', 'Ashmore and Cartier Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('american-samoa', 'American Samoa', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('oceania', ' Oceania', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('australia', 'Australia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('french-guiana', 'French Guiana', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('falkland-islands', 'Falkland Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('south-america', 'South America', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('venezuela', 'Venezuela', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('uruguay', 'Uruguay', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('suriname', 'Suriname', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('peru', 'Peru', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('paraguay', 'Paraguay', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('guyana', 'Guyana', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('virgin-islands', 'United States Virgin Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('ecuador', 'Ecuador', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('colombia', 'Colombia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('brazil', 'Brazil', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('chile', 'Chile', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('bolivia', 'Bolivia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('turks-and-caicos-islands', 'Turks and Caicos Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('argentina', 'Argentina', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('usa', 'United States', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('trinidad-and-tobago', 'Trinidad and Tobago', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('saint-vincent-grenadines', 'Saint Vincent and the Grenadines', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('saint-pierre-and-miquelon', 'Saint Pierre and Miquelon', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('saint-martin', 'Saint Martin', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('saint-lucia', 'Saint Lucia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('saint-kitts-and-nevis', 'Saint Kitts and Nevis', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('saint-barthelemy', 'Saint Barthélemy', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('puerto-rico', 'Puerto Rico', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('nicaragua', 'Nicaragua', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('panama', 'Panama', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('netherlands-antilles', 'Netherlands Antilles', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('navassa-island', 'Navassa Island', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('montserrat', 'Montserrat', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('mexico', 'Mexico', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('martinique', 'Martinique', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('jamaica', 'Jamaica', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('honduras', 'Honduras', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('haiti', 'Haiti', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('guatemala', 'Guatemala', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('guadeloupe', 'Guadeloupe', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('grenada', 'Grenada', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('el-salvador', 'El Salvador', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('greenland', 'Greenland', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('dominican-republic', 'Dominican Republic', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('dominica', 'Dominica', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('cuba', 'Cuba', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('costa-rica', 'Costa Rica', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('clipperton-island', 'Clipperton Island', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('canada', 'Canada', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('cayman-islands', 'Cayman Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('british-virgin-islands', 'British Virgin Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('bermuda', 'Bermuda', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('belize', 'Belize', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('barbados', 'Barbados', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('aruba', 'Aruba', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('bahamas', 'Bahamas', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('antigua-and-barbuda', 'Antigua and Barbuda', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('anguilla', 'Anguilla', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('north-america', 'North America', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('vatican', 'Vatican City', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('ukraine', 'Ukraine', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('transnistria', 'Transnistria', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('switzerland', 'Switzerland', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('sweden', 'Sweden', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('svalbard', 'Svalbard', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('spain', 'Spain', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('slovenia', 'Slovenia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('serbia', 'Serbia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('slovakia', 'Slovakia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('russia', 'Russia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('united-kingdom', 'United Kingdom', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('romania', 'Romania', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('portugal', 'Portugal', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('poland', 'Poland', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('norway', 'Norway', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('netherlands', 'Netherlands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('montenegro', 'Montenegro', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('monaco', 'Monaco', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('kosovo', 'Kosovo', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('latvia', 'Latvia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('liechtenstein', 'Liechtenstein', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('lithuania', 'Lithuania', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('luxembourg', 'Luxembourg', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('macedonia', 'Macedonia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('malta', 'Malta', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('moldova', 'Moldova', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('jersey', 'Jersey', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('italy', 'Italy', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('ireland', 'Ireland', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('san-marino', 'San Marino', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('iceland', 'Iceland', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('hungary', 'Hungary', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('guernsey', 'Guernsey', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('greece', 'Greece', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('gibraltar', 'Gibraltar', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('germany', 'Germany', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('isle-of-man', 'Isle of Man', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('france', 'France', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('finland', 'Finland', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('estonia', 'Estonia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('denmark', 'Denmark', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('faroe-islands', 'Faroe Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('belgium', 'Belgium', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('czech-republic', 'Czech Republic', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('croatia', 'Croatia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('bulgaria', 'Bulgaria', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('belarus', 'Belarus', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('andorra', 'Andorra', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('austria', 'Austria', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('albania', 'Albania', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('vietnam', 'Vietnam', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('yemen', 'Yemen', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('bosnia-herzegovina', 'Bosnia and Herzegovina', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('uzbekistan', 'Uzbekistan', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('aland-islands', 'Åland Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('turkmenistan', 'Turkmenistan', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('turkey', 'Turkey', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('thailand', 'Thailand', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('timor-leste', 'Timor-Leste', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('tajikistan', 'Tajikistan', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('europe', ' Europe', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('syria', 'Syria', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('singapore', 'Singapore', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('philippines', 'Philippines', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('qatar', 'Qatar', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('united-arab-emirates', 'United Arab Emirates', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('sri-lanka', 'Sri Lanka', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('pakistan', 'Pakistan', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('nepal', 'Nepal', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('oman', 'Oman', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('south-ossetia', 'South Ossetia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('nagorno-karabakh', 'Nagorno-Karabakh', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('maldives', 'Maldives', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('mongolia', 'Mongolia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('myanmar', 'Myanmar', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('macau', 'Macau', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('malaysia', 'Malaysia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('lebanon', 'Lebanon', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('laos', 'Laos', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('saudi-arabia', 'Saudi Arabia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('kuwait', 'Kuwait', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('kyrgyzstan', 'Kyrgyzstan', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('kazakhstan', 'Kazakhstan', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('jordan', 'Jordan', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('japan', 'Japan', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('israel', 'Israel', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('iraq', 'Iraq', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('iran', 'Iran', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('palestinian-territories', 'Palestinian territories', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('india', 'India', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('indonesia', 'Indonesia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('georgia', 'Georgia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('cyprus', 'Cyprus', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('taiwan', 'China, Republic of - Taiwan', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('northern-cyprus', 'Northern Cyprus', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('china', 'China', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('cambodia', 'Cambodia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('brunei', 'Brunei', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('korea-republic', 'Korea, Republic of', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('bhutan', 'Bhutan', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('bangladesh', 'Bangladesh', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('bahrain', 'Bahrain', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('azerbaijan', 'Azerbaijan', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('armenia', 'Armenia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('north-korea', 'Korea, Democratic People''s Republic of', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('afghanistan', 'Afghanistan', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('zambia', 'Zambia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('zimbabwe', 'Zimbabwe', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('asia', 'Asia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('abkhazia', 'Abkhazia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('hong-kong', 'Hong Kong', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('uganda', 'Uganda', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('tunisia', 'Tunisia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('swaziland', 'Swaziland', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('sudan', 'Sudan', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('somalia', 'Somalia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('somaliland', 'Somaliland', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('cocos-islands', 'Cocos (Keeling) Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('senegal', 'Senegal', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('seychelles', 'Seychelles', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('christmas-island', 'Christmas Island', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('rwanda', 'Rwanda', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('niger', 'Niger', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('nigeria', 'Nigeria', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('namibia', 'Namibia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('mozambique', 'Mozambique', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('mayotte', 'Mayotte', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('morocco', 'Morocco', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('mauritius', 'Mauritius', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('mauritania', 'Mauritania', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('mali', 'Mali', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('malawi', 'Malawi', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('madagascar', 'Madagascar', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('libya', 'Libya', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('liberia', 'Liberia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('lesotho', 'Lesotho', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('kenya', 'Kenya', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('guinea-bissau', 'Guinea-Bissau', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('guinea', 'Guinea', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('ghana', 'Ghana', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('gambia', 'Gambia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('gabon', 'Gabon', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('ethiopia', 'Ethiopia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('eritrea', 'Eritrea', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('british-indian', 'British Indian Ocean Territory', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('egypt', 'Egypt', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('djibouti', 'Djibouti', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('akrotiri-and-dhekelia', 'Akrotiri and Dhekelia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('western-sahara', 'Western Sahara', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('south-africa', 'South Africa', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('comoros', 'Comoros', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('chad', 'Chad', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('sierra-leone', 'Sierra Leone', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('cameroon', 'Cameroon', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('burundi', 'Burundi', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('sao-tome-and-principe', 'Sao Tome and Principe', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('botswana', 'Botswana', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('benin', 'Benin', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('angola', 'Angola', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('algeria', 'Algeria', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('africa', 'Africa', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('reunion', 'Réunion', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('samoa', 'Samoa', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('equatorial-guinea', 'Equatorial Guinea', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('tokelau', 'Tokelau', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('tonga', 'Tonga', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('tuvalu', 'Tuvalu', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('vanuatu', 'Vanuatu', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('cote-d-ivoire', 'Côte d''Ivoire', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('congo-republic-of', 'Congo, Republic of', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('congo-democratic', 'Congo, Democratic Republic of', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('central-african-republic', 'Central African Republic', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('burkina-faso', 'Burkina Faso', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('cape-verde', 'Cape Verde', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('kingman-reef', 'Kingman Reef', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('marshall-islands', 'Marshall Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('midway-atoll', 'Midway Atoll', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('new-caledonia', 'New Caledonia', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('new-zealand', 'New Zealand', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('norfolk-island', 'Norfolk Island', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('northern-mariana-islands', 'Northern Mariana Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('palmyra-atoll', 'Palmyra Atoll', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('papua-new-guinea', 'Papua New Guinea', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('pitcairn-islands', 'Pitcairn Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('solomon-islands', 'Solomon Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('wake-island', 'Wake Island', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('wallis-and-futuna', 'Wallis and Futuna', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('antarctica', ' Antarctica', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('bouvet-island', 'Bouvet Island', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('french-southern-territories', 'French Southern Territories', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('heard-island-mcdonald-islands', 'Heard Island and McDonald Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('south-georgia-south-sandwich-islands', 'South Georgia and the South Sandwich Islands', NULL, 'en-GB', 'field_option', 13, 0, NULL, NULL, NULL),
('suffix', '', NULL, 'en-GB', 'field', 6, 0, NULL, NULL, NULL),
('metaKeys', 'Business, Directory', NULL, 'en-GB', 'section', 0, 1, NULL, NULL, NULL),
('metaDesc', 'Business Directory', NULL, 'en-GB', 'section', 0, 1, NULL, NULL, NULL),
('name', 'Street', NULL, 'en-GB', 'field', 14, 0, NULL, NULL, NULL),
('name', 'Category', NULL, 'en-GB', 'field', 15, 0, NULL, NULL, NULL),
('bankdata', '<p>Payment Subject: "Entry in the {section.name} at the {cfg:site_name}. Entry id {entry.id}"</p>\r\n<ul>\r\n<li>Account Owner: Jon Doe </li>\r\n<li>Account No.: 8274230479 </li>\r\n<li>Bank No.: 8038012380 </li>\r\n<li>IBAN: 234242343018 </li>\r\n<li>BIC: 07979079779ABCDEFGH</li>\r\n</ul>', 1, 'en-GB', 'application', 0, 1, '', '', ''),
('ppexpl', '<p>Please click on the button below to pay via Paypal.</p>\r\n<p> </p>', 1, 'en-GB', 'application', 0, 1, '', '', ''),
('ppsubject', 'Entry in the {section.name} at the {cfg:site_name}. Entry id {entry.id}', 1, 'en-GB', 'application', 0, 1, '', '', ''),
('sfMetaKeys', 'search', NULL, 'en-GB', 'section', 0, 1, NULL, NULL, NULL),
('sfMetaDesc', 'Search Business', NULL, 'en-GB', 'section', 0, 1, NULL, NULL, NULL),
('efMetaKeys', 'add, edit', NULL, 'en-GB', 'section', 0, 1, NULL, NULL, NULL),
('efMetaDesc', 'Add/Edit Business', NULL, 'en-GB', 'section', 0, 1, NULL, NULL, NULL),
('rejection-of-a-new-entry', 'Entry {entry.name} has been rejected as it does not comply with the rules.\n\nRejected by {user.name} at {date%F Y H:i:s}', 0, 'en-GB', 'rejections-templates', 0, 1, '', '', ''),
('rejection-of-changes', 'Changes in {entry.name} discarded as these changes violating rules. \n\nRejected by {user.name} at {date}', 0, 'en-GB', 'rejections-templates', 0, 1, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_object`
--

CREATE TABLE `sas_sobipro_object` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nid` varchar(255) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `approved` tinyint(1) DEFAULT NULL,
  `confirmed` tinyint(1) DEFAULT NULL,
  `counter` int(11) NOT NULL DEFAULT '0',
  `cout` int(11) DEFAULT NULL,
  `coutTime` datetime DEFAULT NULL,
  `createdTime` datetime DEFAULT NULL,
  `defURL` varchar(250) DEFAULT NULL,
  `metaDesc` text,
  `metaKeys` text,
  `metaAuthor` varchar(150) NOT NULL,
  `metaRobots` varchar(150) NOT NULL,
  `options` text,
  `oType` varchar(50) DEFAULT NULL,
  `owner` int(11) DEFAULT NULL,
  `ownerIP` varchar(15) DEFAULT NULL,
  `params` text,
  `parent` int(11) DEFAULT NULL,
  `state` tinyint(4) DEFAULT NULL,
  `stateExpl` varchar(250) DEFAULT NULL,
  `updatedTime` datetime DEFAULT NULL,
  `updater` int(11) DEFAULT NULL,
  `updaterIP` varchar(15) DEFAULT NULL,
  `validSince` datetime DEFAULT NULL,
  `validUntil` datetime DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `oType` (`oType`),
  KEY `owner` (`owner`),
  KEY `parent` (`parent`),
  KEY `state` (`state`),
  KEY `validSince` (`validSince`),
  KEY `validUntil` (`validUntil`),
  KEY `version` (`version`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=54 ;

--
-- Dumping data for table 'sas_sobipro_object'
--

INSERT INTO `sas_sobipro_object` VALUES
(1, 'business-directory', 'Business Directory', 1, 1, 674, 0, '0000-00-00 00:00:00', '2013-01-02 00:00:00', '', 'Business Directory', 'Business, Directory', 'Radek Suski', '', '', 'section', 63, '84.59.167.50', '', 0, 1, '', '2013-01-02 16:24:47', 791, '192.168.1.32', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 2),
(2, 'computers-and-internet', 'Computers and Internet', 1, 0, 104, 0, '0000-00-00 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 1, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(3, 'games', 'Games', 1, 0, 15, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 1, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(4, 'health', 'Health', 1, 0, 13, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 1, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(5, 'home-garden', 'Home & Garden', 1, 0, 12, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 1, 1, '', '0000-00-00 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(6, 'news', 'News', 1, 0, 13, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 1, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(7, 'shopping', 'Shopping', 1, 0, 37, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 1, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(8, 'communications', 'Communications', 1, 0, 20, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 2, 1, '', '2010-08-24 21:23:32', 63, '84.59.167.50', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(9, 'graphics', 'Graphics', 1, 0, 10, 0, '0000-00-00 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 2, 1, '', '2010-08-24 21:15:14', 63, '84.59.167.50', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(10, 'hardware', 'Hardware', 1, 0, 8, 0, '0000-00-00 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 2, 1, '', '2010-08-24 21:16:49', 63, '84.59.167.50', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(11, 'mobile-computing', 'Mobile Computing', 1, 0, 7, 0, '0000-00-00 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 2, 1, '', '2010-08-24 21:18:03', 63, '84.59.167.50', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(12, 'multimedia', 'Multimedia', 1, 0, 11, 0, '0000-00-00 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 2, 1, '', '2010-08-24 21:18:41', 63, '84.59.167.50', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(13, 'open-source', 'Open Source', 1, 0, 5, 0, '0000-00-00 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 2, 1, '', '2010-08-24 21:19:55', 63, '84.59.167.50', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(14, 'card-games', 'Card Games', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 3, 1, '', '2010-08-24 21:20:52', 63, '84.59.167.50', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(15, 'computer-games', 'Computer Games', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 3, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 3),
(16, 'puzzles', 'Puzzles', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 3, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 3),
(17, 'video-games', 'Video Games', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 3, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(18, 'beauty', 'Beauty', 1, 0, 7, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 4, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(19, 'fitness', 'Fitness', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 4, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(20, 'pharmacy', 'Pharmacy', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 4, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(21, 'weight-loss', 'Weight Loss', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 4, 1, '', '2013-01-02 00:00:00', 63, '84.59.167.50', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 2),
(22, 'do-it-yourself', 'Do it Yourself', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 5, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 2),
(23, 'moving-and-relocating', 'Moving and Relocating', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 5, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 2),
(24, 'personal-finance', 'Personal Finance', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 5, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 2),
(25, 'pets', 'Pets', 1, 0, 7, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 5, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 2),
(26, 'chats-and-forums', 'Chats and Forums', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 6, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 3),
(27, 'current-events', 'Current Events', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 6, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 3),
(28, 'journalism', 'Journalism', 1, 0, 6, 0, '0000-00-00 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 6, 1, '', '2010-08-24 21:33:04', 63, '84.59.167.50', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(29, 'television', 'Television', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 6, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(30, 'weather', 'Weather', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 6, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(31, 'books', 'Books', 1, 0, 6, 0, '0000-00-00 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 7, 1, '', '2010-08-24 21:35:34', 63, '84.59.167.50', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(32, 'movies-music', 'Movies & Music', 1, 0, 7, 0, '0000-00-00 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 7, 1, '', '2010-08-24 21:36:22', 63, '84.59.167.50', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(33, 'toys', 'Toys', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 7, 1, '', '2010-08-24 21:36:49', 63, '84.59.167.50', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(34, 'home-improvement', 'Home Improvement', 1, 0, 7, 0, '0000-00-00 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 7, 1, '', '2010-08-24 21:37:49', 63, '84.59.167.50', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 1),
(35, 'software', 'Software', 1, 0, 4, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 2, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 4),
(36, 'autos', 'Autos', 1, 0, 6, 63, '2013-01-02 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'category', 63, '84.59.167.50', '', 7, 1, '', '2013-01-02 00:00:00', 63, '88.68.227.138', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 2),
(37, 'neo-electronics', '', 1, 0, 35, 0, '0000-00-00 00:00:00', '2013-01-02 17:26:12', '', '', '', '', '', '', 'entry', 0, '88.68.227.138', '', 2, 1, '', '2013-01-02 16:25:51', 791, '192.168.1.32', '2013-01-02 17:26:08', '0000-00-00 00:00:00', 4),
(38, 'n-communications', '', 1, 0, 114, 0, '0000-00-00 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'entry', 0, '88.68.227.138', '', 8, 1, '', '2013-01-02 00:00:00', 63, '88.69.191.86', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 5),
(39, 'sun-bookstore', '', 1, 0, 68, 0, '0000-00-00 00:00:00', '2013-01-02 00:00:00', '', '', '', '', '', '', 'entry', 0, '88.68.227.138', '', 32, 1, '', '2013-01-02 00:00:00', 63, '88.69.191.86', '2013-01-02 00:00:00', '0000-00-00 00:00:00', 6);

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_payments`
--

CREATE TABLE `sas_sobipro_payments` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `refNum` varchar(50) NOT NULL,
  `sid` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `subject` varchar(150) NOT NULL,
  `dateAdded` datetime NOT NULL,
  `datePaid` datetime NOT NULL,
  `validUntil` datetime NOT NULL,
  `paid` tinyint(4) NOT NULL,
  `amount` double NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table 'sas_sobipro_payments'
--

INSERT INTO `sas_sobipro_payments` VALUES
(1, '1282745518.37', 37, 9, 'Full Description', '2013-01-02 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 20, ''),
(2, '1282745518.37', 37, 10, 'Company Logo', '2013-01-02 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 5, ''),
(3, '1282745518.37', 37, 11, 'Website', '2013-01-02 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 10, ''),
(4, '1282748655.38', 38, 10, 'Company Logo', '2013-01-02 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 5, ''),
(5, '1282748655.38', 38, 11, 'Website', '2013-01-02 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 10, ''),
(6, '1282748655.38', 38, 9, 'Full Description', '2013-01-02 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 20, ''),
(7, '1282750744.39', 39, 10, 'Company Logo', '2013-01-02 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 5, ''),
(8, '1282750744.39', 39, 11, 'Website', '2013-01-02 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 10, ''),
(9, '1282750744.39', 39, 9, 'Full Description', '2013-01-02 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 20, '');

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_permissions`
--

CREATE TABLE `sas_sobipro_permissions` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(150) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `value` varchar(50) NOT NULL,
  `site` varchar(50) NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `uniquePermission` (`subject`,`action`,`value`,`site`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Dumping data for table 'sas_sobipro_permissions'
--

INSERT INTO `sas_sobipro_permissions` VALUES
(1, '*', '*', '*', 'front', 0),
(2, 'section', '*', '*', 'front', 0),
(3, 'section', 'access', '*', 'front', 1),
(4, 'section', 'access', 'valid', 'front', 1),
(6, 'category', '*', '*', 'front', 0),
(7, 'category', 'access', 'valid', 'front', 1),
(8, 'category', 'access', '*', 'front', 1),
(9, 'entry', '*', '*', 'front', 1),
(10, 'entry', 'access', 'valid', 'front', 1),
(11, 'entry', 'access', '*', 'front', 1),
(12, 'entry', 'access', 'unpublished_own', 'front', 1),
(13, 'entry', 'access', 'unapproved_own', 'front', 0),
(14, 'entry', 'access', 'unpublished_any', 'front', 1),
(15, 'entry', 'access', 'unapproved_any', 'front', 1),
(16, 'entry', 'add', 'own', 'front', 1),
(17, 'entry', 'edit', 'own', 'front', 1),
(18, 'entry', 'edit', '*', 'front', 1),
(19, 'entry', 'manage', '*', 'front', 1),
(20, 'entry', 'publish', '*', 'front', 1),
(21, 'entry', 'publish', 'own', 'front', 1),
(22, 'entry', 'adm_fields', '*', 'front', 0),
(23, 'entry', 'adm_fields', 'see', 'front', 0),
(24, 'entry', 'adm_fields', 'edit', 'front', 1),
(25, 'entry', 'payment', 'free', 'front', 1),
(26, 'section', 'search', '*', 'front', 1),
(27, 'entry', 'delete', 'own', 'front', 1),
(28, 'entry', 'delete', '*', 'front', 1);

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_permissions_groups`
--

CREATE TABLE `sas_sobipro_permissions_groups` (
  `rid` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  PRIMARY KEY (`rid`,`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_sobipro_permissions_groups'
--

INSERT INTO `sas_sobipro_permissions_groups` VALUES
(1, 0),
(2, 2),
(2, 29);

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_permissions_map`
--

CREATE TABLE `sas_sobipro_permissions_map` (
  `rid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  PRIMARY KEY (`rid`,`sid`,`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_sobipro_permissions_map'
--

INSERT INTO `sas_sobipro_permissions_map` VALUES
(1, 1, 4),
(1, 1, 7),
(1, 1, 10),
(1, 1, 16),
(1, 1, 26),
(2, 1, 16),
(2, 1, 17);

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_permissions_rules`
--

CREATE TABLE `sas_sobipro_permissions_rules` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `nid` varchar(50) NOT NULL,
  `validSince` datetime NOT NULL,
  `validUntil` datetime NOT NULL,
  `note` varchar(250) NOT NULL,
  `state` tinyint(4) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table 'sas_sobipro_permissions_rules'
--

INSERT INTO `sas_sobipro_permissions_rules` VALUES
(1, 'Visitor', 'visitor', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1),
(2, 'Registered', 'registered', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_plugins`
--

CREATE TABLE `sas_sobipro_plugins` (
  `pid` varchar(50) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `version` varchar(50) NOT NULL,
  `description` text,
  `author` varchar(150) DEFAULT NULL,
  `authorURL` varchar(250) DEFAULT NULL,
  `authorMail` varchar(150) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  `depend` text NOT NULL,
  UNIQUE KEY `pid` (`pid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_sobipro_plugins'
--

INSERT INTO `sas_sobipro_plugins` VALUES
('bank_transfer', 'Offline Payment', '1.1', NULL, 'Sigsiu.NET GmbH', 'http://www.sigsiu.net/', 'sobi@sigsiu.net', 1, 'payment', ''),
('paypal', 'PayPal', '1.1', NULL, 'Sigsiu.NET GmbH', 'http://www.sigsiu.net/', 'sobi@sigsiu.net', 1, 'payment', ''),
('chbxgroup', 'Check Box Group', '1.1', NULL, 'Sigsiu.NET GmbH', 'http://www.sigsiu.net/', 'sobi@sigsiu.net', 1, 'field', ''),
('email', 'Email', '1.1', NULL, 'Sigsiu.NET GmbH', 'http://www.sigsiu.net/', 'sobi@sigsiu.net', 1, 'field', ''),
('image', 'Image', '1.1', NULL, 'Sigsiu.NET GmbH', 'http://www.sigsiu.net/', 'sobi@sigsiu.net', 1, 'field', ''),
('inbox', 'Input Box', '1.1', NULL, 'Sigsiu.NET GmbH', 'http://www.sigsiu.net/', 'sobi@sigsiu.net', 1, 'field', ''),
('multiselect', 'Multiple Select List', '1.1', NULL, 'Sigsiu.NET GmbH', 'http://www.sigsiu.net/', 'sobi@sigsiu.net', 1, 'field', ''),
('radio', 'Radio Buttons', '1.1', NULL, 'Sigsiu.NET GmbH', 'http://www.sigsiu.net/', 'sobi@sigsiu.net', 1, 'field', ''),
('select', 'Single Select List', '1.1', NULL, 'Sigsiu.NET GmbH', 'http://www.sigsiu.net/', 'sobi@sigsiu.net', 1, 'field', ''),
('textarea', 'Text Area', '1.1', NULL, 'Sigsiu.NET GmbH', 'http://www.sigsiu.net/', 'sobi@sigsiu.net', 1, 'field', ''),
('url', 'URL', '1.1', NULL, 'Sigsiu.NET GmbH', 'http://www.sigsiu.net/', 'sobi@sigsiu.net', 1, 'field', ''),
('category', 'Category', '1.1', NULL, 'Sigsiu.NET GmbH', 'http://www.sigsiu.net/', 'sobi@sigsiu.net', 1, 'field', '');

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_plugin_section`
--

CREATE TABLE `sas_sobipro_plugin_section` (
  `section` int(11) NOT NULL DEFAULT '0',
  `pid` varchar(50) NOT NULL DEFAULT '',
  `type` varchar(50) NOT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`section`,`pid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_sobipro_plugin_section'
--

INSERT INTO `sas_sobipro_plugin_section` VALUES
(1, 'bank_transfer', 'payment', 1, 0),
(1, 'paypal', 'payment', 1, 0),
(71, 'bank_transfer', 'payment', 1, 1),
(71, 'paypal', 'payment', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_plugin_task`
--

CREATE TABLE `sas_sobipro_plugin_task` (
  `pid` varchar(50) NOT NULL DEFAULT '',
  `onAction` varchar(150) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  UNIQUE KEY `pid` (`pid`,`onAction`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_sobipro_plugin_task'
--

INSERT INTO `sas_sobipro_plugin_task` VALUES
('bank_transfer', 'adm_menu', 'payment'),
('bank_transfer', 'entry.payment', 'payment'),
('bank_transfer', 'entry.save', 'payment'),
('bank_transfer', 'entry.submit', 'payment'),
('paypal', 'adm_menu', 'payment'),
('paypal', 'entry.payment', 'payment'),
('paypal', 'entry.save', 'payment'),
('paypal', 'entry.submit', 'payment');

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_registry`
--

CREATE TABLE `sas_sobipro_registry` (
  `section` varchar(150) NOT NULL,
  `key` varchar(150) NOT NULL,
  `value` text NOT NULL,
  `params` text NOT NULL,
  `description` text NOT NULL,
  `options` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_sobipro_registry'
--

INSERT INTO `sas_sobipro_registry` VALUES
('fields_filter', 'website_full', 'Website with Protocol', 'L15odHRwKHMpPzpcL1wvW1x3XC4tXStcLnsxfVthLXpBLVpdezIsNX0oXC9bXlxzXSopPyQv', 'Please enter a valid URL address in the $field field', ''),
('fields_filter', 'website', 'Website w/o Protocol', 'L15bXHdcLi1dK1wuezF9W2EtekEtWl17Miw1fShcL1teXHNdKik/JC8=', 'Please enter a valid website address without the protocol in the $field field', ''),
('fields_filter', 'title', 'Valid Title', 'L15bXHdcZF0rW1x3XGRccyFAXCRcJVwmXCpcIlwnXC1cK19dKiQv', 'The data entered in the $field field contains not allowed characters', 'custom'),
('fields_filter', 'single_letter', 'Single Letter', 'L15bYS16QS1aXSQv', 'This $field field accept only one letter value', ''),
('fields_filter', 'phone', 'Telephone Number', 'L14oXCtcZHsxLDN9XHM/KT8oXHM/XChbXGRdXClccz8pP1tcZFwtXHNcLl0rJC8=', 'Please enter a valid telephone number into $field field.', ''),
('fields_filter', 'integer', 'Decimal Value', 'L15cZCskLw==', 'Please enter a numeric value in the $field field', ''),
('fields_filter', 'float', 'Float Value', 'L15cZCsoXC5cZCopPyQv', 'Please enter a float value like 9.9 or 12.34 into the  $field field', ''),
('fields_filter', 'alphanum', 'Alphanumeric String', 'L15bYS16QS1aMC05XSskLw==', 'In the $field field only alphabetic and numeric characters are allowed', ''),
('fields_filter', 'email', 'Email Address', 'L15bXHdcLi1dK0BbXHdcLi1dK1wuW2EtekEtWl17Miw1fSQv', 'Please enter an email address into the $field field', ''),
('fields_filter', 'alpha', 'Alphabetic String', 'L15bYS16QS1aXSskLw==', 'In this $field field only letters are allowed', ''),
('paypal', 'ppcc', 'EUR', '', '', ''),
('paypal', 'pprurl', '{cfg:live_site}/index.php?option=com_sobipro&sid={section.id}', '', '', ''),
('paypal', 'ppurl', 'https://www.paypal.com/cgi-bin/webscr', '', '', ''),
('paypal', 'ppemail', 'change@me.com', '', '', ''),
('rejections-templates', 'rejection-of-a-new-entry', 'Rejection of a new entry', 'YTo0OntzOjE3OiJ0cmlnZ2VyLnVucHVibGlzaCI7YjoxO3M6MTc6InRyaWdnZXIudW5hcHByb3ZlIjtiOjA7czo5OiJ1bnB1Ymxpc2giO2I6MTtzOjc6ImRpc2NhcmQiO2I6MDt9', '', ''),
('rejections-templates', 'rejection-of-changes', 'Rejection of changes', 'YTo0OntzOjE3OiJ0cmlnZ2VyLnVucHVibGlzaCI7YjowO3M6MTc6InRyaWdnZXIudW5hcHByb3ZlIjtiOjE7czo5OiJ1bnB1Ymxpc2giO2I6MDtzOjc6ImRpc2NhcmQiO2I6MTt9', '', '');

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_relations`
--

CREATE TABLE `sas_sobipro_relations` (
  `id` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `oType` varchar(50) NOT NULL,
  `position` int(11) DEFAULT NULL,
  `validSince` datetime DEFAULT NULL,
  `validUntil` datetime DEFAULT NULL,
  `copy` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`,`pid`),
  KEY `oType` (`oType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_sobipro_relations'
--

INSERT INTO `sas_sobipro_relations` VALUES
(1, 0, 'section', 1, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(2, 1, 'category', 1, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(3, 1, 'category', 2, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(4, 1, 'category', 3, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(5, 1, 'category', 4, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(6, 1, 'category', 5, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(7, 1, 'category', 6, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(8, 2, 'category', 1, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(9, 2, 'category', 2, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(10, 2, 'category', 3, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(11, 2, 'category', 4, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(12, 2, 'category', 5, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(13, 2, 'category', 6, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(14, 3, 'category', 1, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(15, 3, 'category', 2, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(16, 3, 'category', 3, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(17, 3, 'category', 4, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(18, 4, 'category', 1, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(19, 4, 'category', 2, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(20, 4, 'category', 3, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(21, 4, 'category', 4, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(22, 5, 'category', 5, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(23, 5, 'category', 6, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(24, 5, 'category', 7, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(25, 5, 'category', 8, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(26, 6, 'category', 9, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(27, 6, 'category', 10, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(28, 6, 'category', 11, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(29, 6, 'category', 12, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(30, 6, 'category', 13, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(31, 7, 'category', 2, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(32, 7, 'category', 3, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(33, 7, 'category', 4, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(34, 7, 'category', 5, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(35, 2, 'category', 7, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(36, 7, 'category', 1, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(37, 2, 'entry', 5, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(37, 10, 'entry', 3, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(37, 11, 'entry', 5, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(37, 12, 'entry', 3, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(37, 35, 'entry', 3, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(38, 2, 'entry', 6, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(38, 8, 'entry', 4, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(38, 9, 'entry', 4, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(38, 11, 'entry', 6, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(39, 7, 'entry', 6, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(39, 31, 'entry', 6, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(39, 32, 'entry', 6, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0),
(39, 33, 'entry', 6, '2013-01-02 00:00:00', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_search`
--

CREATE TABLE `sas_sobipro_search` (
  `ssid` double NOT NULL,
  `lastActive` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `searchCreated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `requestData` text NOT NULL,
  `uid` int(11) NOT NULL,
  `browserData` text NOT NULL,
  `entriesResults` text NOT NULL,
  `catsResults` text NOT NULL,
  PRIMARY KEY (`ssid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_section`
--

CREATE TABLE `sas_sobipro_section` (
  `id` int(11) NOT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_users_relation`
--

CREATE TABLE `sas_sobipro_users_relation` (
  `uid` int(11) NOT NULL DEFAULT '0',
  `gid` int(11) NOT NULL DEFAULT '0',
  `validSince` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `validUntil` datetime DEFAULT NULL,
  PRIMARY KEY (`uid`,`gid`,`validSince`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_user_group`
--

CREATE TABLE `sas_sobipro_user_group` (
  `description` text,
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `enabled` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `groupName` varchar(150) NOT NULL,
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5000 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_view_cache`
--

CREATE TABLE `sas_sobipro_view_cache` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `section` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `fileName` varchar(100) NOT NULL,
  `task` varchar(100) NOT NULL,
  `site` int(11) NOT NULL,
  `request` varchar(255) NOT NULL,
  `language` varchar(15) NOT NULL,
  `template` varchar(150) NOT NULL,
  `configFile` text NOT NULL,
  `userGroups` varchar(200) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`cid`),
  KEY `sid` (`sid`),
  KEY `section` (`section`),
  KEY `language` (`language`),
  KEY `task` (`task`),
  KEY `request` (`request`),
  KEY `site` (`site`),
  KEY `userGroups` (`userGroups`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_sobipro_view_cache_relation`
--

CREATE TABLE `sas_sobipro_view_cache_relation` (
  `cid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  PRIMARY KEY (`cid`,`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_tags`
--

CREATE TABLE `sas_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tag_idx` (`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table 'sas_tags'
--

INSERT INTO `sas_tags` VALUES
(1, 0, 0, 1, 0, '', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '', '', '', '', 0, '2011-01-01 00:00:01', '', 0, '0000-00-00 00:00:00', '', '', 0, '*', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table`sas_template_styles`
--

CREATE TABLE `sas_template_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(50) NOT NULL DEFAULT '',
  `client_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` char(7) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template` (`template`),
  KEY `idx_home` (`home`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table 'sas_template_styles'
--

INSERT INTO `sas_template_styles` VALUES
(4, 'beez3', 0, '0', 'Beez3 - Default', '{"wrapperSmall":"53","wrapperLarge":"72","logo":"images\\/joomla_black.gif","sitetitle":"Joomla!","sitedescription":"Open Source Content Management","navposition":"left","templatecolor":"personal","html5":"0"}'),
(5, 'hathor', 1, '0', 'Hathor - Default', '{"showSiteName":"0","colourChoice":"","boldText":"0"}'),
(7, 'protostar', 0, '1', 'protostar - Default', '{"templateColor":"","logoFile":"","googleFont":"1","googleFontName":"Open+Sans","fluidContainer":"0"}'),
(8, 'isis', 1, '1', 'isis - Default', '{"templateColor":"","logoFile":""}');

-- --------------------------------------------------------

--
-- Table structure for table`sas_ucm_base`
--

CREATE TABLE `sas_ucm_base` (
  `ucm_id` int(10) unsigned NOT NULL,
  `ucm_item_id` int(10) NOT NULL,
  `ucm_type_id` int(11) NOT NULL,
  `ucm_language_id` int(11) NOT NULL,
  PRIMARY KEY (`ucm_id`),
  KEY `idx_ucm_item_id` (`ucm_item_id`),
  KEY `idx_ucm_type_id` (`ucm_type_id`),
  KEY `idx_ucm_language_id` (`ucm_language_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table`sas_ucm_content`
--

CREATE TABLE `sas_ucm_content` (
  `core_content_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `core_type_alias` varchar(255) NOT NULL DEFAULT '' COMMENT 'FK to the content types table',
  `core_title` varchar(255) NOT NULL,
  `core_alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `core_body` mediumtext NOT NULL,
  `core_state` tinyint(1) NOT NULL DEFAULT '0',
  `core_checked_out_time` varchar(255) NOT NULL DEFAULT '',
  `core_checked_out_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_access` int(10) unsigned NOT NULL DEFAULT '0',
  `core_params` text NOT NULL,
  `core_featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `core_metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `core_created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `core_created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_modified_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Most recent user that modified',
  `core_modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_language` char(7) NOT NULL,
  `core_publish_up` datetime NOT NULL,
  `core_publish_down` datetime NOT NULL,
  `core_content_item_id` int(10) unsigned DEFAULT NULL COMMENT 'ID from the individual type table',
  `asset_id` int(10) unsigned DEFAULT NULL COMMENT 'FK to the #__assets table.',
  `core_images` text NOT NULL,
  `core_urls` text NOT NULL,
  `core_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `core_version` int(10) unsigned NOT NULL DEFAULT '1',
  `core_ordering` int(11) NOT NULL DEFAULT '0',
  `core_metakey` text NOT NULL,
  `core_metadesc` text NOT NULL,
  `core_catid` int(10) unsigned NOT NULL DEFAULT '0',
  `core_xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `core_type_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`core_content_id`),
  KEY `tag_idx` (`core_state`,`core_access`),
  KEY `idx_access` (`core_access`),
  KEY `idx_alias` (`core_alias`),
  KEY `idx_language` (`core_language`),
  KEY `idx_title` (`core_title`),
  KEY `idx_modified_time` (`core_modified_time`),
  KEY `idx_created_time` (`core_created_time`),
  KEY `idx_content_type` (`core_type_alias`),
  KEY `idx_core_modified_user_id` (`core_modified_user_id`),
  KEY `idx_core_checked_out_user_id` (`core_checked_out_user_id`),
  KEY `idx_core_created_user_id` (`core_created_user_id`),
  KEY `idx_core_type_id` (`core_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Contains core content data in name spaced fields' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_ucm_history`
--

CREATE TABLE `sas_ucm_history` (
  `version_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ucm_item_id` int(10) unsigned NOT NULL,
  `ucm_type_id` int(10) unsigned NOT NULL,
  `version_note` varchar(255) NOT NULL DEFAULT '' COMMENT 'Optional version name',
  `save_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `character_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Number of characters in this version.',
  `sha1_hash` varchar(50) NOT NULL DEFAULT '' COMMENT 'SHA1 hash of the version_data column.',
  `version_data` mediumtext NOT NULL COMMENT 'json-encoded string of version data',
  `keep_forever` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=auto delete; 1=keep',
  PRIMARY KEY (`version_id`),
  KEY `idx_ucm_item_id` (`ucm_type_id`,`ucm_item_id`),
  KEY `idx_save_date` (`save_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_updates`
--

CREATE TABLE `sas_updates` (
  `update_id` int(11) NOT NULL AUTO_INCREMENT,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT '',
  `description` text NOT NULL,
  `element` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `folder` varchar(20) DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(32) DEFAULT '',
  `data` text NOT NULL,
  `detailsurl` text NOT NULL,
  `infourl` text NOT NULL,
  `extra_query` varchar(1000) DEFAULT '',
  PRIMARY KEY (`update_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Available Updates' AUTO_INCREMENT=52 ;

--
-- Dumping data for table 'sas_updates'
--

INSERT INTO `sas_updates` VALUES
(1, 3, 0, 'Malay', '', 'pkg_ms-MY', 'package', '', 0, '3.2.2.1', '', 'http://update.joomla.org/language/details3/ms-MY_details.xml', '', ''),
(2, 3, 0, 'Romanian', '', 'pkg_ro-RO', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/ro-RO_details.xml', '', ''),
(3, 3, 0, 'Flemish', '', 'pkg_nl-BE', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/nl-BE_details.xml', '', ''),
(4, 3, 0, 'Chinese Traditional', '', 'pkg_zh-TW', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/zh-TW_details.xml', '', ''),
(5, 3, 0, 'French', '', 'pkg_fr-FR', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/fr-FR_details.xml', '', ''),
(6, 3, 0, 'German', '', 'pkg_de-DE', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/de-DE_details.xml', '', ''),
(7, 3, 0, 'Greek', '', 'pkg_el-GR', 'package', '', 0, '3.2.0.1', '', 'http://update.joomla.org/language/details3/el-GR_details.xml', '', ''),
(8, 3, 0, 'Japanese', '', 'pkg_ja-JP', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/ja-JP_details.xml', '', ''),
(9, 3, 0, 'Hebrew', '', 'pkg_he-IL', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/he-IL_details.xml', '', ''),
(10, 3, 0, 'EnglishAU', '', 'pkg_en-AU', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/en-AU_details.xml', '', ''),
(11, 3, 0, 'EnglishUS', '', 'pkg_en-US', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/en-US_details.xml', '', ''),
(12, 3, 0, 'Hungarian', '', 'pkg_hu-HU', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/hu-HU_details.xml', '', ''),
(13, 3, 0, 'Afrikaans', '', 'pkg_af-ZA', 'package', '', 0, '3.2.0.1', '', 'http://update.joomla.org/language/details3/af-ZA_details.xml', '', ''),
(14, 3, 0, 'Arabic Unitag', '', 'pkg_ar-AA', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/ar-AA_details.xml', '', ''),
(15, 3, 0, 'Belarusian', '', 'pkg_be-BY', 'package', '', 0, '3.2.1.1', '', 'http://update.joomla.org/language/details3/be-BY_details.xml', '', ''),
(16, 3, 0, 'Bulgarian', '', 'pkg_bg-BG', 'package', '', 0, '3.2.1.1', '', 'http://update.joomla.org/language/details3/bg-BG_details.xml', '', ''),
(17, 3, 0, 'Catalan', '', 'pkg_ca-ES', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/ca-ES_details.xml', '', ''),
(18, 3, 0, 'Chinese Simplified', '', 'pkg_zh-CN', 'package', '', 0, '3.2.1.1', '', 'http://update.joomla.org/language/details3/zh-CN_details.xml', '', ''),
(19, 3, 0, 'Croatian', '', 'pkg_hr-HR', 'package', '', 0, '3.1.5.1', '', 'http://update.joomla.org/language/details3/hr-HR_details.xml', '', ''),
(20, 3, 0, 'Czech', '', 'pkg_cs-CZ', 'package', '', 0, '3.2.3.4', '', 'http://update.joomla.org/language/details3/cs-CZ_details.xml', '', ''),
(21, 3, 0, 'Danish', '', 'pkg_da-DK', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/da-DK_details.xml', '', ''),
(22, 3, 0, 'Dutch', '', 'pkg_nl-NL', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/nl-NL_details.xml', '', ''),
(23, 3, 0, 'Estonian', '', 'pkg_et-EE', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/et-EE_details.xml', '', ''),
(24, 3, 0, 'Italian', '', 'pkg_it-IT', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/it-IT_details.xml', '', ''),
(25, 3, 0, 'Korean', '', 'pkg_ko-KR', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/ko-KR_details.xml', '', ''),
(26, 3, 0, 'Latvian', '', 'pkg_lv-LV', 'package', '', 0, '3.2.3.2', '', 'http://update.joomla.org/language/details3/lv-LV_details.xml', '', ''),
(27, 3, 0, 'Macedonian', '', 'pkg_mk-MK', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/mk-MK_details.xml', '', ''),
(28, 3, 0, 'Norwegian Bokmal', '', 'pkg_nb-NO', 'package', '', 0, '3.2.2.1', '', 'http://update.joomla.org/language/details3/nb-NO_details.xml', '', ''),
(29, 3, 0, 'Persian', '', 'pkg_fa-IR', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/fa-IR_details.xml', '', ''),
(30, 3, 0, 'Polish', '', 'pkg_pl-PL', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/pl-PL_details.xml', '', ''),
(31, 3, 0, 'Russian', '', 'pkg_ru-RU', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/ru-RU_details.xml', '', ''),
(32, 3, 0, 'Slovak', '', 'pkg_sk-SK', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/sk-SK_details.xml', '', ''),
(33, 3, 0, 'Swedish', '', 'pkg_sv-SE', 'package', '', 0, '3.2.1.1', '', 'http://update.joomla.org/language/details3/sv-SE_details.xml', '', ''),
(34, 3, 0, 'Syriac', '', 'pkg_sy-IQ', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/sy-IQ_details.xml', '', ''),
(35, 3, 0, 'Tamil', '', 'pkg_ta-IN', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/ta-IN_details.xml', '', ''),
(36, 3, 0, 'Thai', '', 'pkg_th-TH', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/th-TH_details.xml', '', ''),
(37, 3, 0, 'Turkish', '', 'pkg_tr-TR', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/tr-TR_details.xml', '', ''),
(38, 3, 0, 'Ukrainian', '', 'pkg_uk-UA', 'package', '', 0, '3.2.0.6', '', 'http://update.joomla.org/language/details3/uk-UA_details.xml', '', ''),
(39, 3, 0, 'Uyghur', '', 'pkg_ug-CN', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/ug-CN_details.xml', '', ''),
(40, 3, 0, 'Albanian', '', 'pkg_sq-AL', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/sq-AL_details.xml', '', ''),
(41, 3, 0, 'Portuguese Brazil', '', 'pkg_pt-BR', 'package', '', 0, '3.0.2.1', '', 'http://update.joomla.org/language/details3/pt-BR_details.xml', '', ''),
(42, 3, 0, 'Serbian Latin', '', 'pkg_sr-YU', 'package', '', 0, '3.2.3.3', '', 'http://update.joomla.org/language/details3/sr-YU_details.xml', '', ''),
(43, 3, 0, 'Spanish', '', 'pkg_es-ES', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/es-ES_details.xml', '', ''),
(44, 3, 0, 'Bosnian', '', 'pkg_bs-BA', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/bs-BA_details.xml', '', ''),
(45, 3, 0, 'Serbian Cyrillic', '', 'pkg_sr-RS', 'package', '', 0, '3.2.3.2', '', 'http://update.joomla.org/language/details3/sr-RS_details.xml', '', ''),
(46, 3, 0, 'Vietnamese', '', 'pkg_vi-VN', 'package', '', 0, '3.2.1.1', '', 'http://update.joomla.org/language/details3/vi-VN_details.xml', '', ''),
(47, 3, 0, 'Bahasa Indonesia', '', 'pkg_id-ID', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/id-ID_details.xml', '', ''),
(48, 3, 0, 'Finnish', '', 'pkg_fi-FI', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/fi-FI_details.xml', '', ''),
(49, 3, 0, 'Swahili', '', 'pkg_sw-KE', 'package', '', 0, '3.2.3.1', '', 'http://update.joomla.org/language/details3/sw-KE_details.xml', '', ''),
(50, 3, 0, 'Montenegrin', '', 'pkg_srp-ME', 'package', '', 0, '3.2.1.1', '', 'http://update.joomla.org/language/details3/srp-ME_details.xml', '', '');

-- --------------------------------------------------------

--
-- Table structure for table`sas_update_sites`
--

CREATE TABLE `sas_update_sites` (
  `update_site_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `location` text NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  `extra_query` varchar(1000) DEFAULT '',
  PRIMARY KEY (`update_site_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Update Sites' AUTO_INCREMENT=15 ;

--
-- Dumping data for table 'sas_update_sites'
--

INSERT INTO `sas_update_sites` VALUES
(1, 'Joomla Core', 'collection', 'http://update.joomla.org/core/list.xml', 1, 1397790700, ''),
(2, 'Joomla Extension Directory', 'collection', 'http://update.joomla.org/jed/list.xml', 1, 1397790700, ''),
(3, 'Accredited Joomla! Translations', 'collection', 'http://update.joomla.org/language/translationlist_3.xml', 1, 1397790700, ''),
(4, 'jHackGuard Updates', 'extension', 'http://download.siteground.com/jhackguard.xml', 1, 1397790700, ''),
(5, 'jSGCache Updates', 'extension', 'http://download.siteground.com/jsgcache.xml', 1, 1397790700, ''),
(6, 'WebInstaller Update Site', 'extension', 'http://appscdn.joomla.org/webapps/jedapps/webinstaller.xml', 1, 1397790700, ''),
(7, 'JCE Editor Updates', 'extension', 'https://www.joomlacontenteditor.net/index.php?option=com_updates&view=update&format=xml&id=1&file=extension.xml', 1, 1397790700, ''),
(8, 'Akeeba Backup Core', 'extension', 'http://cdn.akeebabackup.com/updates/abcore.xml', 1, 1397790700, ''),
(9, 'AllVideos', 'extension', 'http://www.joomlaworks.net/updates/jw_allvideos.xml', 1, 1397790700, ''),
(10, 'K2 Updates', 'extension', 'http://getk2.org/update.xml', 1, 1397790700, ''),
(11, 'FlexBanner Updates', 'extension', 'http://www.inchhosting.co.uk/index.php?option=com_ars&view=update&format=xml&task=stream&id=4&dummy=extension.xml', 1, 1397790698, ''),
(12, 'SobiPro Updates', 'extension', 'https://xml.sigsiu.net/SobiPro/SobiPro.xml', 1, 1397790700, ''),
(13, 'AcyMailing', 'extension', 'http://www.acyba.com/component/updateme/updatexml/component-acymailing/level-Starter/file-extension.xml', 1, 1397790700, ''),
(14, 'ContentMap update site', 'extension', 'http://www.opensourcesolutions.es/download/contentmap.xml', 1, 1397790698, '');

-- --------------------------------------------------------

--
-- Table structure for table`sas_update_sites_extensions`
--

CREATE TABLE `sas_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`update_site_id`,`extension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Links extensions to update sites';

--
-- Dumping data for table 'sas_update_sites_extensions'
--

INSERT INTO `sas_update_sites_extensions` VALUES
(1, 700),
(2, 700),
(3, 600),
(6, 10003),
(7, 10006),
(8, 10007),
(9, 10009),
(10, 10010),
(11, 10024),
(12, 10027),
(13, 10028),
(14, 10048);

-- --------------------------------------------------------

--
-- Table structure for table`sas_usergroups`
--

CREATE TABLE `sas_usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table 'sas_usergroups'
--

INSERT INTO `sas_usergroups` VALUES
(1, 0, 1, 18, 'Public'),
(2, 1, 8, 15, 'Registered'),
(3, 2, 9, 14, 'Author'),
(4, 3, 10, 13, 'Editor'),
(5, 4, 11, 12, 'Publisher'),
(6, 1, 4, 7, 'Manager'),
(7, 6, 5, 6, 'Administrator'),
(8, 1, 16, 17, 'Super Users'),
(9, 1, 2, 3, 'Guest');

-- --------------------------------------------------------

--
-- Table structure for table`sas_users`
--

CREATE TABLE `sas_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `lastResetTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date of last password reset',
  `resetCount` int(11) NOT NULL DEFAULT '0' COMMENT 'Count of password resets since lastResetTime',
  `otpKey` varchar(1000) NOT NULL DEFAULT '' COMMENT 'Two factor authentication encrypted keys',
  `otep` varchar(1000) NOT NULL DEFAULT '' COMMENT 'One time emergency passwords',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_block` (`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=223 ;

--
-- Dumping data for table 'sas_users'
--

INSERT INTO `sas_users` VALUES
(222, 'Administrator', 'administrator', 'hello@jasonloton.com', '58198c10a8ad5495aab94a4b27ab87d0', 0, 1, '2014-04-12 12:58:13', '2014-04-18 03:11:35', '0', '{}', '0000-00-00 00:00:00', 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table`sas_user_keys`
--

CREATE TABLE `sas_user_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `series` varchar(255) NOT NULL,
  `invalid` tinyint(4) NOT NULL,
  `time` varchar(200) NOT NULL,
  `uastring` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `series` (`series`),
  UNIQUE KEY `series_2` (`series`),
  UNIQUE KEY `series_3` (`series`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_user_notes`
--

CREATE TABLE `sas_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(100) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category_id` (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_user_profiles`
--

CREATE TABLE `sas_user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) NOT NULL,
  `profile_value` varchar(255) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Simple user profile storage table';

-- --------------------------------------------------------

--
-- Table structure for table`sas_user_usergroup_map`
--

CREATE TABLE `sas_user_usergroup_map` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id',
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sas_user_usergroup_map'
--

INSERT INTO `sas_user_usergroup_map` VALUES
(222, 8);

-- --------------------------------------------------------

--
-- Table structure for table`sas_viewlevels`
--

CREATE TABLE `sas_viewlevels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `title` varchar(100) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_assetgroup_title_lookup` (`title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table 'sas_viewlevels'
--

INSERT INTO `sas_viewlevels` VALUES
(1, 'Public', 0, '[1]'),
(2, 'Registered', 1, '[6,2,8]'),
(3, 'Special', 2, '[6,3,8]'),
(5, 'Guest', 0, '[9]'),
(6, 'Super Users', 0, '[8]');

-- --------------------------------------------------------

--
-- Table structure for table`sas_weblinks`
--

CREATE TABLE `sas_weblinks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `language` char(7) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if link is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `images` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table`sas_wf_profiles`
--

CREATE TABLE `sas_wf_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `users` text NOT NULL,
  `types` text NOT NULL,
  `components` text NOT NULL,
  `area` tinyint(3) NOT NULL,
  `device` varchar(255) NOT NULL,
  `rows` text NOT NULL,
  `plugins` text NOT NULL,
  `published` tinyint(3) NOT NULL,
  `ordering` int(11) NOT NULL,
  `checked_out` tinyint(3) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table 'sas_wf_profiles'
--

INSERT INTO `sas_wf_profiles` VALUES
(1, 'Default', 'Default Profile for all users', '', '3,4,5,6,8,7', '', 0, 'desktop,tablet,phone', 'help,newdocument,undo,redo,spacer,bold,italic,underline,strikethrough,justifyfull,justifycenter,justifyleft,justifyright,spacer,blockquote,formatselect,styleselect,removeformat,cleanup;fontselect,fontsizeselect,forecolor,backcolor,spacer,clipboard,indent,outdent,lists,sub,sup,textcase,charmap,hr;directionality,fullscreen,preview,source,print,searchreplace,spacer,table;visualaid,visualchars,visualblocks,nonbreaking,style,xhtmlxtras,anchor,unlink,link,imgmanager,spellchecker,article', 'charmap,contextmenu,browser,inlinepopups,media,help,clipboard,searchreplace,directionality,fullscreen,preview,source,table,textcase,print,style,nonbreaking,visualchars,visualblocks,xhtmlxtras,imgmanager,anchor,link,spellchecker,article,lists', 1, 1, 0, '0000-00-00 00:00:00', ''),
(2, 'Front End', 'Sample Front-end Profile', '', '3,4,5', '', 1, 'desktop,tablet,phone', 'help,newdocument,undo,redo,spacer,bold,italic,underline,strikethrough,justifyfull,justifycenter,justifyleft,justifyright,spacer,formatselect,styleselect;clipboard,searchreplace,indent,outdent,lists,cleanup,charmap,removeformat,hr,sub,sup,textcase,nonbreaking,visualchars,visualblocks;fullscreen,preview,print,visualaid,style,xhtmlxtras,anchor,unlink,link,imgmanager,spellchecker,article', 'charmap,contextmenu,inlinepopups,help,clipboard,searchreplace,fullscreen,preview,print,style,textcase,nonbreaking,visualchars,visualblocks,xhtmlxtras,imgmanager,anchor,link,spellchecker,article,lists', 0, 2, 0, '0000-00-00 00:00:00', ''),
(3, 'Blogger', 'Simple Blogging Profile', '', '3,4,5,6,8,7', '', 0, 'desktop,tablet,phone', 'bold,italic,strikethrough,lists,blockquote,spacer,justifyleft,justifycenter,justifyright,spacer,link,unlink,imgmanager,article,spellchecker,fullscreen,kitchensink;formatselect,underline,justifyfull,forecolor,clipboard,removeformat,charmap,indent,outdent,undo,redo,help', 'link,imgmanager,article,spellchecker,fullscreen,kitchensink,clipboard,contextmenu,inlinepopups,lists', 0, 3, 0, '0000-00-00 00:00:00', '{"editor":{"toggle":"0"}}'),
(4, 'Mobile', 'Sample Mobile Profile', '', '3,4,5,6,8,7', '', 0, 'tablet,phone', 'undo,redo,spacer,bold,italic,underline,formatselect,spacer,justifyleft,justifycenter,justifyfull,justifyright,spacer,fullscreen,kitchensink;styleselect,lists,spellchecker,article,link,unlink', 'fullscreen,kitchensink,spellchecker,article,link,inlinepopups,lists', 0, 4, 0, '0000-00-00 00:00:00', '{"editor":{"toolbar_theme":"mobile","resizing":"0","resize_horizontal":"0","resizing_use_cookie":"0","toggle":"0","links":{"popups":{"default":"","jcemediabox":{"enable":"0"},"window":{"enable":"0"}}}}}');

-- --------------------------------------------------------

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
