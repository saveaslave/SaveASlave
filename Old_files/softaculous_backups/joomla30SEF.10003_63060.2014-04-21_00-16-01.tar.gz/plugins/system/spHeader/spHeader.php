<?php
/**
 * @version: $Id: spHeader.php 3925 2013-12-17 10:47:32Z Sigrid Suski $
 * @package: SobiPro Component for Joomla!
 * @author
 * Name: Sigrid Suski & Radek Suski, Sigsiu.NET GmbH
 * Email: sobi[at]sigsiu.net
 * Url: http://www.Sigsiu.NET
 * @copyright Copyright (C) 2006 - 2013 Sigsiu.NET GmbH (http://www.sigsiu.net). All rights reserved.
 * @license GNU/GPL Version 3
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License version 3
 * as published by the Free Software Foundation, and under the additional terms according section 7 of GPL v3.
 * See http://www.gnu.org/licenses/gpl.html and http://sobipro.sigsiu.net/licenses.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * $Date: 2013-12-17 11:47:32 +0100 (Tue, 17 Dec 2013) $
 * $Revision: 3925 $
 * $Author: Sigrid Suski $
 */

defined( '_JEXEC' ) or die();
class plgSystemSpHeader extends JPlugin
{
	public function onBeforeCompileHead()
	{
		// if the class exists it means something initialised it so we can send the header
		if ( class_exists( 'SPFactory' ) ) {
			SPFactory::header()->sendHeader();
		}
	}
}
